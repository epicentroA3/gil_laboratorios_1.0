-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: gil_laboratorios
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alertas_mantenimiento`
--

DROP TABLE IF EXISTS `alertas_mantenimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alertas_mantenimiento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_equipo` int NOT NULL,
  `tipo_alerta` enum('mantenimiento_programado','mantenimiento_vencido','falla_predicha','revision_urgente') COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion_alerta` text COLLATE utf8mb4_unicode_ci,
  `fecha_alerta` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_limite` date DEFAULT NULL,
  `prioridad` enum('baja','media','alta','critica') COLLATE utf8mb4_unicode_ci DEFAULT 'media',
  `estado_alerta` enum('pendiente','en_proceso','resuelta','cancelada') COLLATE utf8mb4_unicode_ci DEFAULT 'pendiente',
  `asignado_a` int DEFAULT NULL,
  `fecha_resolucion` datetime DEFAULT NULL,
  `observaciones_resolucion` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `id_equipo` (`id_equipo`),
  KEY `asignado_a` (`asignado_a`),
  KEY `idx_estado_alerta` (`estado_alerta`),
  KEY `idx_prioridad` (`prioridad`),
  KEY `idx_fecha_limite` (`fecha_limite`),
  CONSTRAINT `alertas_mantenimiento_ibfk_1` FOREIGN KEY (`id_equipo`) REFERENCES `equipos` (`id`),
  CONSTRAINT `alertas_mantenimiento_ibfk_2` FOREIGN KEY (`asignado_a`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alertas_mantenimiento`
--

LOCK TABLES `alertas_mantenimiento` WRITE;
/*!40000 ALTER TABLE `alertas_mantenimiento` DISABLE KEYS */;
INSERT INTO `alertas_mantenimiento` VALUES (1,1,'mantenimiento_programado','Mantenimiento preventivo mensual programado para microscopio','2025-12-12 19:38:09','2024-12-15','media','pendiente',6,NULL,NULL),(2,2,'mantenimiento_programado','Mantenimiento preventivo mensual programado para microscopio','2025-12-12 19:38:09','2024-12-15','media','pendiente',6,NULL,NULL),(3,12,'mantenimiento_programado','Limpieza mensual de quemador y nebulizador del AA','2025-12-12 19:38:09','2024-12-20','alta','resuelta',7,'2025-12-14 15:23:59','Resuelto por mantenimiento #6'),(4,3,'revision_urgente','Se detectó desalineación en el sistema óptico durante última práctica','2025-12-12 19:38:09','2024-12-10','critica','en_proceso',6,NULL,NULL),(5,21,'mantenimiento_vencido','Calibración de temperatura vencida hace 15 días','2025-12-12 19:38:09','2024-11-25','alta','pendiente',7,NULL,NULL),(6,1,'mantenimiento_vencido','Mantenimiento vencido para Microscopio Óptico Binocular. Fecha programada: 2024-12-01','2025-12-14 15:51:51','2024-12-01','alta','pendiente',NULL,NULL,NULL),(7,2,'mantenimiento_vencido','Mantenimiento vencido para Microscopio Óptico Binocular. Fecha programada: 2024-12-01','2025-12-14 15:51:51','2024-12-01','alta','pendiente',NULL,NULL,NULL),(8,5,'mantenimiento_vencido','Mantenimiento vencido para Balanza Analítica de Precisión. Fecha programada: 2025-04-15','2025-12-14 15:51:51','2025-04-15','alta','pendiente',NULL,NULL,NULL),(9,6,'mantenimiento_vencido','Mantenimiento vencido para Balanza Analítica de Precisión. Fecha programada: 2025-04-15','2025-12-14 15:51:51','2025-04-15','alta','resuelta',NULL,'2025-12-14 15:27:47','Resuelto por mantenimiento #4'),(10,11,'mantenimiento_vencido','Mantenimiento vencido para Espectrofotómetro de Absorción Atómica. Fecha programada: 2025-03-20','2025-12-14 15:51:51','2025-03-20','alta','pendiente',NULL,NULL,NULL),(11,12,'mantenimiento_vencido','Mantenimiento vencido para pH-metro de Mesa. Fecha programada: 2024-12-15','2025-12-14 15:51:51','2024-12-15','alta','resuelta',NULL,'2025-12-14 15:23:59','Resuelto por mantenimiento #6'),(12,19,'mantenimiento_vencido','Mantenimiento vencido para Celda de Flotación Denver. Fecha programada: 2024-12-05','2025-12-14 15:51:51','2024-12-05','alta','resuelta',NULL,'2025-12-14 14:29:13','Resuelto por mantenimiento #7'),(13,19,'revision_urgente','Revisión urgente requerida para Celda de Flotación Denver (MIN-003). Estado físico: malo','2025-12-14 18:46:48','2025-12-14','critica','resuelta',NULL,'2025-12-14 14:29:13','Resuelto por mantenimiento #7'),(14,28,'revision_urgente','Revisión urgente requerida para AIRPORDS (EQP-8EC1CE0D). Estado físico: malo','2025-12-14 18:46:48','2025-12-14','critica','resuelta',NULL,'2025-12-14 14:32:53','Resuelto por mantenimiento #9'),(15,2,'falla_predicha','⚠️ Equipo con estado físico MALO - Microscopio Óptico Binocular (MICRO-002)','2025-12-14 19:57:16','2025-12-17','critica','cancelada',NULL,NULL,'Cancelada por usuario'),(16,28,'falla_predicha','⚠️ Equipo con estado físico MALO - AIRPORDS (EQP-8EC1CE0D)','2025-12-14 19:57:16','2025-12-17','critica','cancelada',NULL,NULL,'Cancelada por usuario'),(17,1,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para Microscopio Óptico Binocular (MICRO-001)','2025-12-14 20:04:54','2025-12-21','critica','cancelada',NULL,NULL,'Cancelada por usuario'),(18,3,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para Microscopio Estereoscópico (MICRO-003)','2025-12-14 20:04:54','2025-12-21','critica','cancelada',NULL,NULL,'Cancelada por usuario'),(19,4,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para Microscopio Petrográfico (MICRO-004)','2025-12-14 20:04:54','2025-12-21','critica','pendiente',NULL,NULL,NULL),(20,5,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para Balanza Analítica de Precisión (BAL-001)','2025-12-14 20:04:54','2025-12-21','critica','pendiente',NULL,NULL,NULL),(21,6,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para Balanza Analítica de Precisión (BAL-002)','2025-12-14 20:04:54','2025-12-21','critica','resuelta',NULL,'2025-12-14 15:27:47','Resuelto por mantenimiento #4'),(22,7,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para Balanza de Precisión (BAL-003)','2025-12-14 20:04:54','2025-12-21','critica','pendiente',NULL,NULL,NULL),(23,8,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para Centrífuga de Laboratorio (CENT-001)','2025-12-14 20:04:54','2025-12-21','critica','cancelada',NULL,NULL,'Cancelada por usuario'),(24,9,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para Centrífuga Refrigerada (CENT-002)','2025-12-14 20:04:54','2025-12-21','critica','cancelada',NULL,NULL,'Cancelada por usuario'),(25,10,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para Espectrofotómetro UV-Vis (ESPEC-001)','2025-12-14 20:04:54','2025-12-21','critica','cancelada',NULL,NULL,'Cancelada por usuario'),(26,11,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para Espectrofotómetro de Absorción Atómica (ESPEC-002)','2025-12-14 20:04:54','2025-12-21','critica','cancelada',NULL,NULL,'Cancelada por usuario'),(27,12,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para pH-metro de Mesa (PH-001)','2025-12-14 20:04:54','2025-12-21','critica','resuelta',NULL,'2025-12-14 15:23:59','Resuelto por mantenimiento #6'),(28,13,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para pH-metro de Mesa (PH-002)','2025-12-14 20:04:54','2025-12-21','critica','pendiente',NULL,NULL,NULL),(29,14,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para pH-metro Portátil (PH-003)','2025-12-14 20:04:54','2025-12-21','critica','pendiente',NULL,NULL,NULL),(30,15,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para Estufa de Secado (ESTUF-001)','2025-12-14 20:04:54','2025-12-21','critica','pendiente',NULL,NULL,NULL),(31,16,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para Mufla de Alta Temperatura (ESTUF-002)','2025-12-14 20:04:54','2025-12-21','critica','pendiente',NULL,NULL,NULL),(32,17,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para Trituradora de Mandíbulas (MIN-001)','2025-12-14 20:04:54','2025-12-21','critica','pendiente',NULL,NULL,NULL),(33,18,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para Molino de Bolas (MIN-002)','2025-12-14 20:04:54','2025-12-21','critica','pendiente',NULL,NULL,NULL),(34,19,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para Celda de Flotación Denver (MIN-003)','2025-12-14 20:04:55','2025-12-21','critica','resuelta',NULL,'2025-12-14 15:21:54','Resuelto por mantenimiento #7'),(35,21,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para Hidrómetro de Bouyoucos (SUELO-002)','2025-12-14 20:04:55','2025-12-21','critica','pendiente',NULL,NULL,NULL),(36,22,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para Balanza (EQP-2A61CADA)','2025-12-14 20:04:55','2025-12-21','critica','pendiente',NULL,NULL,NULL),(37,23,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para quimico a (EQP-EA2D5758)','2025-12-14 20:04:55','2025-12-21','critica','pendiente',NULL,NULL,NULL),(38,24,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para KB (EQP-0E640D1D)','2025-12-14 20:04:55','2025-12-21','critica','pendiente',NULL,NULL,NULL),(39,25,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para call of duty (EQP-6311A703)','2025-12-14 20:04:55','2025-12-21','critica','pendiente',NULL,NULL,NULL),(40,26,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para call of duty ww (EQP-164AB54B)','2025-12-14 20:04:55','2025-12-21','critica','pendiente',NULL,NULL,NULL),(41,27,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para call of duty III (EQP-A320436F)','2025-12-14 20:04:55','2025-12-21','critica','pendiente',NULL,NULL,NULL),(42,29,'falla_predicha','🤖 IA predice falla con 100.0% de probabilidad para FORRO (EQP-3C3E77A9)','2025-12-14 20:04:55','2025-12-21','critica','pendiente',NULL,NULL,NULL),(43,2,'falla_predicha','⚠️ Equipo con estado físico MALO - Microscopio Óptico Binocular (MICRO-002)','2025-12-14 20:43:09','2025-12-17','critica','pendiente',NULL,NULL,NULL),(44,2,'revision_urgente','Revisión urgente requerida para Microscopio Óptico Binocular (MICRO-002). Estado físico: malo','2025-12-15 16:58:51','2025-12-15','critica','pendiente',NULL,NULL,NULL);
/*!40000 ALTER TABLE `alertas_mantenimiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capacitaciones`
--

DROP TABLE IF EXISTS `capacitaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `capacitaciones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titulo` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `tipo_capacitacion` enum('modulo_formativo','taller','material_didactico','gestion_cambio') COLLATE utf8mb4_unicode_ci DEFAULT 'taller',
  `producto` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `medicion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cantidad_meta` int DEFAULT NULL,
  `cantidad_actual` int DEFAULT '0',
  `actividad` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `porcentaje_avance` decimal(5,2) DEFAULT '0.00',
  `recursos_asociados` text COLLATE utf8mb4_unicode_ci,
  `participantes` text COLLATE utf8mb4_unicode_ci,
  `duracion_horas` int DEFAULT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `estado` enum('programada','activo','finalizada','cancelada') COLLATE utf8mb4_unicode_ci DEFAULT 'programada',
  `id_instructor` int DEFAULT NULL,
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_instructor` (`id_instructor`),
  CONSTRAINT `capacitaciones_ibfk_1` FOREIGN KEY (`id_instructor`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capacitaciones`
--

LOCK TABLES `capacitaciones` WRITE;
/*!40000 ALTER TABLE `capacitaciones` DISABLE KEYS */;
INSERT INTO `capacitaciones` VALUES (1,'Módulo 1: Fundamentos de Inteligencia Artificial','Introducción a conceptos básicos de IA, Machine Learning y Deep Learning aplicados al laboratorio','modulo_formativo','Programa formativo en tecnologías IA','Número de módulos formativos',7,2,'Actividad 1: Diseñar programa de formación en tecnologías IA',28.57,NULL,NULL,40,'2025-01-15','2025-02-15','activo',NULL,'2025-12-15 10:54:12'),(2,'Módulo 2: Reconocimiento de Imágenes con IA','Aplicación de redes neuronales convolucionales para reconocimiento de equipos de laboratorio','modulo_formativo','Programa formativo en tecnologías IA','Número de módulos formativos',5,1,'Actividad 1: Diseñar programa de formación en tecnologías IA',20.00,NULL,NULL,30,'2025-02-20','2025-03-20','programada',NULL,'2025-12-15 10:54:12'),(3,'Módulo 3: Procesamiento de Voz con IA','Implementación de asistentes virtuales y reconocimiento de comandos de voz','modulo_formativo','Programa formativo en tecnologías IA','Número de módulos formativos',5,1,'Actividad 1: Diseñar programa de formación en tecnologías IA',20.00,NULL,NULL,40,'2025-03-25','2025-04-25','programada',NULL,'2025-12-15 10:54:12'),(4,'Módulo 4: IA Predictiva para Mantenimiento','Modelos predictivos para anticipar necesidades de mantenimiento de equipos','modulo_formativo','Programa formativo en tecnologías IA','Número de módulos formativos',5,1,'Actividad 1: Diseñar programa de formación en tecnologías IA',20.00,NULL,NULL,40,'2025-05-01','2025-06-01','programada',NULL,'2025-12-15 10:54:12'),(5,'Módulo 5: Integración y Despliegue de Modelos IA','Implementación práctica de modelos IA en el sistema de laboratorio','modulo_formativo','Programa formativo en tecnologías IA','Número de módulos formativos',5,1,'Actividad 1: Diseñar programa de formación en tecnologías IA',20.00,NULL,NULL,40,'2025-06-05','2025-07-05','programada',NULL,'2025-12-15 10:54:12'),(6,'Taller: Reconocimiento Facial para Acceso al Sistema','Taller práctico sobre implementación de reconocimiento facial en el sistema GIL','taller','Personal capacitado en nuevas tecnologías','Número de personas capacitadas',33,0,'Actividad 2: Realizar talleres de tecnologías de voz e imagen',0.00,NULL,NULL,8,'2025-02-10','2025-02-10','programada',NULL,'2025-12-15 10:54:12'),(7,'Taller: Asistente de Voz LUCIA - Configuración y Uso','Capacitación en el uso y configuración del asistente de voz del sistema','taller','Personal capacitado en nuevas tecnologías','Número de personas capacitadas',33,0,'Actividad 2: Realizar talleres de tecnologías de voz e imagen',0.00,NULL,NULL,6,'2025-03-15','2025-03-15','programada',NULL,'2025-12-15 10:54:12'),(8,'Taller: Reconocimiento de Equipos por Imagen','Uso práctico del sistema de reconocimiento de equipos mediante fotografías','taller','Personal capacitado en nuevas tecnologías','Número de personas capacitadas',33,0,'Actividad 2: Realizar talleres de tecnologías de voz e imagen',0.00,NULL,NULL,6,'2025-04-10','2025-04-10','programada',NULL,'2025-12-15 10:54:12'),(9,'Desarrollo de Guías de Usuario del Sistema GIL','Creación de manuales y guías interactivas para usuarios del sistema','material_didactico','Material didáctico multimedia','Número de recursos creados',20,5,'Actividad 3: Desarrollar material didáctico sobre el sistema',25.00,NULL,NULL,120,'2025-01-10','2025-06-30','activo',NULL,'2025-12-15 10:54:12'),(10,'Videos Tutoriales de Funcionalidades IA','Serie de videos explicativos sobre las funcionalidades de IA del sistema','material_didactico','Material didáctico multimedia','Número de recursos creados',20,3,'Actividad 3: Desarrollar material didáctico sobre el sistema',15.00,NULL,NULL,80,'2025-02-01','2025-06-30','activo',NULL,'2025-12-15 10:54:12'),(11,'Infografías de Procesos del Sistema','Infografías visuales de los procesos clave del sistema de laboratorio','material_didactico','Material didáctico multimedia','Número de recursos creados',20,2,'Actividad 3: Desarrollar material didáctico sobre el sistema',10.00,NULL,NULL,40,'2025-03-01','2025-06-30','activo',NULL,'2025-12-15 10:54:12'),(12,'Estrategia de Adopción Tecnológica','Implementación de estrategia para promover la adopción del sistema GIL con IA','gestion_cambio','Estrategia de gestión del cambio','Porcentaje de adopción tecnológica',90,80,'Actividad 4: Implementar estrategia de gestión del cambio',88.89,NULL,NULL,160,'2025-01-05','2025-12-31','activo',NULL,'2025-12-15 10:54:12'),(13,'Programa de Embajadores Tecnológicos','Formación de usuarios clave como promotores del cambio tecnológico','gestion_cambio','Estrategia de gestión del cambio','Porcentaje de adopción tecnológica',90,30,'Actividad 4: Implementar estrategia de gestión del cambio',33.33,NULL,NULL,80,'2025-02-01','2025-12-31','activo',NULL,'2025-12-15 10:54:12'),(14,'Prueba de Capacitación','Esta es una prueba','taller','Producto de prueba','Número de pruebas',10,0,'Actividad de prueba',0.00,NULL,NULL,8,'2025-01-20','2025-01-21','programada',NULL,'2025-12-15 11:12:43'),(15,'DIPLOMA DE ESTUDIOS DE BÁSICA PRIMARIA','','modulo_formativo','ASD','ASD',2,2,'Actividad 1: Diseñar programa de formación en tecnología',100.00,NULL,'3',1,'2025-12-15','2025-12-15','finalizada',NULL,'2025-12-15 11:18:24'),(16,'DIPLOMA DE ESTUDIOS','','modulo_formativo','','',3,0,'',0.00,NULL,NULL,1,'2025-12-15','2025-12-15','activo',NULL,'2025-12-15 17:17:48'),(17,'DIPLOMA DE ESTUDIOS DE BÁSICA PRIMARIA','','modulo_formativo','','',0,0,'',0.00,NULL,NULL,1,'2025-12-15','2025-12-15','programada',NULL,'2025-12-15 19:28:17');
/*!40000 ALTER TABLE `capacitaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias_equipos`
--

DROP TABLE IF EXISTS `categorias_equipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorias_equipos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `codigo` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias_equipos`
--

LOCK TABLES `categorias_equipos` WRITE;
/*!40000 ALTER TABLE `categorias_equipos` DISABLE KEYS */;
INSERT INTO `categorias_equipos` VALUES (1,'Microscopios','Equipos de observación y análisis microscópico','MICRO','2025-12-12 19:38:02'),(2,'Balanzas','Equipos de medición de masa y peso','BAL','2025-12-12 19:38:02'),(3,'Centrifugas','Equipos de separación por centrifugación','CENT','2025-12-12 19:38:02'),(4,'Espectrofotómetros','Equipos de análisis espectral','ESPEC','2025-12-12 19:38:02'),(5,'pH-metros','Equipos de medición de pH','PH','2025-12-12 19:38:02'),(6,'Estufas','Equipos de calentamiento y secado','ESTUF','2025-12-12 19:38:02'),(7,'Equipos Minería','Equipos específicos para análisis minero','MIN','2025-12-12 19:38:02'),(8,'Equipos Suelos','Equipos para análisis de suelos','SUELO','2025-12-12 19:38:02'),(9,'Instrumentos Medición','Instrumentos generales de medición','MED','2025-12-12 19:38:02'),(10,'Reactivos','Productos químicos y reactivos','REACT','2025-12-12 19:38:02');
/*!40000 ALTER TABLE `categorias_equipos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comandos_voz`
--

DROP TABLE IF EXISTS `comandos_voz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comandos_voz` (
  `id_comando` int NOT NULL AUTO_INCREMENT,
  `comando_texto` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `intencion` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parametros` text COLLATE utf8mb4_unicode_ci,
  `respuesta_esperada` text COLLATE utf8mb4_unicode_ci,
  `frecuencia_uso` int DEFAULT '0',
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `estado` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci DEFAULT 'activo',
  PRIMARY KEY (`id_comando`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comandos_voz`
--

LOCK TABLES `comandos_voz` WRITE;
/*!40000 ALTER TABLE `comandos_voz` DISABLE KEYS */;
INSERT INTO `comandos_voz` VALUES (1,'Lucia buscar equipo','buscar_equipo','{\"tipo\": \"general\"}','Iniciando búsqueda de equipos disponibles',0,'2025-12-12 19:38:02','activo'),(2,'Lucia estado laboratorio','consultar_laboratorio','{\"info\": \"estado\"}','Consultando estado actual de laboratorios',0,'2025-12-12 19:38:02','activo'),(3,'Lucia préstamo equipo','solicitar_prestamo','{\"accion\": \"solicitar\"}','Iniciando proceso de solicitud de préstamo',0,'2025-12-12 19:38:02','activo'),(4,'Lucia inventario disponible','consultar_inventario','{\"filtro\": \"disponible\"}','Mostrando inventario disponible',0,'2025-12-12 19:38:02','activo'),(5,'Lucia alertas mantenimiento','consultar_alertas','{\"tipo\": \"mantenimiento\"}','Consultando alertas de mantenimiento pendientes',0,'2025-12-12 19:38:02','activo'),(6,'Lucia ayuda comandos','mostrar_ayuda','{\"seccion\": \"comandos\"}','Mostrando comandos disponibles',0,'2025-12-12 19:38:02','activo'),(7,'Lucia estado préstamos','consultar_prestamos','{\"estado\": \"activos\"}','Consultando préstamos activos',0,'2025-12-12 19:38:02','activo'),(8,'Lucia registrar devolución','devolver_equipo','{\"accion\": \"devolver\"}','Iniciando proceso de devolución',0,'2025-12-12 19:38:02','activo');
/*!40000 ALTER TABLE `comandos_voz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion_sistema`
--

DROP TABLE IF EXISTS `configuracion_sistema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracion_sistema` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clave_config` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_config` text COLLATE utf8mb4_unicode_ci,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `tipo_dato` enum('string','integer','boolean','json') COLLATE utf8mb4_unicode_ci DEFAULT 'string',
  `fecha_actualizacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave_config` (`clave_config`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion_sistema`
--

LOCK TABLES `configuracion_sistema` WRITE;
/*!40000 ALTER TABLE `configuracion_sistema` DISABLE KEYS */;
INSERT INTO `configuracion_sistema` VALUES (1,'nombre_sistema','GIL Laboratorios SENA','Nombre del sistema','string','2025-12-12 19:38:09'),(2,'version','1.0.0','Versión actual del sistema','string','2025-12-12 19:38:09'),(3,'timezone','America/Bogota','Zona horaria del sistema','string','2025-12-12 19:38:09'),(4,'idioma_default','es','Idioma por defecto','string','2025-12-12 19:38:09'),(5,'max_prestamo_horas','8','Máximo de horas por préstamo','integer','2025-12-12 19:38:09'),(6,'dias_anticipacion_alerta','7','Días de anticipación para alertas de mantenimiento','integer','2025-12-12 19:38:09'),(7,'umbral_confianza_voz','0.75','Umbral mínimo de confianza para comandos de voz','string','2025-12-12 19:38:09'),(8,'umbral_confianza_imagen','0.80','Umbral mínimo de confianza para reconocimiento de imágenes','string','2025-12-12 19:38:09'),(9,'habilitar_notificaciones_email','true','Habilitar notificaciones por email','boolean','2025-12-12 19:38:09'),(10,'habilitar_lucia','true','Habilitar asistente de voz LUCIA','boolean','2025-12-12 19:38:09'),(11,'tema_interfaz','claro','Tema de la interfaz (claro/oscuro)','string','2025-12-12 19:38:09'),(12,'backup_automatico','true','Habilitar backup automático diario','boolean','2025-12-12 19:38:09'),(13,'SISTEMA_NOMBRE','Sistema GIL - Centro Minero','Nombre del sistema','string','2025-12-15 10:44:23'),(14,'SISTEMA_VERSION','1.0.0','Versión actual del sistema','string','2025-12-15 10:44:23'),(15,'SISTEMA_MANTENIMIENTO','false','Modo mantenimiento activado','boolean','2025-12-15 10:44:23'),(16,'SESION_TIMEOUT','3600','Tiempo de sesión en segundos (1 hora)','integer','2025-12-15 10:44:23'),(17,'SESION_MAX_INTENTOS','5','Máximo de intentos de login fallidos','integer','2025-12-15 10:44:23'),(18,'SESION_BLOQUEO_MINUTOS','15','Minutos de bloqueo tras intentos fallidos','integer','2025-12-15 10:44:23'),(19,'PASSWORD_MIN_LENGTH','8','Longitud mínima de contraseña','integer','2025-12-15 10:44:23'),(20,'PASSWORD_REQUIRE_UPPERCASE','true','Requiere mayúsculas en contraseña','boolean','2025-12-15 10:44:23'),(21,'PASSWORD_REQUIRE_LOWERCASE','true','Requiere minúsculas en contraseña','boolean','2025-12-15 10:44:23'),(22,'PASSWORD_REQUIRE_NUMBER','true','Requiere números en contraseña','boolean','2025-12-15 10:44:23'),(23,'PASSWORD_REQUIRE_SPECIAL','true','Requiere caracteres especiales en contraseña','boolean','2025-12-15 10:44:23'),(24,'BACKUP_AUTO_ENABLED','true','Backups automáticos habilitados','boolean','2025-12-15 10:44:23'),(25,'BACKUP_FREQUENCY_HOURS','24','Frecuencia de backups en horas','integer','2025-12-15 10:44:23'),(26,'BACKUP_RETENTION_DAYS','30','Días de retención de backups','integer','2025-12-15 10:44:23'),(27,'BACKUP_MAX_FILES','10','Número máximo de archivos de backup','integer','2025-12-15 10:44:23'),(28,'PRESTAMO_DURACION_MAX_DIAS','7','Duración máxima de préstamo en días','integer','2025-12-15 10:44:23'),(29,'PRESTAMO_RENOVACIONES_MAX','2','Número máximo de renovaciones','integer','2025-12-15 10:44:23'),(30,'PRESTAMO_MULTA_DIA','5000','Multa por día de retraso (COP)','integer','2025-12-15 10:44:23'),(31,'RESERVA_ANTICIPACION_MAX_DIAS','30','Días máximos de anticipación para reservas','integer','2025-12-15 10:44:23'),(32,'RESERVA_DURACION_MAX_HORAS','4','Duración máxima de reserva en horas','integer','2025-12-15 10:44:23'),(33,'RESERVA_CANCELACION_HORAS','24','Horas mínimas para cancelar reserva','integer','2025-12-15 10:44:23'),(34,'MANTENIMIENTO_ALERTA_DIAS','7','Días de anticipación para alertas de mantenimiento','integer','2025-12-15 10:44:23'),(35,'MANTENIMIENTO_PREVENTIVO_MESES','6','Meses entre mantenimientos preventivos','integer','2025-12-15 10:44:23'),(36,'NOTIFICACIONES_EMAIL_ENABLED','false','Notificaciones por email habilitadas','boolean','2025-12-15 10:44:23'),(37,'NOTIFICACIONES_SMS_ENABLED','false','Notificaciones por SMS habilitadas','boolean','2025-12-15 10:44:23'),(38,'NOTIFICACIONES_PRESTAMOS_VENCIDOS','true','Notificar préstamos vencidos','boolean','2025-12-15 10:44:23'),(39,'NOTIFICACIONES_MANTENIMIENTO_PROXIMO','true','Notificar mantenimientos próximos','boolean','2025-12-15 10:44:23'),(40,'IA_RECONOCIMIENTO_ENABLED','true','Reconocimiento de equipos por IA habilitado','boolean','2025-12-15 10:44:24'),(41,'IA_CONFIDENCE_THRESHOLD','0.85','Umbral de confianza para IA (0-1)','string','2025-12-15 10:44:24'),(42,'IA_MAX_IMAGE_SIZE_MB','5','Tamaño máximo de imagen en MB','integer','2025-12-15 10:44:24'),(43,'LUCIA_ENABLED','true','Asistente de voz LUCIA habilitado','boolean','2025-12-15 10:44:24'),(44,'LUCIA_LANGUAGE','es-CO','Idioma del asistente de voz','string','2025-12-15 10:44:24'),(45,'LUCIA_TIMEOUT_SECONDS','5','Timeout de reconocimiento de voz en segundos','integer','2025-12-15 10:44:24'),(46,'REPORTES_FORMATO_DEFECTO','PDF','Formato por defecto de reportes','string','2025-12-15 10:44:24'),(47,'REPORTES_LOGO_ENABLED','true','Incluir logo en reportes','boolean','2025-12-15 10:44:24'),(48,'UI_THEME','light','Tema de la interfaz (light/dark)','string','2025-12-15 10:44:24'),(49,'UI_ITEMS_PER_PAGE','20','Elementos por página en tablas','integer','2025-12-15 10:44:24'),(50,'UI_DATE_FORMAT','DD/MM/YYYY','Formato de fecha','string','2025-12-15 10:44:24'),(51,'UI_TIME_FORMAT','HH:mm','Formato de hora','string','2025-12-15 10:44:24');
/*!40000 ALTER TABLE `configuracion_sistema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encuestas`
--

DROP TABLE IF EXISTS `encuestas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `encuestas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `tipo` enum('practica','prestamo','mantenimiento','general') COLLATE utf8mb4_unicode_ci NOT NULL,
  `puntuacion` int DEFAULT NULL,
  `comentarios` text COLLATE utf8mb4_unicode_ci,
  `fecha` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `encuestas_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `encuestas_chk_1` CHECK ((`puntuacion` between 1 and 5))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encuestas`
--

LOCK TABLES `encuestas` WRITE;
/*!40000 ALTER TABLE `encuestas` DISABLE KEYS */;
INSERT INTO `encuestas` VALUES (1,9,'prestamo',5,'El asistente Lucia me prestó el equipo en 10 segundos, ¡increíble!','2025-12-12 19:38:09'),(2,10,'practica',4,'Muy útil, pero a veces Lucia no entiende mi acento boyacense.','2025-12-12 19:38:09'),(3,11,'mantenimiento',5,'Me avisaron que el microscopio necesitaba calibración antes de que fallara.','2025-12-12 19:38:09'),(4,12,'general',4,'El sistema es rápido, pero falta más información en el dashboard.','2025-12-12 19:38:09'),(5,13,'prestamo',3,'El código QR no funcionó, tuve que usar el buscador manual.','2025-12-12 19:38:09'),(6,14,'practica',5,'La programación de prácticas fue muy fluida, sin conflictos.','2025-12-12 19:38:09'),(7,15,'general',5,'Se nota que el sistema aprende, cada vez reconoce mejor los equipos.','2025-12-12 19:38:09'),(8,16,'mantenimiento',4,'Buenas alertas, pero deberían llegar por email también.','2025-12-12 19:38:09'),(9,17,'prestamo',5,'Devolver el equipo con voz es súper cómodo, especialmente con guantes.','2025-12-12 19:38:09'),(10,18,'general',4,'Me gustaría poder reportar fallos directamente desde el sistema.','2025-12-12 19:38:09');
/*!40000 ALTER TABLE `encuestas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipos`
--

DROP TABLE IF EXISTS `equipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo_interno` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_qr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marca` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modelo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_serie` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_categoria` int DEFAULT NULL,
  `id_laboratorio` int DEFAULT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `especificaciones_tecnicas` text COLLATE utf8mb4_unicode_ci,
  `valor_adquisicion` decimal(12,2) DEFAULT NULL,
  `fecha_adquisicion` date DEFAULT NULL,
  `proveedor` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `garantia_meses` int DEFAULT '12',
  `vida_util_anos` int DEFAULT '5',
  `imagen_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imagen_hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` enum('disponible','prestado','mantenimiento','reparacion','dado_baja') COLLATE utf8mb4_unicode_ci DEFAULT 'disponible',
  `estado_fisico` enum('excelente','bueno','regular','malo') COLLATE utf8mb4_unicode_ci DEFAULT 'bueno',
  `ubicacion_especifica` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_actualizacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo_interno` (`codigo_interno`),
  UNIQUE KEY `codigo_qr` (`codigo_qr`),
  KEY `idx_codigo_interno` (`codigo_interno`),
  KEY `idx_estado` (`estado`),
  KEY `idx_categoria` (`id_categoria`),
  KEY `idx_laboratorio` (`id_laboratorio`),
  CONSTRAINT `equipos_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categorias_equipos` (`id`),
  CONSTRAINT `equipos_ibfk_2` FOREIGN KEY (`id_laboratorio`) REFERENCES `laboratorios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipos`
--

LOCK TABLES `equipos` WRITE;
/*!40000 ALTER TABLE `equipos` DISABLE KEYS */;
INSERT INTO `equipos` VALUES (1,'MICRO-001','QR-MICRO-001','Microscopio Óptico Binocular','Olympus','CX23','OLY-CX23-2024-001',1,1,'Microscopio óptico para análisis de muestras','{\"aumento_max\": \"1000x\", \"oculares\": \"10x\", \"objetivos\": \"4x,10x,40x,100x\"}',3500000.00,'2024-01-15','Equipos Científicos S.A.S',24,10,NULL,NULL,'disponible','excelente','Mesa de trabajo 1',NULL,'2025-12-12 19:38:09','2025-12-12 19:38:09'),(2,'MICRO-002','QR-MICRO-002','Microscopio Óptico Binocular','Olympus','CX23','OLY-CX23-2024-002',1,1,'Microscopio óptico para análisis de muestras','{\"aumento_max\": \"1000x\", \"oculares\": \"10x\", \"objetivos\": \"4x,10x,40x,100x\"}',3500000.00,'2024-01-15','Equipos Científicos S.A.S',24,10,NULL,NULL,'reparacion','malo','Mesa de trabajo 2',NULL,'2025-12-12 19:38:09','2025-12-14 19:40:50'),(3,'MICRO-003','QR-MICRO-003','Microscopio Estereoscópico','Nikon','SMZ745','NIK-SMZ-2023-001',1,4,'Microscopio para observación de minerales','{\"aumento\": \"0.67x-5x\", \"distancia_trabajo\": \"115mm\"}',8500000.00,'2023-06-20','Nikon Colombia',36,15,NULL,NULL,'disponible','bueno','Estación mineralógica',NULL,'2025-12-12 19:38:09','2025-12-12 19:38:09'),(4,'MICRO-004','QR-MICRO-004','Microscopio Petrográfico','Leica','DM750P','LEI-DM750-2022-001',1,4,'Microscopio polarizado para petrografía','{\"polarizadores\": \"rotatorios\", \"platina\": \"circular graduada\"}',25000000.00,'2022-03-10','Leica Microsystems',36,20,NULL,NULL,'disponible','excelente','Sala de petrografía',NULL,'2025-12-12 19:38:09','2025-12-12 19:38:09'),(5,'BAL-001','QR-BAL-001','Balanza Analítica de Precisión','Mettler Toledo','ME204E','MT-ME204-2024-001',2,1,'Balanza para pesaje de precisión','{\"capacidad\": \"220g\", \"legibilidad\": \"0.1mg\", \"repetibilidad\": \"0.1mg\"}',12000000.00,'2024-02-01','Mettler Toledo Colombia',24,15,NULL,NULL,'disponible','excelente','Mesa de balanzas',NULL,'2025-12-12 19:38:09','2025-12-14 23:36:34'),(6,'BAL-002','QR-BAL-002','Balanza Analítica de Precisión','Mettler Toledo','ME204E','MT-ME204-2024-002',2,1,'Balanza para pesaje de precisión','{\"capacidad\": \"220g\", \"legibilidad\": \"0.1mg\", \"repetibilidad\": \"0.1mg\"}',12000000.00,'2024-02-01','Mettler Toledo Colombia',24,15,NULL,NULL,'disponible','bueno','Mesa de balanzas',NULL,'2025-12-12 19:38:09','2025-12-14 23:36:34'),(7,'BAL-003','QR-BAL-003','Balanza de Precisión','Ohaus','Pioneer PX224','OH-PX224-2023-001',2,5,'Balanza para análisis de suelos','{\"capacidad\": \"220g\", \"legibilidad\": \"0.1mg\"}',4500000.00,'2023-08-15','Ohaus Colombia',24,10,NULL,NULL,'disponible','bueno','Área de preparación',NULL,'2025-12-12 19:38:09','2025-12-15 17:18:37'),(8,'CENT-001','QR-CENT-001','Centrífuga de Laboratorio','Hettich','EBA 21','HET-EBA21-2024-001',3,1,'Centrífuga para separación de muestras','{\"rpm_max\": \"6000\", \"rcf_max\": \"3461xg\", \"capacidad\": \"6x15ml\"}',8000000.00,'2024-03-01','Hettich Instrumentos',24,12,NULL,NULL,'disponible','excelente','Área de centrifugación',NULL,'2025-12-12 19:38:09','2025-12-14 23:44:13'),(9,'CENT-002','QR-CENT-002','Centrífuga Refrigerada','Eppendorf','5430R','EPP-5430R-2023-001',3,2,'Centrífuga con control de temperatura','{\"rpm_max\": \"17500\", \"temperatura\": \"-10 a 40°C\", \"capacidad\": \"30x1.5ml\"}',35000000.00,'2023-05-20','Eppendorf Colombia',36,15,NULL,NULL,'disponible','excelente','Cuarto frío',NULL,'2025-12-12 19:38:09','2025-12-12 19:38:09'),(10,'ESPEC-001','QR-ESPEC-001','Espectrofotómetro UV-Vis','Thermo Scientific','Genesys 150','TS-GEN150-2024-001',4,1,'Espectrofotómetro para análisis químico','{\"rango\": \"190-1100nm\", \"ancho_banda\": \"2nm\", \"precision\": \"±0.002A\"}',28000000.00,'2024-01-20','Thermo Fisher Scientific',24,15,NULL,NULL,'disponible','excelente','Área de espectroscopía',NULL,'2025-12-12 19:38:09','2025-12-12 19:38:09'),(11,'ESPEC-002','QR-ESPEC-002','Espectrofotómetro de Absorción Atómica','Agilent','240FS AA','AGI-240FS-2022-001',4,1,'AA para análisis de metales','{\"atomizador\": \"llama\", \"elementos\": \"67\", \"precision\": \"< 1% RSD\"}',120000000.00,'2022-06-15','Agilent Technologies',36,20,NULL,NULL,'disponible','bueno','Sala de absorción atómica',NULL,'2025-12-12 19:38:09','2025-12-12 19:38:09'),(12,'PH-001','QR-PH-001','pH-metro de Mesa','Hanna Instruments','HI5221','HAN-HI5221-2024-001',5,1,'Medidor de pH de alta precisión','{\"rango_pH\": \"-2 a 20\", \"resolucion\": \"0.001\", \"precision\": \"±0.002\"}',3800000.00,'2024-02-15','Hanna Instruments',24,8,NULL,NULL,'disponible','bueno','Mesa de análisis',NULL,'2025-12-12 19:38:09','2025-12-14 20:23:59'),(13,'PH-002','QR-PH-002','pH-metro de Mesa','Hanna Instruments','HI5221','HAN-HI5221-2024-002',5,5,'Medidor de pH para análisis de suelos','{\"rango_pH\": \"-2 a 20\", \"resolucion\": \"0.001\", \"precision\": \"±0.002\"}',3800000.00,'2024-02-15','Hanna Instruments',24,8,NULL,NULL,'disponible','excelente','Área de pH',NULL,'2025-12-12 19:38:09','2025-12-12 19:38:09'),(14,'PH-003','QR-PH-003','pH-metro Portátil','Hanna Instruments','HI98190','HAN-HI98190-2023-001',5,7,'Medidor de pH portátil','{\"rango_pH\": \"0 a 14\", \"resolucion\": \"0.01\", \"IP67\": true}',2500000.00,'2023-09-10','Hanna Instruments',24,5,NULL,NULL,'prestado','bueno','Almacén portátiles',NULL,'2025-12-12 19:38:09','2025-12-12 19:38:09'),(15,'ESTUF-001','QR-ESTUF-001','Estufa de Secado','Binder','ED 115','BIN-ED115-2023-001',6,5,'Estufa para secado de muestras de suelo','{\"volumen\": \"115L\", \"temperatura_max\": \"300°C\", \"uniformidad\": \"±3°C\"}',15000000.00,'2023-04-01','Binder GmbH',24,15,NULL,NULL,'prestado','excelente','Área de secado',NULL,'2025-12-12 19:38:09','2025-12-14 22:04:15'),(16,'ESTUF-002','QR-ESTUF-002','Mufla de Alta Temperatura','Nabertherm','L9/11','NAB-L911-2022-001',6,6,'Mufla para calcinación','{\"volumen\": \"9L\", \"temperatura_max\": \"1100°C\", \"rampa\": \"programable\"}',22000000.00,'2022-08-20','Nabertherm',24,20,NULL,NULL,'prestado','bueno','Área de calcinación',NULL,'2025-12-12 19:38:09','2025-12-14 22:04:15'),(17,'MIN-001','QR-MIN-001','Trituradora de Mandíbulas','Retsch','BB 50','RET-BB50-2023-001',7,3,'Trituradora para preparación de muestras','{\"abertura\": \"40x40mm\", \"granulometria_final\": \"<0.5mm\", \"potencia\": \"750W\"}',45000000.00,'2023-02-15','Retsch GmbH',24,20,NULL,NULL,'disponible','excelente','Área de trituración',NULL,'2025-12-12 19:38:09','2025-12-12 19:38:09'),(18,'MIN-002','QR-MIN-002','Molino de Bolas','Retsch','PM 100','RET-PM100-2022-001',7,3,'Molino planetario para molienda fina','{\"velocidad_max\": \"650rpm\", \"capacidad\": \"500ml\", \"finura\": \"<1µm\"}',38000000.00,'2022-07-10','Retsch GmbH',24,15,NULL,NULL,'disponible','bueno','Área de molienda',NULL,'2025-12-12 19:38:09','2025-12-12 19:38:09'),(19,'MIN-003','QR-MIN-003','Celda de Flotación Denver','Metso','D-12','MET-D12-2021-001',7,3,'Celda de flotación para pruebas batch','{\"volumen\": \"2.5L\", \"rpm\": \"1200\", \"aireacion\": \"controlada\"}',28000000.00,'2021-11-05','Metso Outotec',24,20,NULL,NULL,'disponible','bueno','Área de flotación',NULL,'2025-12-12 19:38:09','2025-12-14 20:22:52'),(20,'SUELO-001','QR-SUELO-001','Agitador de Tamices','Retsch','AS 200','RET-AS200-2023-001',3,5,'Agitador para análisis granulométrico','{\"amplitud\": \"3mm\", \"tamices\": \"8\", \"tiempo\": \"programable\"}',18000000.00,'2023-03-20','Retsch GmbH',24,15,NULL,NULL,'dado_baja','regular','Área de granulometría','','2025-12-12 19:38:09','2025-12-15 01:04:04'),(21,'SUELO-002','QR-SUELO-002','Hidrómetro de Bouyoucos','Fisher Scientific','ASTM 152H','FS-152H-2024-001',8,5,'Hidrómetro para análisis de textura','{\"rango\": \"0-60g/L\", \"precision\": \"±0.5\"}',850000.00,'2024-01-10','Fisher Scientific',12,10,NULL,NULL,'disponible','excelente','Área de sedimentación',NULL,'2025-12-12 19:38:09','2025-12-12 19:38:09'),(22,'EQP-2A61CADA',NULL,'Balanza','kz','pphp','1239817231',NULL,6,'-----','',200000.00,'2025-12-12','',12,5,NULL,NULL,'prestado','bueno','Área de granulometría','','2025-12-12 21:53:35','2025-12-12 22:44:08'),(23,'EQP-EA2D5758',NULL,'quimico a',NULL,NULL,NULL,2,5,NULL,NULL,NULL,NULL,NULL,12,5,NULL,NULL,'disponible','bueno',NULL,NULL,'2025-12-12 22:08:00','2025-12-14 22:14:01'),(24,'EQP-0E640D1D',NULL,'KB','SAD',NULL,NULL,3,6,NULL,NULL,100000.00,'2025-12-12',NULL,12,5,NULL,NULL,'disponible','bueno',NULL,NULL,'2025-12-12 22:34:04','2025-12-12 22:34:04'),(25,'EQP-6311A703',NULL,'call of duty','SAD',NULL,NULL,7,4,NULL,NULL,100000.00,'2025-12-12',NULL,12,5,NULL,NULL,'disponible','bueno',NULL,NULL,'2025-12-12 23:25:40','2025-12-12 23:25:40'),(26,'EQP-164AB54B',NULL,'call of duty ww','SAD','asd',NULL,3,4,NULL,NULL,10000.00,'2025-12-12',NULL,12,5,NULL,NULL,'disponible','bueno',NULL,NULL,'2025-12-12 23:41:03','2025-12-12 23:41:03'),(27,'EQP-A320436F',NULL,'call of duty IIII','SAD','','',NULL,NULL,'','',100000.00,NULL,'',12,5,NULL,'648d61218278eac8ea6ab11eb0128b60','disponible','bueno','','','2025-12-12 23:46:19','2025-12-15 17:24:18'),(28,'EQP-8EC1CE0D',NULL,'AIRPORDS','APPLE','','',2,6,'','',10000.00,'2025-12-12','',12,5,'/uploads/equipos/28_92fb0e73.jpg','92fb0e73d00813d31388850a1b0c3064','disponible','excelente','','','2025-12-13 00:30:13','2025-12-15 17:28:30'),(29,'EQP-3C3E77A9',NULL,'FORROS','APPLE','','',NULL,NULL,'','',20000.00,NULL,'',12,5,NULL,'a9052598afb2e2adb7527f54068e4f4d','mantenimiento','bueno','','','2025-12-13 01:11:52','2025-12-15 17:04:00'),(30,'EQP-DA84C138',NULL,'AAAAAAAAAAAA','SAD',NULL,NULL,3,5,NULL,NULL,10000.00,'2025-12-08',NULL,12,5,NULL,NULL,'prestado','bueno',NULL,NULL,'2025-12-15 17:24:49','2025-12-15 17:25:43');
/*!40000 ALTER TABLE `equipos` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `tr_log_modificar_equipo` AFTER UPDATE ON `equipos` FOR EACH ROW BEGIN
    IF OLD.estado != NEW.estado THEN
        INSERT INTO logs_sistema (modulo, nivel_log, mensaje)
        VALUES ('equipos', 'INFO', CONCAT('Equipo ', NEW.codigo_interno, ' cambió estado: ', OLD.estado, ' -> ', NEW.estado));
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `historial_mantenimiento`
--

DROP TABLE IF EXISTS `historial_mantenimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `historial_mantenimiento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_equipo` int NOT NULL,
  `id_tipo_mantenimiento` int NOT NULL,
  `estado` enum('en_proceso','completado','cancelado') COLLATE utf8mb4_unicode_ci DEFAULT 'completado',
  `fecha_inicio` datetime NOT NULL,
  `fecha_fin` datetime DEFAULT NULL,
  `tecnico_responsable_id` int DEFAULT NULL,
  `descripcion_trabajo` text COLLATE utf8mb4_unicode_ci,
  `partes_reemplazadas` text COLLATE utf8mb4_unicode_ci,
  `costo_mantenimiento` decimal(10,2) DEFAULT NULL,
  `tiempo_inactividad_horas` decimal(5,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `estado_post_mantenimiento` enum('excelente','bueno','regular','malo') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proxima_fecha_mantenimiento` date DEFAULT NULL,
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_tipo_mantenimiento` (`id_tipo_mantenimiento`),
  KEY `tecnico_responsable_id` (`tecnico_responsable_id`),
  KEY `idx_equipo_mantenimiento` (`id_equipo`),
  KEY `idx_fecha_mantenimiento` (`fecha_inicio`),
  CONSTRAINT `historial_mantenimiento_ibfk_1` FOREIGN KEY (`id_equipo`) REFERENCES `equipos` (`id`),
  CONSTRAINT `historial_mantenimiento_ibfk_2` FOREIGN KEY (`id_tipo_mantenimiento`) REFERENCES `tipos_mantenimiento` (`id`),
  CONSTRAINT `historial_mantenimiento_ibfk_3` FOREIGN KEY (`tecnico_responsable_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historial_mantenimiento`
--

LOCK TABLES `historial_mantenimiento` WRITE;
/*!40000 ALTER TABLE `historial_mantenimiento` DISABLE KEYS */;
INSERT INTO `historial_mantenimiento` VALUES (1,1,1,'completado','2024-11-01 09:00:00','2024-11-01 09:00:00',6,'Limpieza de lentes, verificación de iluminación y ajuste de platina',NULL,150000.00,2.00,NULL,'excelente','2024-12-01','2025-12-12 19:38:09'),(2,2,1,'en_proceso','2024-11-01 11:00:00',NULL,6,'Limpieza de lentes, verificación de iluminación y ajuste de platina','',150000.00,2.00,'','malo','2024-12-01','2025-12-12 19:38:09'),(3,5,3,'completado','2024-10-15 08:00:00','2024-10-15 08:00:00',7,'Calibración con pesas patrón certificadas, ajuste de sensibilidad',NULL,350000.00,4.00,NULL,'excelente','2025-04-15','2025-12-12 19:38:09'),(5,11,3,'completado','2024-09-20 09:00:00','2024-09-20 09:00:00',7,'Calibración de longitud de onda, verificación de absorbancia',NULL,500000.00,6.00,NULL,'excelente','2025-03-20','2025-12-12 19:38:09'),(8,28,4,'completado','2025-12-14 12:40:00','2025-12-14 12:58:00',7,'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'','',100000.00,0.31,'','bueno','2025-12-29','2025-12-14 17:40:00'),(9,28,4,'completado','2025-12-14 14:32:00','2025-12-14 14:50:22',7,'fdasfsdfsdfds','',0.00,0.31,'','bueno','2025-12-29','2025-12-14 19:32:33'),(10,28,1,'completado','2025-12-14 14:34:00','2025-12-14 14:39:55',1,'sdfsdfsdfsdf','',0.00,0.10,'','regular','2026-01-13','2025-12-14 19:34:26'),(11,28,4,'completado','2025-12-14 14:36:00','2025-12-14 14:36:00',7,'dsfsdfdsfsd','',0.00,0.01,'','malo','2025-12-29','2025-12-14 19:36:24'),(12,28,4,'completado','2025-12-14 15:31:18','2025-12-14 15:36:04',7,'ASDASDAsdasdasd','',0.00,0.08,'','bueno','2025-12-29','2025-12-14 20:31:18'),(13,28,4,'completado','2025-12-14 15:53:40','2025-12-15 12:00:09',1,'asdasdasddd','',0.00,20.11,'','bueno','2025-12-30','2025-12-14 20:53:40'),(14,29,4,'en_proceso','2025-12-15 12:04:00',NULL,1,'',NULL,NULL,NULL,NULL,NULL,NULL,'2025-12-15 17:04:00'),(15,28,3,'completado','2025-12-15 12:26:45','2025-12-15 12:28:30',7,'SCZXCDDFGDFGDFG','',0.00,0.03,'','excelente','2026-03-25','2025-12-15 17:26:45');
/*!40000 ALTER TABLE `historial_mantenimiento` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `tr_crear_alerta_mantenimiento` AFTER INSERT ON `historial_mantenimiento` FOR EACH ROW BEGIN
    
    IF NEW.proxima_fecha_mantenimiento IS NOT NULL THEN
        INSERT INTO alertas_mantenimiento (id_equipo, tipo_alerta, descripcion_alerta, fecha_limite, prioridad, estado_alerta, asignado_a)
        VALUES (
            NEW.id_equipo,
            'mantenimiento_programado',
            CONCAT('Próximo mantenimiento programado para equipo'),
            NEW.proxima_fecha_mantenimiento,
            'media',
            'pendiente',
            NEW.tecnico_responsable_id
        );
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `imagenes_entrenamiento`
--

DROP TABLE IF EXISTS `imagenes_entrenamiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagenes_entrenamiento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_equipo` int NOT NULL,
  `ruta_imagen` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `angulo_captura` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'frontal',
  `resolucion` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `formato` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'jpg',
  `tamano_bytes` int DEFAULT NULL,
  `hash_imagen` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `calidad_imagen` decimal(3,2) DEFAULT NULL,
  `estado` enum('pendiente','entrenado','error') COLLATE utf8mb4_unicode_ci DEFAULT 'pendiente',
  `fecha_captura` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_equipo` (`id_equipo`),
  KEY `idx_estado` (`estado`),
  CONSTRAINT `imagenes_entrenamiento_ibfk_1` FOREIGN KEY (`id_equipo`) REFERENCES `equipos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagenes_entrenamiento`
--

LOCK TABLES `imagenes_entrenamiento` WRITE;
/*!40000 ALTER TABLE `imagenes_entrenamiento` DISABLE KEYS */;
INSERT INTO `imagenes_entrenamiento` VALUES (1,28,'/uploads/entrenamiento/EQP-8EC1CE0D/EQP-8EC1CE0D_frontal_20251212_193110_0.jpg','frontal','1403x1202','jpg',148419,'92fb0e73d00813d31388850a1b0c3064',1.00,'entrenado','2025-12-13 00:31:11'),(2,28,'/uploads/entrenamiento/EQP-8EC1CE0D/EQP-8EC1CE0D_lateral_20251212_193255_0.jpg','trasera','1600x1465','jpg',175719,'f784980660bfdfb3c2feec0c5c4b0db1',0.80,'entrenado','2025-12-13 00:32:55'),(3,28,'/uploads/entrenamiento/EQP-8EC1CE0D/EQP-8EC1CE0D_lateral_izquierda_20251212_193809_0.jpg','lateral_izquierda','829x1600','jpg',61765,'2bd51e4eceea1620bc0067382977ba6c',0.80,'entrenado','2025-12-13 00:38:10'),(4,28,'/uploads/entrenamiento/EQP-8EC1CE0D/EQP-8EC1CE0D_superior_20251212_194056_0.jpg','superior','986x672','jpg',56775,'ab09c33b0835e6c58ada13c6762f8e82',0.95,'entrenado','2025-12-13 00:40:56'),(5,28,'/uploads/entrenamiento/EQP-8EC1CE0D/EQP-8EC1CE0D_lateral_derecha_20251212_194143_0.jpg','lateral_derecha','946x1376','jpg',76360,'0240f2ec013d153fa31cb4bdf8fb8b4e',0.80,'entrenado','2025-12-13 00:41:43'),(6,29,'/uploads/entrenamiento/EQP-3C3E77A9/EQP-3C3E77A9_frontal_20251212_201240_0.jpg','frontal','834x1600','jpg',216566,'a9052598afb2e2adb7527f54068e4f4d',1.00,'entrenado','2025-12-13 01:12:40'),(7,29,'/uploads/entrenamiento/EQP-3C3E77A9/EQP-3C3E77A9_lateral_derecha_20251212_201334_0.jpg','lateral_derecha','279x1600','jpg',33962,'445ad73886983aa9ff7eb1cf5f6b0531',0.70,'entrenado','2025-12-13 01:13:34'),(8,29,'/uploads/entrenamiento/EQP-3C3E77A9/EQP-3C3E77A9_lateral_izquierda_20251212_201524_0.jpg','lateral_izquierda','294x1600','jpg',34855,'6df62d0db826d3fb7082e8326f738f85',0.70,'entrenado','2025-12-13 01:15:24'),(10,29,'/uploads/entrenamiento/EQP-3C3E77A9/EQP-3C3E77A9_frontal_20251212_201834_0.jpg','frontal','1600x708','jpg',77486,'1306fef01f68d730650880ffdb700fd0',0.80,'entrenado','2025-12-13 01:18:34'),(11,29,'/uploads/entrenamiento/EQP-3C3E77A9/EQP-3C3E77A9_trasera_20251212_202053_0.jpg','trasera','884x1600','jpg',83375,'cfe098c8f54da2c9fdd301ebb70ea2a7',0.80,'entrenado','2025-12-13 01:20:54');
/*!40000 ALTER TABLE `imagenes_entrenamiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructores`
--

DROP TABLE IF EXISTS `instructores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `especialidad` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `experiencia_anos` int DEFAULT NULL,
  `certificaciones` text COLLATE utf8mb4_unicode_ci,
  `fecha_vinculacion` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `instructores_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructores`
--

LOCK TABLES `instructores` WRITE;
/*!40000 ALTER TABLE `instructores` DISABLE KEYS */;
INSERT INTO `instructores` VALUES (1,3,'Química Analítica y Control de Calidad',8,'Certificación ISO 17025, Especialización en Análisis Instrumental','2017-02-15'),(2,4,'Procesamiento de Minerales',12,'Maestría en Ingeniería de Minas, Certificación en Flotación','2013-03-20'),(3,5,'Análisis de Suelos y Aguas',6,'Especialización en Gestión Ambiental, Certificación en Muestreo','2019-01-10');
/*!40000 ALTER TABLE `instructores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interacciones_voz`
--

DROP TABLE IF EXISTS `interacciones_voz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interacciones_voz` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int DEFAULT NULL,
  `comando_detectado` text COLLATE utf8mb4_unicode_ci,
  `intencion_identificada` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confianza_reconocimiento` decimal(3,2) DEFAULT NULL,
  `respuesta_generada` text COLLATE utf8mb4_unicode_ci,
  `accion_ejecutada` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exitosa` tinyint(1) DEFAULT '0',
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `duracion_procesamiento_ms` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_usuario` (`id_usuario`),
  KEY `idx_timestamp` (`timestamp`),
  CONSTRAINT `interacciones_voz_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=242 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interacciones_voz`
--

LOCK TABLES `interacciones_voz` WRITE;
/*!40000 ALTER TABLE `interacciones_voz` DISABLE KEYS */;
INSERT INTO `interacciones_voz` VALUES (1,9,'Lucia buscar microscopio disponible','buscar_equipo',0.95,'Encontré 3 microscopios disponibles. ¿Deseas ver los detalles?','query_equipos',1,'2025-12-12 19:38:09',245),(2,10,'Lucia estado del laboratorio de química','consultar_laboratorio',0.88,'El laboratorio de Química Analítica está disponible con capacidad para 25 personas.','query_laboratorios',1,'2025-12-12 19:38:09',312),(3,11,'Lucia préstamo balanza','solicitar_prestamo',0.92,'Hay 2 balanzas disponibles. ¿Cuál deseas solicitar?','iniciar_prestamo',1,'2025-12-12 19:38:09',198),(4,12,'Lucia alertas pendientes','consultar_alertas',0.97,'Tienes 3 alertas de mantenimiento pendientes. La más urgente es el microscopio estereoscópico.','query_alertas',1,'2025-12-12 19:38:09',156),(5,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 21:27:06',0),(6,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 21:28:36',1),(7,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 21:34:25',0),(8,1,'ayuda','ayuda',0.62,'Puedo ayudarte con las siguientes acciones:\n• Reservar equipos: \"Quiero reservar el microscopio\"\n• Ver tus reservas: \"Mostrar mis reservas\"\n• Cancelar reservas: \"Cancelar mi reserva\"\n• Consultar equipos: \"¿Está disponible el osciloscopio?\"\n• Ver inventario: \"Mostrar equipos disponibles\"\n• Información de laboratorios: \"Ver laboratorios\"\n¿Qué te gustaría hacer?',NULL,1,'2025-12-13 21:34:33',2),(9,1,'Ver inventario','listar_equipos',0.60,'Hay 10 equipos disponibles. Algunos son:\n• Agitador de Tamices (Retsch AS 200)\n• AIRPORDS (APPLE None)\n• Balanza Analítica de Precisión (Mettler Toledo ME204E)\n• Balanza Analítica de Precisión (Mettler Toledo ME204E)\n• Balanza de Precisión (Ohaus Pioneer PX224)\n...y 5 más.','mostrar_equipos',1,'2025-12-13 21:34:52',7),(10,1,'Ver laboratorios','consultar_laboratorio',0.70,'No hay laboratorios activos registrados.','mostrar_laboratorios',1,'2025-12-13 21:44:49',7),(11,1,'Ayuda','ayuda',0.62,'Puedo ayudarte con las siguientes acciones:\n• Reservar equipos: \"Quiero reservar el microscopio\"\n• Ver tus reservas: \"Mostrar mis reservas\"\n• Cancelar reservas: \"Cancelar mi reserva\"\n• Consultar equipos: \"¿Está disponible el osciloscopio?\"\n• Ver inventario: \"Mostrar equipos disponibles\"\n• Información de laboratorios: \"Ver laboratorios\"\n¿Qué te gustaría hacer?',NULL,1,'2025-12-13 21:44:57',1),(12,1,'Mostrar equipos disponibles','listar_equipos',0.94,'Hay 10 equipos disponibles. Algunos son:\n• Agitador de Tamices (Retsch AS 200)\n• AIRPORDS (APPLE None)\n• Balanza Analítica de Precisión (Mettler Toledo ME204E)\n• Balanza Analítica de Precisión (Mettler Toledo ME204E)\n• Balanza de Precisión (Ohaus Pioneer PX224)\n...y 5 más.','mostrar_equipos',1,'2025-12-13 21:45:01',7),(13,1,'Mostrar equipos disponibles','listar_equipos',0.94,'Hay 10 equipos disponibles. Algunos son:\n• Agitador de Tamices (Retsch AS 200)\n• AIRPORDS (APPLE None)\n• Balanza Analítica de Precisión (Mettler Toledo ME204E)\n• Balanza Analítica de Precisión (Mettler Toledo ME204E)\n• Balanza de Precisión (Ohaus Pioneer PX224)\n...y 5 más.','mostrar_equipos',1,'2025-12-13 21:45:19',5),(14,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 21:53:13',0),(15,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 21:53:39',0),(16,1,'Ayuda','ayuda',0.62,'Puedo ayudarte con las siguientes acciones:\n• Reservar equipos: \"Quiero reservar el microscopio\"\n• Ver tus reservas: \"Mostrar mis reservas\"\n• Cancelar reservas: \"Cancelar mi reserva\"\n• Consultar equipos: \"¿Está disponible el osciloscopio?\"\n• Ver inventario: \"Mostrar equipos disponibles\"\n• Información de laboratorios: \"Ver laboratorios\"\n¿Qué te gustaría hacer?',NULL,1,'2025-12-13 22:03:25',1),(17,1,'Mostrar equipos disponibles','listar_equipos',0.94,'Hay 10 equipos disponibles. Algunos son:\n• Agitador de Tamices (Retsch AS 200)\n• AIRPORDS (APPLE None)\n• Balanza Analítica de Precisión (Mettler Toledo ME204E)\n• Balanza Analítica de Precisión (Mettler Toledo ME204E)\n• Balanza de Precisión (Ohaus Pioneer PX224)\n...y 5 más.','mostrar_equipos',1,'2025-12-13 22:04:36',40),(18,1,'Ayuda','ayuda',0.62,'Puedo ayudarte con las siguientes acciones:\n• Reservar equipos: \"Quiero reservar el microscopio\"\n• Ver tus reservas: \"Mostrar mis reservas\"\n• Cancelar reservas: \"Cancelar mi reserva\"\n• Consultar equipos: \"¿Está disponible el osciloscopio?\"\n• Ver inventario: \"Mostrar equipos disponibles\"\n• Información de laboratorios: \"Ver laboratorios\"\n¿Qué te gustaría hacer?',NULL,1,'2025-12-13 22:04:47',1),(19,1,'Ver mis reservas','listar_reservas',0.94,'No tienes reservas activas en este momento.','mostrar_reservas',1,'2025-12-13 22:04:51',45),(20,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:15:15',0),(21,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:20:04',0),(22,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:26:52',17),(23,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:27:04',14),(24,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:27:14',22),(25,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:27:20',18),(26,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:28:06',20),(27,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:28:16',15),(28,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:28:26',16),(29,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:28:34',16),(30,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:28:43',14),(31,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:28:51',16),(32,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:29:28',18),(33,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:30:28',19),(34,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:30:58',15),(35,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:31:08',15),(36,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:31:18',18),(37,1,'hola','saludo',0.74,'¡Hola! Soy LUCIA, tu asistente virtual del laboratorio. ¿En qué puedo ayudarte hoy?',NULL,1,'2025-12-13 22:35:05',2),(38,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:35:20',22),(39,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:35:28',19),(40,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:35:32',17),(41,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:35:40',19),(42,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:35:52',21),(43,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:37:09',16),(44,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:37:17',19),(45,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:40:06',20),(46,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:40:09',17),(47,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:40:19',20),(48,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:40:26',17),(49,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:41:20',19),(50,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:42:17',19),(51,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:44:32',22),(52,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:45:36',18),(53,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:47:13',20),(54,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:47:48',19),(55,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:47:55',17),(56,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:48:06',14),(57,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:48:19',21),(58,NULL,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:49:02',9),(59,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:49:50',18),(60,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:53:00',18),(61,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 22:57:37',18),(62,1,'Mostrar equipos disponibles','listar_equipos',0.94,'Hay 10 equipos disponibles. Algunos son:\n• Agitador de Tamices (Retsch AS 200)\n• AIRPORDS (APPLE None)\n• Balanza Analítica de Precisión (Mettler Toledo ME204E)\n• Balanza Analítica de Precisión (Mettler Toledo ME204E)\n• Balanza de Precisión (Ohaus Pioneer PX224)\n...y 5 más.','mostrar_equipos',1,'2025-12-13 22:57:54',46),(63,1,'hola','saludo',0.74,'¡Hola! Soy LUCIA, tu asistente virtual del laboratorio. ¿En qué puedo ayudarte hoy?',NULL,1,'2025-12-13 23:05:11',859),(64,1,'ver equipos de moles','listar_equipos',0.70,'Hay 10 equipos disponibles. Algunos son:\n• Agitador de Tamices (Retsch AS 200)\n• AIRPORDS (APPLE None)\n• Balanza Analítica de Precisión (Mettler Toledo ME204E)\n• Balanza Analítica de Precisión (Mettler Toledo ME204E)\n• Balanza de Precisión (Ohaus Pioneer PX224)\n...y 5 más.','mostrar_equipos',1,'2025-12-13 23:05:46',596),(65,1,'reservas','listar_reservas',0.73,'No tienes reservas activas en este momento.','mostrar_reservas',1,'2025-12-13 23:06:59',682),(66,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 23:07:08',374),(67,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 23:07:16',442),(68,1,'usuarias','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:07:26',661),(69,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 23:07:40',350),(70,1,'dashboard','reporte',0.45,'📊 Resumen del sistema:\n• Equipos disponibles: 27\n• Préstamos activos: 1\n• Laboratorios activos: 0','mostrar_reporte',1,'2025-12-13 23:08:18',607),(71,1,'de export','desconocido',0.80,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:08:47',524),(72,1,'dashboard','reporte',0.45,'📊 Resumen del sistema:\n• Equipos disponibles: 27\n• Préstamos activos: 1\n• Laboratorios activos: 0','mostrar_reporte',1,'2025-12-13 23:09:04',609),(73,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 23:09:17',350),(74,1,'dashboard','reporte',0.45,'📊 Resumen del sistema:\n• Equipos disponibles: 27\n• Préstamos activos: 1\n• Laboratorios activos: 0','mostrar_reporte',1,'2025-12-13 23:09:34',560),(75,1,'reportes','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:12:12',477),(76,1,'reservas','listar_reservas',0.73,'No tienes reservas activas en este momento.','mostrar_reservas',1,'2025-12-13 23:12:24',537),(77,1,'prácticas','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:12:34',504),(78,1,'laboratorios','consultar_laboratorio',0.60,'Consultando información de laboratorios...','redirect',1,'2025-12-13 23:16:52',518),(79,1,'equipos','listar_equipos',0.67,'Consultando equipos disponibles...','redirect',1,'2025-12-13 23:17:07',483),(80,1,'prácticas','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:17:18',462),(81,1,'ir prácticas','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:17:31',563),(82,1,'prácticas de laboratorio','crear_practica',0.34,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:17:43',536),(83,1,'veinte reservas','listar_reservas',0.73,'Consultando tus reservas activas...','redirect',1,'2025-12-13 23:18:02',699),(84,1,'ir reservas','listar_reservas',0.73,'Consultando tus reservas activas...','redirect',1,'2025-12-13 23:18:14',505),(85,1,'capacitaciones','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:18:56',594),(86,1,'ir a capacitaciones','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:19:06',553),(87,1,'porque tampoco tengo roots report','listar_reservas',0.48,'Consultando tus reservas activas...','redirect',1,'2025-12-13 23:19:21',667),(88,1,'partes','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:19:33',527),(89,1,'reportes','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:19:43',585),(90,1,'usuarios','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:19:56',511),(91,1,'sesión de usuarios','desconocido',0.73,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:20:07',698),(92,1,'reales','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:20:26',457),(93,1,'roles','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:20:35',488),(94,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 23:20:44',492),(95,1,'hola','saludo',0.74,'¡Hola! Soy LUCIA, tu asistente virtual del laboratorio. ¿En qué puedo ayudarte hoy?',NULL,1,'2025-12-13 23:22:17',462),(96,1,'guzmán','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:24:03',757),(97,1,'hola','saludo',0.74,'¡Hola! Soy LUCIA, tu asistente virtual del laboratorio. ¿En qué puedo ayudarte hoy?',NULL,1,'2025-12-13 23:25:18',487),(98,1,'una of','crear_reserva',0.37,'Entendido, vamos a crear una reserva. Te llevo a la sección de reservas.','redirect',1,'2025-12-13 23:28:28',605),(99,1,'usuarios','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:28:39',655),(100,1,'ir a','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:28:51',533),(101,1,'los','listar_equipos',0.31,'Consultando equipos disponibles...','redirect',1,'2025-12-13 23:29:02',821),(102,1,'equipos','listar_equipos',0.67,'Consultando equipos disponibles...','redirect',1,'2025-12-13 23:29:13',496),(103,1,'inicio','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:29:24',462),(104,1,'y visual','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:31:30',518),(105,1,'guía visual','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:31:39',535),(106,1,'reconoce','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:31:48',448),(107,1,'reconocer equipo','crear_reserva',0.43,'Entendido, vamos a crear una reserva. Te llevo a la sección de reservas.','redirect',1,'2025-12-13 23:31:57',477),(108,1,'perfil','desconocido',0.86,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:32:15',464),(109,1,'mi perfil','cancelar_reserva',0.31,'Te llevo a la sección de reservas para cancelar.','redirect',1,'2025-12-13 23:32:44',496),(110,1,'lucía','desconocido',0.94,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:39:02',595),(111,1,'rusia','desconocido',0.94,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:39:13',605),(112,1,'lucía y','desconocido',0.94,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:39:31',504),(113,1,'rusia','desconocido',0.94,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:39:43',532),(114,1,'lucía','desconocido',0.94,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:40:37',502),(115,1,'tal vez','saludo',0.31,'¡Hola! Soy LUCIA, tu asistente virtual del laboratorio. ¿En qué puedo ayudarte hoy?',NULL,1,'2025-12-13 23:40:53',517),(116,1,'consulta','desconocido',0.94,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:41:06',469),(117,1,'lucía','desconocido',0.94,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:42:55',541),(118,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 23:43:03',321),(119,1,'la cia','desconocido',0.94,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:43:09',623),(120,1,'rusia equipos','listar_equipos',0.76,'Consultando equipos disponibles...','redirect',1,'2025-12-13 23:43:21',720),(121,1,'los mía los','desconocido',0.80,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:43:38',660),(122,1,'lucía y post','desconocido',0.94,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:43:49',577),(123,1,'rusia hipo','desconocido',0.94,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:44:05',701),(124,1,'se interpretas','desconocido',0.94,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:44:19',543),(125,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 23:44:23',300),(126,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 23:44:26',283),(127,1,'lucía','desconocido',0.94,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:44:35',522),(128,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 23:44:51',655),(129,1,'menos hola','saludo',0.50,'¡Hola! Soy LUCIA, tu asistente virtual del laboratorio. ¿En qué puedo ayudarte hoy?',NULL,1,'2025-12-13 23:44:58',772),(130,1,'ver','desconocido',0.90,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:48:03',479),(131,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 23:50:55',516),(132,1,'hola','saludo',0.57,'¡Hola! Soy LUCIA, tu asistente virtual del laboratorio. ¿En qué puedo ayudarte hoy?',NULL,1,'2025-12-13 23:51:03',453),(133,1,'hola los','desconocido',0.73,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:51:08',462),(134,1,'rusia','desconocido',0.94,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:51:14',519),(135,1,'nuevos','desconocido',0.94,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:51:20',518),(136,1,'equipos','listar_equipos',0.65,'Consultando equipos disponibles...','redirect',1,'2025-12-13 23:53:44',507),(137,1,'la cia','desconocido',0.94,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:53:56',558),(138,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 23:54:14',495),(139,1,'laboratorios','consultar_laboratorio',0.59,'Consultando información de laboratorios...','redirect',1,'2025-12-13 23:54:24',582),(140,1,'laboratorios','consultar_laboratorio',0.59,'Consultando información de laboratorios...','redirect',1,'2025-12-13 23:54:38',861),(141,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 23:54:51',439),(142,1,'laboratorios de prácticas','ir_practicas',0.47,'Abriendo prácticas de laboratorio...','redirect',1,'2025-12-13 23:54:57',593),(143,1,'prácticas de laboratorio','ir_practicas',0.82,'Abriendo prácticas de laboratorio...','redirect',1,'2025-12-13 23:55:14',733),(144,1,'lucia','desconocido',0.92,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:55:28',683),(145,1,'la mano','desconocido',0.94,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:55:38',774),(146,1,'mantenimiento preventivo','consultar_mantenimiento',0.59,'Consultando estado de mantenimientos...','redirect',1,'2025-12-13 23:55:45',629),(147,1,'hola mundo','saludo',0.57,'¡Hola! Soy LUCIA, tu asistente virtual del laboratorio. ¿En qué puedo ayudarte hoy?',NULL,1,'2025-12-13 23:56:02',524),(148,1,'laboratorios práctica','desconocido',0.75,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:56:15',855),(149,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 23:56:23',429),(150,1,'laboratorio de práctica','ir_practicas',0.63,'Abriendo prácticas de laboratorio...','redirect',1,'2025-12-13 23:56:38',597),(151,1,'los músculos','desconocido',0.81,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-13 23:56:48',622),(152,1,'','no_reconocido',0.00,'No pude entender el audio',NULL,0,'2025-12-13 23:56:57',527),(153,1,'vacía reservas','listar_reservas',0.65,'Consultando tus reservas activas...','redirect',1,'2025-12-13 23:57:03',641),(154,1,'Ver laboratorios','consultar_laboratorio',0.58,'Consultando información de laboratorios...','redirect',1,'2025-12-14 00:05:31',1),(155,1,'Mostrar equipos disponibles','listar_equipos',0.88,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:05:39',2),(156,1,'Ver mis reservas','listar_reservas',0.85,'Consultando tus reservas activas...','redirect',1,'2025-12-14 00:05:48',1),(157,1,'VER EQUIPOS','listar_equipos',0.75,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:05:58',1),(158,1,'Mostrar equipos disponibles','listar_equipos',0.88,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:06:25',1),(159,1,'Mostrar equipos disponibles','listar_equipos',0.88,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:07:08',2),(160,1,'Hola Lucía','saludo',0.57,'¡Hola! Soy LUCIA, tu asistente virtual del laboratorio. ¿En qué puedo ayudarte hoy?',NULL,1,'2025-12-14 00:11:12',2),(161,1,'Lucía equipos','listar_equipos',0.65,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:11:18',1),(162,1,'Lucía ver equipos','listar_equipos',0.75,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:11:24',2),(163,1,'redirigir a equipos','listar_equipos',0.65,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:11:34',1),(164,1,'mantenimiento preventivo','consultar_mantenimiento',0.59,'Consultando estado de mantenimientos...','redirect',1,'2025-12-14 00:11:42',1),(165,1,'ver equipos disponibles','listar_equipos',0.89,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:12:00',1),(166,1,'Lucía dirígete a equipos','listar_equipos',0.65,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:18:14',1),(167,1,'ver equipos disponibles','listar_equipos',0.94,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:22:43',1),(168,1,'Lucía ir a equipos','listar_equipos',0.80,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:23:06',2),(169,1,'Lucía ver equipos','listar_equipos',0.88,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:23:30',1),(170,1,'lucías','desconocido',0.92,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:24:46',2),(171,1,'Lucía ayuda','desconocido',0.70,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:24:49',1),(172,1,'ayuda','desconocido',0.70,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:24:56',1),(173,1,'Lucía ayuda','desconocido',0.70,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:25:02',1),(174,1,'Lucía y abisal','desconocido',0.92,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:25:12',2),(175,1,'Lucía ya visual','desconocido',0.88,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:25:25',2),(176,1,'Lucía ya visual','desconocido',0.88,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:25:26',1),(177,1,'Lucía ir usuarios','ir_usuarios',0.79,'Abriendo gestión de usuarios...','redirect',1,'2025-12-14 00:25:38',2),(178,1,'Lucía ir a','desconocido',0.89,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:25:46',1),(179,1,'Lucía ver equipos','listar_equipos',0.88,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:25:51',1),(180,1,'Lucía ir a usuarios','ir_usuarios',0.79,'Abriendo gestión de usuarios...','redirect',1,'2025-12-14 00:25:57',2),(181,1,'Hola','saludo',0.55,'¡Hola! Soy LUCIA, tu asistente virtual del laboratorio. ¿En qué puedo ayudarte hoy?',NULL,1,'2025-12-14 00:27:55',2),(182,1,'adiós','despedida',0.34,'¡Hasta luego! Fue un placer ayudarte. ¡Que tengas un excelente día!',NULL,1,'2025-12-14 00:28:09',1),(183,1,'Lucía Buscar','ir_buscador',0.33,'Abriendo el buscador de inventario...','redirect',1,'2025-12-14 00:28:29',2),(184,1,'Lucía ir a equipos','listar_equipos',0.80,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:29:12',1),(185,1,'Lucía ir a usuarios','ir_usuarios',0.79,'Abriendo gestión de usuarios...','redirect',1,'2025-12-14 00:29:51',1),(186,1,'Lucía ir a equipos','listar_equipos',0.80,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:33:35',2),(187,1,'Lucía ir a inventario','listar_equipos',0.40,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:33:44',3),(188,1,'Lucía ir a usuarios','ir_usuarios',0.79,'Abriendo gestión de usuarios...','redirect',1,'2025-12-14 00:33:57',0),(189,1,'Lucía ir a mi perfil','ir_perfil',0.55,'Abriendo tu perfil de usuario...','redirect',1,'2025-12-14 00:34:19',0),(190,1,'Lucía ir a reportes','reporte',0.77,'Abriendo reportes y estadísticas...','redirect',1,'2025-12-14 00:34:46',1),(191,1,'Lucía ir a existencia','desconocido',0.89,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:34:59',2),(192,1,'o sea ir a registro facial','ir_registro_facial',0.78,'Abriendo registro facial...','redirect',1,'2025-12-14 00:35:08',0),(193,1,'Lucía ir','desconocido',0.89,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:35:21',1),(194,1,'Lucía ir a reconocer equipo','ir_reconocimiento',0.55,'Abriendo reconocimiento de equipos con IA...','redirect',1,'2025-12-14 00:35:54',2),(195,1,'está cayendo','desconocido',0.73,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:36:04',1),(196,1,'Lucía ir a registro facial','ir_registro_facial',0.78,'Abriendo registro facial...','redirect',1,'2025-12-14 00:36:14',1),(197,1,'Lucía regresa a la página anterior','desconocido',0.83,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:37:09',1),(198,1,'Lucía ir al anterior apartado','ir_dashboard',0.41,'Abriendo el panel principal...','redirect',1,'2025-12-14 00:37:20',0),(199,1,'Lucía','desconocido',0.92,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:37:41',2),(200,1,'Lucía ir al apartado anterior','ir_dashboard',0.41,'Abriendo el panel principal...','redirect',1,'2025-12-14 00:37:47',1),(201,1,'Lucía ir al apartado anterior','ir_dashboard',0.41,'Abriendo el panel principal...','redirect',1,'2025-12-14 00:38:03',1),(202,1,'Lucía ir a configuración','ir_configuracion',0.48,'Abriendo configuración del sistema...','redirect',1,'2025-12-14 00:38:21',1),(203,1,'Lucía ir a entrenamiento ia','ir_ia_visual',0.43,'Abriendo entrenamiento de IA visual...','redirect',1,'2025-12-14 00:38:35',2),(204,1,'Lucía ir ayuda','ir_ayuda',0.41,'Abriendo centro de ayuda...','redirect',1,'2025-12-14 00:38:53',1),(205,1,'Lucía ir a roles','ir_roles',0.49,'Abriendo configuración de roles y permisos...','redirect',1,'2025-12-14 00:39:04',1),(206,1,'Lucía ir a programas','ir_programas',0.51,'Abriendo programas de formación...','redirect',1,'2025-12-14 00:39:13',1),(207,1,'Lucía ir a buscador','desconocido',0.77,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:39:37',0),(208,1,'Lucía ir a inventario','listar_equipos',0.40,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:39:46',1),(209,1,'Hola hola','saludo',0.55,'¡Hola! Soy LUCIA, tu asistente virtual del laboratorio. ¿En qué puedo ayudarte hoy?',NULL,1,'2025-12-14 00:40:15',1),(210,1,'Ver laboratorios','consultar_laboratorio',0.65,'Consultando información de laboratorios...','redirect',1,'2025-12-14 00:44:38',1),(211,1,'y la finalización de la vacuna Lucía desactívate','desconocido',0.85,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:45:13',1),(212,1,'Lucía apágate','desconocido',0.92,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:45:24',1),(213,1,'prácticas reserva','desconocido',0.75,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:45:57',2),(214,1,'capacidad','desconocido',0.92,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:46:00',0),(215,1,'Lucía apágate','apagar_microfono',0.45,'Entendido, me voy a descansar. ¡Llámame cuando me necesites! Apagando micrófono...',NULL,1,'2025-12-14 00:49:31',2),(216,1,'Lucía apágate','apagar_microfono',0.45,'Entendido, me voy a descansar. ¡Llámame cuando me necesites! Apagando micrófono...',NULL,1,'2025-12-14 00:49:45',1),(217,1,'ahí funciona apágate','desconocido',0.77,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:50:14',0),(218,1,'ahí está el mensaje','consultar_equipo',0.50,'¿Qué equipo deseas consultar? Dime el nombre del equipo.','solicitar_equipo',1,'2025-12-14 00:50:21',2),(219,1,'Lucía apágate','apagar_microfono',0.45,'Entendido, me voy a descansar. ¡Llámame cuando me necesites! Apagando micrófono...',NULL,1,'2025-12-14 00:50:31',1),(220,1,'Lucía apágate','apagar_microfono',0.45,'Entendido, me voy a descansar. ¡Llámame cuando me necesites! Apagando micrófono...',NULL,1,'2025-12-14 00:51:30',0),(221,1,'entendido me voy a','despedida',0.48,'¡Hasta luego! Fue un placer ayudarte. ¡Que tengas un excelente día!',NULL,1,'2025-12-14 00:51:33',1),(222,1,'ver equipos','listar_equipos',0.88,'Consultando equipos disponibles...','redirect',1,'2025-12-14 00:56:09',2),(223,1,'lucia ir a reservas','listar_reservas',0.78,'Consultando tus reservas activas...','redirect',1,'2025-12-14 00:57:38',1),(224,1,'está encima de la vista','desconocido',0.78,'Lo siento, no entendí tu solicitud. ¿Podrías reformularla? Di \"ayuda\" para ver las opciones disponibles.',NULL,1,'2025-12-14 00:59:15',0),(225,1,'Lucía ir asistente de Lucía','ir_asistente',0.31,'Ya estás hablando conmigo, LUCIA. ¿En qué puedo ayudarte?','redirect',1,'2025-12-14 00:59:28',2),(226,1,'hola','saludo',0.54,'¡Hola! Soy LUCIA, tu asistente virtual del laboratorio. ¿En qué puedo ayudarte hoy?',NULL,1,'2025-12-14 01:58:26',2),(227,1,'préstamos','listar_reservas',0.52,'Consultando tus reservas activas...','redirect',1,'2025-12-14 14:02:58',1),(228,1,'Lucía ir a préstamos','listar_reservas',0.47,'Consultando tus reservas activas...','redirect',1,'2025-12-14 14:03:10',0),(229,1,'Equipos disponibles','listar_equipos',0.84,'Consultando equipos disponibles...','redirect',1,'2025-12-14 15:34:09',2),(230,1,'hola','saludo',0.54,'¡Hola! Soy LUCIA, tu asistente virtual del laboratorio. ¿En qué puedo ayudarte hoy?',NULL,1,'2025-12-14 15:34:22',1),(231,1,'Lucía ir a prácticas','ir_practicas',0.55,'Abriendo prácticas de laboratorio...','redirect',1,'2025-12-14 21:01:03',2),(232,1,'Lucía ir a mantenimiento','consultar_mantenimiento',0.77,'Consultando estado de mantenimientos...','redirect',1,'2025-12-14 21:01:26',1),(233,1,'Lucía ir a inventarios de equipos','listar_equipos',0.79,'Consultando equipos disponibles...','redirect',1,'2025-12-14 21:01:42',1),(234,1,'receta de laboratorio','ir_practicas',0.46,'Abriendo prácticas de laboratorio...','redirect',1,'2025-12-14 23:56:08',2),(235,1,'capacitaciones','ir_capacitaciones',0.49,'Abriendo capacitaciones disponibles...','redirect',1,'2025-12-14 23:56:22',1),(236,1,'Lucía apágate','apagar_microfono',0.45,'Entendido, me voy a descansar. ¡Llámame cuando me necesites! Apagando micrófono...',NULL,1,'2025-12-14 23:57:47',1),(237,1,'entendido me voy a','despedida',0.48,'¡Hasta luego! Fue un placer ayudarte. ¡Que tengas un excelente día!',NULL,1,'2025-12-14 23:57:52',0),(238,1,'ver equipos','listar_equipos',0.88,'Consultando equipos disponibles...','redirect',1,'2025-12-15 19:32:22',2),(239,1,'ver mantenimiento','consultar_mantenimiento',0.68,'Consultando estado de mantenimientos...','redirect',1,'2025-12-15 19:32:32',1),(240,1,'roles','ir_roles',0.44,'Abriendo configuración de roles y permisos...','redirect',1,'2025-12-15 19:32:41',1),(241,1,'reportes','reporte',0.64,'Abriendo reportes y estadísticas...','redirect',1,'2025-12-15 19:32:53',1);
/*!40000 ALTER TABLE `interacciones_voz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `laboratorios`
--

DROP TABLE IF EXISTS `laboratorios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `laboratorios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo_lab` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('quimica','mineria','suelos','metalurgia','general') COLLATE utf8mb4_unicode_ci NOT NULL,
  `ubicacion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `capacidad_personas` int DEFAULT '20',
  `area_m2` decimal(8,2) DEFAULT NULL,
  `responsable_id` int DEFAULT NULL,
  `estado` enum('disponible','ocupado','mantenimiento','fuera_servicio') COLLATE utf8mb4_unicode_ci DEFAULT 'disponible',
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo_lab` (`codigo_lab`),
  KEY `responsable_id` (`responsable_id`),
  CONSTRAINT `laboratorios_ibfk_1` FOREIGN KEY (`responsable_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `laboratorios`
--

LOCK TABLES `laboratorios` WRITE;
/*!40000 ALTER TABLE `laboratorios` DISABLE KEYS */;
INSERT INTO `laboratorios` VALUES (1,'LAB-QUI-001','Laboratorio de Química Analítica','quimica','Bloque A - Piso 2 - Aula 201',25,80.50,1,'disponible','2025-12-12 19:38:09'),(2,'LAB-QUI-002','Laboratorio de Química Orgánica','quimica','Bloque A - Piso 2 - Aula 202',20,65.00,1,'disponible','2025-12-12 19:38:09'),(3,'LAB-MIN-001','Laboratorio de Procesamiento de Minerales','mineria','Bloque B - Piso 1 - Aula 101',30,120.00,2,'disponible','2025-12-12 19:38:09'),(4,'LAB-MIN-002','Laboratorio de Caracterización Mineralógica','mineria','Bloque B - Piso 1 - Aula 102',20,75.00,2,'ocupado','2025-12-12 19:38:09'),(5,'LAB-SUE-001','Laboratorio de Análisis de Suelos','suelos','Bloque C - Piso 1 - Aula 103',30,90.00,4,'ocupado','2025-12-12 19:38:09'),(6,'LAB-MET-001','Laboratorio de Metalurgia Extractiva','metalurgia','Bloque D - Piso 1 - Aula 104',20,100.00,4,'disponible','2025-12-12 19:38:09'),(7,'LAB-GEN-001','Laboratorio Multipropósito','general','Bloque E - Piso 1 - Aula 105',35,150.00,1,'disponible','2025-12-12 19:38:09'),(8,'LAB-SUE-003','Laboratorio de Análisis de Suelos A','suelos','Bloque C - Piso 1 - Aula 104',10,20.00,18,'disponible','2025-12-13 17:20:33'),(9,'dasdasd','asdasd','quimica',NULL,20,NULL,NULL,'disponible','2025-12-15 18:38:06');
/*!40000 ALTER TABLE `laboratorios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs_cambios`
--

DROP TABLE IF EXISTS `logs_cambios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs_cambios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tabla_afectada` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_registro` int NOT NULL,
  `campo` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_anterior` text COLLATE utf8mb4_unicode_ci,
  `valor_nuevo` text COLLATE utf8mb4_unicode_ci,
  `id_usuario` int DEFAULT NULL,
  `fecha` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `logs_cambios_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs_cambios`
--

LOCK TABLES `logs_cambios` WRITE;
/*!40000 ALTER TABLE `logs_cambios` DISABLE KEYS */;
/*!40000 ALTER TABLE `logs_cambios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs_sistema`
--

DROP TABLE IF EXISTS `logs_sistema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs_sistema` (
  `id` int NOT NULL AUTO_INCREMENT,
  `modulo` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nivel_log` enum('DEBUG','INFO','WARNING','ERROR','CRITICAL') COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensaje` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_usuario` int DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `datos_adicionales` text COLLATE utf8mb4_unicode_ci,
  `timestamp_log` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_modulo` (`modulo`),
  KEY `idx_nivel_log` (`nivel_log`),
  KEY `idx_timestamp` (`timestamp_log`),
  KEY `idx_usuario_log` (`id_usuario`),
  CONSTRAINT `logs_sistema_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs_sistema`
--

LOCK TABLES `logs_sistema` WRITE;
/*!40000 ALTER TABLE `logs_sistema` DISABLE KEYS */;
INSERT INTO `logs_sistema` VALUES (1,'autenticacion','INFO','Usuario carlos.rodriguez@sena.edu.co inició sesión exitosamente',1,'192.168.1.100',NULL,NULL,'2025-12-12 19:38:09'),(2,'prestamos','INFO','Préstamo PREST-2024-001 creado por usuario ID 9',9,'192.168.1.105',NULL,NULL,'2025-12-12 19:38:09'),(3,'mantenimiento','WARNING','Alerta de mantenimiento vencido para equipo ESTUF-002',NULL,NULL,NULL,NULL,'2025-12-12 19:38:09'),(4,'reconocimiento_voz','INFO','Comando de voz procesado exitosamente: buscar_equipo',9,'192.168.1.105',NULL,NULL,'2025-12-12 19:38:09'),(5,'reconocimiento_imagen','INFO','Equipo MICRO-001 identificado con 94% de confianza',6,'192.168.1.110',NULL,NULL,'2025-12-12 19:38:09'),(6,'sistema','INFO','Backup automático completado exitosamente',NULL,NULL,NULL,NULL,'2025-12-12 19:38:09'),(7,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-12 19:43:13'),(8,'equipos','INFO','Equipo SUELO-001 cambió estado: disponible -> prestado',NULL,NULL,NULL,NULL,'2025-12-12 21:49:42'),(9,'equipos','INFO','Equipo SUELO-001 cambió estado: prestado -> reparacion',NULL,NULL,NULL,NULL,'2025-12-12 21:50:58'),(10,'equipos','INFO','Equipo SUELO-001 cambió estado: reparacion -> disponible',NULL,NULL,NULL,NULL,'2025-12-12 21:51:18'),(11,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-12 22:21:04'),(12,'equipos','INFO','Equipo EQP-2A61CADA cambió estado: disponible -> prestado',NULL,NULL,NULL,NULL,'2025-12-12 22:37:28'),(13,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-13 03:26:45'),(14,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-13 13:41:00'),(15,'auth','INFO','Login exitoso',8,'127.0.0.1',NULL,NULL,'2025-12-13 13:42:02'),(16,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-13 13:43:07'),(17,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-13 15:04:42'),(18,'auth','INFO','Login exitoso',8,'127.0.0.1',NULL,NULL,'2025-12-13 15:05:11'),(19,'auth','WARNING','Intento de login fallido - contraseña incorrecta',1,'127.0.0.1',NULL,NULL,'2025-12-13 15:46:40'),(20,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-13 15:46:53'),(21,'auth','INFO','Login exitoso',8,'127.0.0.1',NULL,NULL,'2025-12-13 15:51:52'),(22,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-13 15:56:38'),(23,'auth','INFO','Login exitoso',8,'127.0.0.1',NULL,NULL,'2025-12-13 15:56:53'),(24,'auth','INFO','Login exitoso',8,'127.0.0.1',NULL,NULL,'2025-12-13 16:09:13'),(25,'auth','INFO','Login exitoso',8,'127.0.0.1',NULL,NULL,'2025-12-13 16:11:00'),(26,'usuarios','INFO','Usuario creado: asd as - asd asdasd',19,NULL,NULL,NULL,'2025-12-13 16:44:29'),(27,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-13 19:07:35'),(28,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-13 22:46:57'),(29,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-13 22:47:36'),(30,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-13 22:57:28'),(31,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-13 23:28:19'),(32,'auth','WARNING','Intento de login fallido - contraseña incorrecta',1,'127.0.0.1',NULL,NULL,'2025-12-13 23:53:08'),(33,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-13 23:53:34'),(34,'auth','INFO','Login exitoso',8,'127.0.0.1',NULL,NULL,'2025-12-14 02:46:02'),(35,'auth','INFO','Login exitoso',8,'127.0.0.1',NULL,NULL,'2025-12-14 03:05:49'),(36,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: disponible -> prestado',NULL,NULL,NULL,NULL,'2025-12-14 03:33:13'),(37,'equipos','INFO','Equipo EQP-A320436F cambió estado: disponible -> prestado',NULL,NULL,NULL,NULL,'2025-12-14 03:33:33'),(38,'equipos','INFO','Equipo EQP-A320436F cambió estado: prestado -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 03:33:56'),(39,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: prestado -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 03:35:26'),(40,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-14 13:28:10'),(41,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: disponible -> prestado',NULL,NULL,NULL,NULL,'2025-12-14 14:07:09'),(42,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-14 15:22:08'),(43,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: prestado -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 17:10:28'),(44,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: disponible -> mantenimiento',NULL,NULL,NULL,NULL,'2025-12-14 17:40:00'),(45,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: mantenimiento -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 17:58:53'),(46,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: disponible -> reparacion',NULL,NULL,NULL,NULL,'2025-12-14 17:59:16'),(47,'equipos','INFO','Equipo SUELO-001 cambió estado: disponible -> dado_baja',NULL,NULL,NULL,NULL,'2025-12-14 18:02:58'),(48,'equipos','INFO','Equipo MIN-003 cambió estado: disponible -> reparacion',NULL,NULL,NULL,NULL,'2025-12-14 18:40:38'),(49,'equipos','INFO','Equipo MIN-003 cambió estado: reparacion -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 19:29:13'),(50,'equipos','INFO','Equipo MIN-003 cambió estado: disponible -> reparacion',NULL,NULL,NULL,NULL,'2025-12-14 19:29:25'),(51,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: reparacion -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 19:29:48'),(52,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: disponible -> mantenimiento',NULL,NULL,NULL,NULL,'2025-12-14 19:32:33'),(53,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: mantenimiento -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 19:32:53'),(54,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: disponible -> mantenimiento',NULL,NULL,NULL,NULL,'2025-12-14 19:34:26'),(55,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: mantenimiento -> reparacion',NULL,NULL,NULL,NULL,'2025-12-14 19:34:43'),(56,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: reparacion -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 19:35:09'),(57,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: disponible -> mantenimiento',NULL,NULL,NULL,NULL,'2025-12-14 19:36:24'),(58,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: mantenimiento -> reparacion',NULL,NULL,NULL,NULL,'2025-12-14 19:36:46'),(59,'equipos','INFO','Equipo MIN-003 cambió estado: reparacion -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 19:37:04'),(60,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: reparacion -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 19:39:55'),(61,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: disponible -> reparacion',NULL,NULL,NULL,NULL,'2025-12-14 19:40:20'),(62,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: reparacion -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 19:40:37'),(63,'equipos','INFO','Equipo MICRO-002 cambió estado: disponible -> reparacion',NULL,NULL,NULL,NULL,'2025-12-14 19:40:50'),(64,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: disponible -> reparacion',NULL,NULL,NULL,NULL,'2025-12-14 19:49:32'),(65,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: reparacion -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 19:50:22'),(66,'equipos','INFO','Equipo PH-001 cambió estado: disponible -> reparacion',NULL,NULL,NULL,NULL,'2025-12-14 20:23:53'),(67,'equipos','INFO','Equipo PH-001 cambió estado: reparacion -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 20:23:59'),(68,'equipos','INFO','Equipo BAL-002 cambió estado: disponible -> reparacion',NULL,NULL,NULL,NULL,'2025-12-14 20:27:33'),(69,'equipos','INFO','Equipo BAL-002 cambió estado: reparacion -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 20:27:47'),(70,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: disponible -> mantenimiento',NULL,NULL,NULL,NULL,'2025-12-14 20:31:18'),(71,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: mantenimiento -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 20:36:04'),(72,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: disponible -> mantenimiento',NULL,NULL,NULL,NULL,'2025-12-14 20:53:40'),(73,'auth','INFO','Login exitoso',8,'127.0.0.1',NULL,NULL,'2025-12-14 21:04:16'),(74,'equipos','INFO','Equipo ESTUF-001 cambió estado: disponible -> prestado',NULL,NULL,NULL,NULL,'2025-12-14 22:04:15'),(75,'equipos','INFO','Equipo ESTUF-002 cambió estado: disponible -> prestado',NULL,NULL,NULL,NULL,'2025-12-14 22:04:15'),(76,'equipos','INFO','Equipo EQP-EA2D5758 cambió estado: disponible -> prestado',NULL,NULL,NULL,NULL,'2025-12-14 22:06:32'),(77,'equipos','INFO','Equipo BAL-003 cambió estado: disponible -> prestado',NULL,NULL,NULL,NULL,'2025-12-14 22:06:32'),(78,'equipos','INFO','Equipo EQP-EA2D5758 cambió estado: prestado -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 22:14:01'),(79,'equipos','INFO','Equipo BAL-003 cambió estado: prestado -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 22:14:01'),(80,'equipos','INFO','Equipo BAL-001 cambió estado: disponible -> prestado',NULL,NULL,NULL,NULL,'2025-12-14 22:46:46'),(81,'equipos','INFO','Equipo BAL-002 cambió estado: disponible -> prestado',NULL,NULL,NULL,NULL,'2025-12-14 22:46:46'),(82,'equipos','INFO','Equipo CENT-001 cambió estado: disponible -> prestado',NULL,NULL,NULL,NULL,'2025-12-14 23:05:01'),(83,'equipos','INFO','Equipo CENT-001 cambió estado: prestado -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 23:09:48'),(84,'equipos','INFO','Equipo BAL-003 cambió estado: disponible -> prestado',NULL,NULL,NULL,NULL,'2025-12-14 23:24:48'),(85,'equipos','INFO','Equipo EQP-A320436F cambió estado: disponible -> prestado',NULL,NULL,NULL,NULL,'2025-12-14 23:26:37'),(86,'equipos','INFO','Equipo EQP-A320436F cambió estado: prestado -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 23:27:59'),(87,'auth','INFO','Login exitoso',8,'127.0.0.1',NULL,NULL,'2025-12-14 23:31:48'),(88,'equipos','INFO','Equipo BAL-001 cambió estado: prestado -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 23:36:34'),(89,'equipos','INFO','Equipo BAL-002 cambió estado: prestado -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 23:36:34'),(90,'equipos','INFO','Equipo CENT-001 cambió estado: disponible -> prestado',NULL,NULL,NULL,NULL,'2025-12-14 23:42:16'),(91,'equipos','INFO','Equipo CENT-001 cambió estado: prestado -> disponible',NULL,NULL,NULL,NULL,'2025-12-14 23:44:13'),(92,'auth','INFO','Login exitoso',3,'127.0.0.1',NULL,NULL,'2025-12-15 00:14:43'),(93,'auth','INFO','Login exitoso',3,'127.0.0.1',NULL,NULL,'2025-12-15 00:16:01'),(94,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 00:53:22'),(95,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 00:57:31'),(96,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 00:58:25'),(97,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 00:58:42'),(98,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 00:59:18'),(99,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 01:00:44'),(100,'auth','WARNING','Intento de login fallido - contraseña incorrecta',3,'127.0.0.1',NULL,NULL,'2025-12-15 01:08:59'),(101,'auth','WARNING','Intento de login fallido - contraseña incorrecta',3,'127.0.0.1',NULL,NULL,'2025-12-15 01:09:15'),(102,'auth','INFO','Login exitoso',3,'127.0.0.1',NULL,NULL,'2025-12-15 01:09:31'),(103,'auth','WARNING','Intento de login fallido - contraseña incorrecta',3,'127.0.0.1',NULL,NULL,'2025-12-15 01:11:07'),(104,'auth','WARNING','Intento de login fallido - contraseña incorrecta',8,'127.0.0.1',NULL,NULL,'2025-12-15 01:11:20'),(105,'auth','INFO','Login exitoso',3,'127.0.0.1',NULL,NULL,'2025-12-15 01:11:32'),(106,'auth','INFO','Login exitoso',3,'127.0.0.1',NULL,NULL,'2025-12-15 01:13:09'),(107,'auth','INFO','Login exitoso',3,'127.0.0.1',NULL,NULL,'2025-12-15 01:17:42'),(108,'auth','INFO','Login exitoso',3,'127.0.0.1',NULL,NULL,'2025-12-15 01:21:03'),(109,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 10:06:37'),(110,'auth','INFO','Login exitoso',3,'127.0.0.1',NULL,NULL,'2025-12-15 10:10:12'),(111,'auth','INFO','Login exitoso',3,'127.0.0.1',NULL,NULL,'2025-12-15 10:10:55'),(112,'auth','WARNING','Intento de login fallido - contraseña incorrecta',3,'127.0.0.1',NULL,NULL,'2025-12-15 10:13:37'),(113,'auth','INFO','Login exitoso',3,'127.0.0.1',NULL,NULL,'2025-12-15 10:13:51'),(114,'auth','WARNING','Intento de login fallido - contraseña incorrecta',8,'127.0.0.1',NULL,NULL,'2025-12-15 10:16:06'),(115,'auth','WARNING','Intento de login fallido - contraseña incorrecta',8,'127.0.0.1',NULL,NULL,'2025-12-15 10:17:17'),(116,'auth','INFO','Login exitoso',9,'127.0.0.1',NULL,NULL,'2025-12-15 10:17:25'),(117,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 10:18:37'),(118,'usuarios','INFO','Usuario creado: 1118534593 - Juan Torres',20,NULL,NULL,NULL,'2025-12-15 10:19:35'),(119,'auth','INFO','Nuevo registro de usuario: 1118534593 - Juan Torres',NULL,'127.0.0.1',NULL,NULL,'2025-12-15 10:19:35'),(120,'sistema','INFO','Permisos de backups actualizados - Solo Administrador tiene acceso',NULL,'127.0.0.1',NULL,NULL,'2025-12-15 10:33:55'),(121,'sistema','INFO','Permisos de backups actualizados - Solo Administrador tiene acceso',NULL,'127.0.0.1',NULL,NULL,'2025-12-15 10:35:30'),(122,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 10:35:51'),(123,'backups','INFO','Backup creado: backup_20251215_054209.sql.gz',1,'127.0.0.1',NULL,NULL,'2025-12-15 10:42:10'),(124,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 15:25:22'),(125,'auth','INFO','Solicitud de restablecimiento de contraseña para darksss00007@gmail.com',20,'127.0.0.1',NULL,NULL,'2025-12-15 15:28:02'),(126,'auth','INFO','Contraseña restablecida exitosamente para darksss00007@gmail.com',20,'127.0.0.1',NULL,NULL,'2025-12-15 15:29:49'),(127,'auth','INFO','Login exitoso',20,'127.0.0.1',NULL,NULL,'2025-12-15 15:30:34'),(128,'auth','INFO','Solicitud de restablecimiento de contraseña para darksss00007@gmail.com',20,'127.0.0.1',NULL,NULL,'2025-12-15 15:38:58'),(129,'auth','INFO','Contraseña restablecida exitosamente para darksss00007@gmail.com',20,'127.0.0.1',NULL,NULL,'2025-12-15 15:49:50'),(130,'auth','WARNING','Intento de login fallido - contraseña incorrecta',20,'127.0.0.1',NULL,NULL,'2025-12-15 15:50:14'),(131,'auth','INFO','Login exitoso',20,'127.0.0.1',NULL,NULL,'2025-12-15 15:50:30'),(132,'auth','INFO','Login exitoso',20,'127.0.0.1',NULL,NULL,'2025-12-15 16:04:20'),(133,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 16:22:52'),(134,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 16:23:04'),(135,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 16:23:21'),(136,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 16:23:36'),(137,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 16:23:55'),(138,'auth','INFO','Login exitoso',20,'127.0.0.1',NULL,NULL,'2025-12-15 16:24:37'),(139,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 16:25:15'),(140,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 16:25:30'),(141,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 16:26:56'),(142,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 16:27:25'),(143,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 16:32:14'),(144,'auth','INFO','Login exitoso',20,'127.0.0.1',NULL,NULL,'2025-12-15 16:38:28'),(145,'auth','INFO','Login exitoso',20,'127.0.0.1',NULL,NULL,'2025-12-15 16:38:51'),(146,'auth','INFO','Login exitoso',20,'127.0.0.1',NULL,NULL,'2025-12-15 16:57:11'),(147,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: mantenimiento -> disponible',NULL,NULL,NULL,NULL,'2025-12-15 17:00:09'),(148,'equipos','INFO','Equipo EQP-3C3E77A9 cambió estado: disponible -> mantenimiento',NULL,NULL,NULL,NULL,'2025-12-15 17:04:00'),(149,'equipos','INFO','Equipo BAL-003 cambió estado: prestado -> disponible',NULL,NULL,NULL,NULL,'2025-12-15 17:18:37'),(150,'equipos','INFO','Equipo EQP-DA84C138 cambió estado: disponible -> prestado',NULL,NULL,NULL,NULL,'2025-12-15 17:25:43'),(151,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: disponible -> mantenimiento',NULL,NULL,NULL,NULL,'2025-12-15 17:26:45'),(152,'equipos','INFO','Equipo EQP-8EC1CE0D cambió estado: mantenimiento -> disponible',NULL,NULL,NULL,NULL,'2025-12-15 17:28:30'),(153,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 17:55:20'),(154,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 18:10:05'),(155,'auth','INFO','Solicitud de restablecimiento de contraseña para darksss00007@gmail.com',20,'127.0.0.1',NULL,NULL,'2025-12-15 19:05:30'),(156,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 19:09:15'),(157,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 19:21:41'),(158,'auth','INFO','Solicitud de restablecimiento de contraseña para darksss00007@gmail.com',20,'127.0.0.1',NULL,NULL,'2025-12-15 19:35:51');
/*!40000 ALTER TABLE `logs_sistema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modelos_ia`
--

DROP TABLE IF EXISTS `modelos_ia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modelos_ia` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('reconocimiento_imagenes','reconocimiento_voz','prediccion_mantenimiento') COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ruta_archivo` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `precision_modelo` decimal(5,4) DEFAULT NULL,
  `fecha_entrenamiento` date DEFAULT NULL,
  `fecha_deployment` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `estado` enum('activo','inactivo','entrenando') COLLATE utf8mb4_unicode_ci DEFAULT 'activo',
  `parametros_modelo` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modelos_ia`
--

LOCK TABLES `modelos_ia` WRITE;
/*!40000 ALTER TABLE `modelos_ia` DISABLE KEYS */;
INSERT INTO `modelos_ia` VALUES (1,'MobileNetV2-Equipos','reconocimiento_imagenes','2.1.0','/models/mobilenet_equipos_v2.h5',0.9234,'2024-10-15','2025-12-12 19:38:09','activo','{\"input_shape\": [224, 224, 3], \"classes\": 50, \"optimizer\": \"adam\"}'),(2,'Whisper-LUCIA','reconocimiento_voz','1.5.0','/models/whisper_lucia_v1.pt',0.8876,'2024-09-20','2025-12-12 19:38:09','activo','{\"language\": \"es\", \"model_size\": \"medium\", \"beam_size\": 5}'),(3,'LSTM-Mantenimiento','prediccion_mantenimiento','1.2.0','/models/lstm_maint_v1.h5',0.8542,'2024-08-10','2025-12-12 19:38:09','activo','{\"sequence_length\": 30, \"features\": 15, \"hidden_units\": 128}'),(4,'MobileNetV2','reconocimiento_imagenes','2.0','models/reconocimiento/mobilenet_equipos.h5',1.0000,'2025-12-14','2025-12-13 00:52:31','activo','{\"epochs\": 10, \"clases\": 2, \"imagenes\": 10}');
/*!40000 ALTER TABLE `modelos_ia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expira_en` datetime NOT NULL,
  `usado` tinyint(1) DEFAULT '0',
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ip_solicitud` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_token` (`token`),
  KEY `idx_expira` (`expira_en`),
  KEY `idx_usuario` (`id_usuario`),
  CONSTRAINT `password_reset_tokens_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
INSERT INTO `password_reset_tokens` VALUES (1,20,'V7pgftrUsKuqFLaneY-0GJo0G2ppJVk9wlUcDQrgUo4','darksss00007@gmail.com','2025-12-15 11:28:01',1,'2025-12-15 15:28:00','127.0.0.1'),(2,20,'AAvpArFOYXqfw-BVOBXHcrfkoMOtwz4AqRy3FwlH18s','darksss00007@gmail.com','2025-12-15 11:38:56',1,'2025-12-15 15:38:55','127.0.0.1'),(3,20,'m0KBrPy9ENxTPiT80V8MiegK2TfJiFzyEYRNLWVKcV0','darksss00007@gmail.com','2025-12-15 15:05:27',0,'2025-12-15 19:05:26','127.0.0.1'),(4,20,'o4-JEmhd-89WAMiovS-vpQ364eJZHyDQY2eGFdkBXn8','darksss00007@gmail.com','2025-12-15 15:35:48',0,'2025-12-15 19:35:48','127.0.0.1');
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `practicas_laboratorio`
--

DROP TABLE IF EXISTS `practicas_laboratorio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `practicas_laboratorio` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_programa` int NOT NULL,
  `id_laboratorio` int NOT NULL,
  `id_instructor` int NOT NULL,
  `fecha` datetime NOT NULL,
  `duracion_horas` decimal(3,1) DEFAULT NULL,
  `numero_estudiantes` int DEFAULT NULL,
  `equipos_requeridos` text COLLATE utf8mb4_unicode_ci,
  `materiales_requeridos` text COLLATE utf8mb4_unicode_ci,
  `objetivos` text COLLATE utf8mb4_unicode_ci,
  `descripcion_actividades` text COLLATE utf8mb4_unicode_ci,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `estado` enum('programada','en_curso','completada','cancelada') COLLATE utf8mb4_unicode_ci DEFAULT 'programada',
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `id_programa` (`id_programa`),
  KEY `id_instructor` (`id_instructor`),
  KEY `idx_fecha` (`fecha`),
  KEY `idx_estado` (`estado`),
  KEY `idx_laboratorio` (`id_laboratorio`),
  CONSTRAINT `practicas_laboratorio_ibfk_1` FOREIGN KEY (`id_programa`) REFERENCES `programas_formacion` (`id`),
  CONSTRAINT `practicas_laboratorio_ibfk_2` FOREIGN KEY (`id_laboratorio`) REFERENCES `laboratorios` (`id`),
  CONSTRAINT `practicas_laboratorio_ibfk_3` FOREIGN KEY (`id_instructor`) REFERENCES `instructores` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `practicas_laboratorio`
--

LOCK TABLES `practicas_laboratorio` WRITE;
/*!40000 ALTER TABLE `practicas_laboratorio` DISABLE KEYS */;
INSERT INTO `practicas_laboratorio` VALUES (1,'PRAC-QUI-001','Análisis Volumétrico: Titulaciones Ácido-Base',1,1,1,'2024-12-15 08:00:00',4.0,20,'[1,2,13,14]','Buretas, erlenmeyers, indicadores, soluciones patrón','Determinar la concentración de soluciones mediante titulación',NULL,NULL,'completada','2025-12-12 19:38:09'),(2,'PRAC-QUI-002','Espectrofotometría UV-Vis',2,1,1,'2024-12-16 08:00:00',3.0,15,'[11]','Celdas de cuarzo, soluciones estándar, micropipetas','Aplicar la ley de Beer-Lambert para cuantificación',NULL,NULL,'completada','2025-12-12 19:38:09'),(3,'PRAC-MIN-001','Preparación de Muestras Minerales',2,3,2,'2024-12-17 08:00:00',5.0,18,'[19,20]','Muestras de roca, bolsas para muestras, etiquetas','Realizar trituración y molienda de muestras minerales',NULL,NULL,'completada','2025-12-12 19:38:09'),(4,'PRAC-MIN-002','Flotación de Sulfuros',2,3,2,'2024-12-14 17:45:00',4.0,12,'[21]','Reactivos de flotación, colectores, espumantes','Separar minerales de cobre por flotación','','','completada','2025-12-12 19:38:09'),(5,'PRAC-SUE-001','Análisis Granulométrico de Suelos',3,5,3,'2024-12-19 08:00:00',4.0,22,'[22,23,7]','Tamices ASTM, cilindros de sedimentación, dispersante','Determinar la distribución de tamaño de partículas',NULL,NULL,'completada','2025-12-12 19:38:09'),(7,'0001','Laboratorio de Caracterización',4,3,1,'2025-12-14 17:55:00',2.0,20,'[5,6]','','','','','completada','2025-12-14 22:46:18'),(8,'ASas','Laboratorio de Análisis de Suelos AAA',3,6,2,'2025-12-14 17:58:00',2.0,20,'[]','','','','','completada','2025-12-14 22:54:49'),(9,'LAB-SUE-00123','Laboratorio de Caracterización Mineral',3,6,1,'2025-12-17 18:44:00',2.0,20,'[]','','','','','completada','2025-12-14 23:40:36'),(10,'123123','Laboratorio de Análisis  de adso',4,6,1,'2025-12-14 22:41:00',1.0,20,'[8]','','','','','completada','2025-12-14 23:41:57'),(11,'123123234','xxllasd',3,6,1,'2025-12-14 23:17:00',2.0,20,'[]','','','','','completada','2025-12-15 00:18:01');
/*!40000 ALTER TABLE `practicas_laboratorio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestamos`
--

DROP TABLE IF EXISTS `prestamos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prestamos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_equipo` int NOT NULL,
  `id_usuario_solicitante` int NOT NULL,
  `id_usuario_autorizador` int DEFAULT NULL,
  `fecha_solicitud` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha` datetime DEFAULT NULL,
  `fecha_devolucion_programada` datetime DEFAULT NULL,
  `fecha_devolucion_real` datetime DEFAULT NULL,
  `proposito` text COLLATE utf8mb4_unicode_ci,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `observaciones_devolucion` text COLLATE utf8mb4_unicode_ci,
  `estado` enum('solicitado','aprobado','rechazado','activo','devuelto','vencido') COLLATE utf8mb4_unicode_ci DEFAULT 'solicitado',
  `calificacion_devolucion` enum('excelente','bueno','regular','malo') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `id_equipo` (`id_equipo`),
  KEY `id_usuario_autorizador` (`id_usuario_autorizador`),
  KEY `idx_estado` (`estado`),
  KEY `idx_fecha` (`fecha`),
  KEY `idx_usuario_solicitante` (`id_usuario_solicitante`),
  CONSTRAINT `prestamos_ibfk_1` FOREIGN KEY (`id_equipo`) REFERENCES `equipos` (`id`),
  CONSTRAINT `prestamos_ibfk_2` FOREIGN KEY (`id_usuario_solicitante`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `prestamos_ibfk_3` FOREIGN KEY (`id_usuario_autorizador`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestamos`
--

LOCK TABLES `prestamos` WRITE;
/*!40000 ALTER TABLE `prestamos` DISABLE KEYS */;
INSERT INTO `prestamos` VALUES (1,'PREST-2024-001',17,9,3,'2025-12-12 19:38:09','2024-12-01 08:00:00','2024-12-01 17:00:00','2025-12-13 22:12:40','Medición de pH en campo para proyecto de análisis de aguas',NULL,'as','devuelto',NULL),(2,'PREST-2024-002',1,10,3,'2025-12-12 19:38:09','2024-12-10 09:00:00','2024-12-10 12:00:00',NULL,'Práctica de microscopía para identificación de microorganismos',NULL,NULL,'solicitado',NULL),(3,'PREST-2024-003',5,11,6,'2025-12-12 19:38:09','2024-11-25 08:00:00','2024-11-25 16:00:00',NULL,'Pesaje de muestras para análisis gravimétrico',NULL,NULL,'devuelto',NULL),(4,'PREST-2024-004',8,12,6,'2025-12-12 19:38:09','2024-11-28 10:00:00','2024-11-28 14:00:00',NULL,'Separación de fases en muestras de laboratorio',NULL,NULL,'devuelto',NULL),(5,'PREST-2024-005',11,13,3,'2025-12-12 19:38:09','2024-12-05 08:00:00','2024-12-05 17:00:00',NULL,'Análisis de concentración de soluciones',NULL,NULL,'aprobado',NULL),(6,'PREST-868124AB',28,8,1,'2025-12-14 03:06:18','2025-12-13 22:35:20','2025-12-13 15:06:00','2025-12-13 22:35:26','para uso personal','','','devuelto','excelente'),(7,'PREST-5728B52D',27,1,1,'2025-12-14 03:26:55','2025-12-13 22:33:34','2025-12-13 22:30:00','2025-12-13 22:33:56','sadas d asd','','','devuelto','excelente'),(8,'PREST-F847FEE1',28,1,1,'2025-12-14 14:05:40','2025-12-14 12:10:09','2025-12-14 09:11:00','2025-12-14 12:10:29','Uso  personal','','','devuelto','excelente'),(9,'PRAC-PRAC-SUE-002-EQ15',15,5,1,'2025-12-14 22:04:15','2024-12-20 08:00:00','2024-12-20 12:00:00',NULL,'Práctica: Determinación de pH y Conductividad Eléctrica',NULL,NULL,'activo',NULL),(10,'PRAC-PRAC-SUE-002-EQ16',16,5,1,'2025-12-14 22:04:15','2024-12-20 08:00:00','2024-12-20 12:00:00',NULL,'Práctica: Determinación de pH y Conductividad Eléctrica',NULL,NULL,'activo',NULL),(11,'PRAC-PRAC-SUE-001-EQ23',23,5,1,'2025-12-14 22:06:32','2024-12-19 08:00:00','2024-12-19 12:00:00','2025-12-14 17:14:01','Práctica: Análisis Granulométrico de Suelos',NULL,NULL,'devuelto',NULL),(12,'PRAC-PRAC-SUE-001-EQ7',7,5,1,'2025-12-14 22:06:32','2024-12-19 08:00:00','2024-12-19 12:00:00','2025-12-14 17:14:01','Práctica: Análisis Granulométrico de Suelos',NULL,NULL,'devuelto',NULL),(13,'PRAC-0001-EQ5',5,3,1,'2025-12-14 22:46:46','2025-12-14 17:55:00','2025-12-14 19:55:00','2025-12-14 18:36:34','Práctica: Laboratorio de Caracterización',NULL,NULL,'devuelto',NULL),(14,'PRAC-0001-EQ6',6,3,1,'2025-12-14 22:46:46','2025-12-14 17:55:00','2025-12-14 19:55:00','2025-12-14 18:36:34','Práctica: Laboratorio de Caracterización',NULL,NULL,'devuelto',NULL),(15,'PRAC-ASas-EQ8',8,4,1,'2025-12-14 23:05:01','2025-12-14 17:58:00','2025-12-14 19:58:00','2025-12-14 18:09:48','Práctica: Laboratorio de Análisis de Suelos AAA',NULL,NULL,'devuelto',NULL),(16,'PREST-0E766783',7,1,1,'2025-12-14 23:24:37','2025-12-14 18:27:09','2025-12-17 18:28:00','2025-12-15 12:18:38','ASDASDDADDASD','','','devuelto','excelente'),(17,'PREST-9F18AB86',27,1,1,'2025-12-14 23:26:18','2025-12-14 18:27:02','2025-12-14 22:26:00','2025-12-14 18:27:59','ASDASDASDASD','','','devuelto','bueno'),(18,'PREST-A8734EBF',27,1,1,'2025-12-14 23:31:01','2025-12-14 18:29:00','2025-12-19 18:33:00',NULL,'sdCADASDASD','ASDASDASDASD',NULL,'rechazado',NULL),(19,'PREST-003EC05F',27,8,1,'2025-12-14 23:33:14','2025-12-14 18:36:00','2025-12-16 23:38:00',NULL,'ASDASDASDASDAASDASD','DENEGADO POR',NULL,'rechazado',NULL),(20,'PRAC-123123-EQ8',8,3,1,'2025-12-14 23:42:16','2025-12-14 22:41:00','2025-12-14 23:41:00','2025-12-14 18:44:13','Práctica: Laboratorio de Análisis  de adso',NULL,NULL,'devuelto',NULL),(21,'PREST-3A6CC471',28,1,1,'2025-12-15 17:23:57','2025-12-15 12:23:57','2025-12-16 17:28:00',NULL,'ASDASDASDASDASD','ASDASDASDD',NULL,'rechazado',NULL),(22,'PREST-9A0A6810',30,1,1,'2025-12-15 17:25:37','2025-12-15 12:26:00','2025-12-17 12:28:00',NULL,'ASDASDASDASD','',NULL,'aprobado',NULL);
/*!40000 ALTER TABLE `prestamos` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `tr_prestamo_actualizar_equipo` AFTER INSERT ON `prestamos` FOR EACH ROW BEGIN
    IF NEW.estado = 'activo' OR NEW.estado = 'aprobado' THEN
        UPDATE equipos SET estado = 'prestado' WHERE id = NEW.id_equipo;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `tr_devolucion_restaurar_equipo` AFTER UPDATE ON `prestamos` FOR EACH ROW BEGIN
    IF NEW.estado = 'devuelto' AND OLD.estado != 'devuelto' THEN
        UPDATE equipos SET estado = 'disponible' WHERE id = NEW.id_equipo;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `programas_formacion`
--

DROP TABLE IF EXISTS `programas_formacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `programas_formacion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo_programa` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre_programa` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_programa` enum('tecnico','tecnologo','complementaria') COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `duracion_meses` int DEFAULT NULL,
  `estado` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci DEFAULT 'activo',
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo_programa` (`codigo_programa`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programas_formacion`
--

LOCK TABLES `programas_formacion` WRITE;
/*!40000 ALTER TABLE `programas_formacion` DISABLE KEYS */;
INSERT INTO `programas_formacion` VALUES (1,'TEC-MIN-001','Tecnología en Minería','tecnologo','Programa tecnológico en explotación minera',30,'activo'),(2,'TEC-QUI-001','Tecnología en Química','tecnologo','Programa tecnológico en análisis químico',30,'activo'),(3,'TEC-SUE-001','Tecnología en Análisis de Suelos','tecnico','Programa técnico en análisis y caracterización de suelos',19,'activo'),(4,'TEC-MET-001','Tecnología en Metalurgia','tecnologo','',30,'activo'),(5,'123123','ADSO','tecnologo','',23,'activo');
/*!40000 ALTER TABLE `programas_formacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reconocimientos_imagen`
--

DROP TABLE IF EXISTS `reconocimientos_imagen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reconocimientos_imagen` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_equipo_detectado` int DEFAULT NULL,
  `imagen_original_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confianza_deteccion` decimal(3,2) DEFAULT NULL,
  `coordenadas_deteccion` text COLLATE utf8mb4_unicode_ci,
  `id_modelo_usado` int DEFAULT NULL,
  `procesado_por_usuario` int DEFAULT NULL,
  `fecha_reconocimiento` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `validacion_manual` enum('correcto','incorrecto','pendiente') COLLATE utf8mb4_unicode_ci DEFAULT 'pendiente',
  PRIMARY KEY (`id`),
  KEY `id_equipo_detectado` (`id_equipo_detectado`),
  KEY `id_modelo_usado` (`id_modelo_usado`),
  KEY `procesado_por_usuario` (`procesado_por_usuario`),
  CONSTRAINT `reconocimientos_imagen_ibfk_1` FOREIGN KEY (`id_equipo_detectado`) REFERENCES `equipos` (`id`),
  CONSTRAINT `reconocimientos_imagen_ibfk_2` FOREIGN KEY (`id_modelo_usado`) REFERENCES `modelos_ia` (`id`),
  CONSTRAINT `reconocimientos_imagen_ibfk_3` FOREIGN KEY (`procesado_por_usuario`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reconocimientos_imagen`
--

LOCK TABLES `reconocimientos_imagen` WRITE;
/*!40000 ALTER TABLE `reconocimientos_imagen` DISABLE KEYS */;
INSERT INTO `reconocimientos_imagen` VALUES (1,1,'/uploads/reconocimiento/img_2024120901.jpg',0.94,'{\"x\": 120, \"y\": 85, \"width\": 340, \"height\": 280}',1,6,'2025-12-12 19:38:09','correcto'),(2,5,'/uploads/reconocimiento/img_2024120902.jpg',0.89,'{\"x\": 200, \"y\": 150, \"width\": 180, \"height\": 220}',1,6,'2025-12-12 19:38:09','correcto'),(3,11,'/uploads/reconocimiento/img_2024120903.jpg',0.78,'{\"x\": 50, \"y\": 30, \"width\": 400, \"height\": 350}',1,7,'2025-12-12 19:38:09','pendiente'),(4,28,'reconocimiento_20251212_195257.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 00:52:57','pendiente'),(5,28,'reconocimiento_20251212_195800.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 00:58:00','pendiente'),(6,28,'reconocimiento_20251212_195805.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 00:58:05','pendiente'),(7,28,'reconocimiento_20251212_195915.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 00:59:15','pendiente'),(8,28,'reconocimiento_20251212_200335.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 01:03:35','pendiente'),(9,28,'reconocimiento_20251212_200536.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 01:05:36','pendiente'),(10,28,'reconocimiento_20251212_200540.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 01:05:40','pendiente'),(11,28,'reconocimiento_20251212_200541.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 01:05:41','pendiente'),(12,28,'reconocimiento_20251212_200548.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 01:05:48','pendiente'),(13,28,'reconocimiento_20251212_200602.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 01:06:02','pendiente'),(14,28,'reconocimiento_20251212_200603.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 01:06:03','pendiente'),(15,28,'reconocimiento_20251212_200603.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 01:06:03','pendiente'),(16,28,'reconocimiento_20251212_200604.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 01:06:04','pendiente'),(17,28,'reconocimiento_20251212_200605.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 01:06:05','pendiente'),(18,28,'reconocimiento_20251212_200606.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 01:06:06','pendiente'),(19,28,'reconocimiento_20251212_200607.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 01:06:07','pendiente'),(20,28,'reconocimiento_20251212_200607.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 01:06:07','pendiente'),(21,28,'reconocimiento_20251212_200608.jpg',1.00,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"100.0%\"}]',1,1,'2025-12-13 01:06:08','pendiente'),(22,NULL,'reconocimiento_20251212_200951.jpg',0.70,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"70.0%\"}]',1,1,'2025-12-13 01:09:51','pendiente'),(23,NULL,'reconocimiento_20251212_201531.jpg',0.70,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"70.0%\"}]',1,1,'2025-12-13 01:15:31','pendiente'),(24,NULL,'reconocimiento_20251212_202112.jpg',0.65,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"64.5%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"35.5%\"}]',1,1,'2025-12-13 01:21:12','pendiente'),(25,NULL,'reconocimiento_20251212_202451.jpg',0.51,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"50.7%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"49.3%\"}]',1,1,'2025-12-13 01:24:51','pendiente'),(26,NULL,'reconocimiento_20251212_202518.jpg',0.51,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"50.7%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"49.3%\"}]',1,1,'2025-12-13 01:25:18','pendiente'),(27,NULL,'reconocimiento_20251212_202612.jpg',0.51,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"50.7%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"49.3%\"}]',1,1,'2025-12-13 01:26:12','pendiente'),(28,NULL,'reconocimiento_20251212_202656.jpg',0.51,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"50.7%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"49.3%\"}]',1,1,'2025-12-13 01:26:56','pendiente'),(29,NULL,'reconocimiento_20251212_202740.jpg',0.51,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"50.7%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"49.3%\"}]',1,1,'2025-12-13 01:27:40','pendiente'),(30,NULL,'reconocimiento_20251212_202937.jpg',0.63,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"63.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"37.0%\"}]',1,1,'2025-12-13 01:29:37','pendiente'),(31,NULL,'reconocimiento_20251212_203351.jpg',0.51,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"50.7%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"49.3%\"}]',1,1,'2025-12-13 01:33:51','pendiente'),(32,NULL,'reconocimiento_20251212_203410.jpg',0.51,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"50.7%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"49.3%\"}]',1,1,'2025-12-13 01:34:10','pendiente'),(33,NULL,'reconocimiento_20251212_203502.jpg',0.51,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"50.7%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"49.3%\"}]',1,1,'2025-12-13 01:35:02','pendiente'),(34,NULL,'reconocimiento_20251212_203549.jpg',0.63,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"63.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"37.0%\"}]',1,1,'2025-12-13 01:35:49','pendiente'),(35,NULL,'reconocimiento_20251212_203604.jpg',0.63,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"63.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"37.0%\"}]',1,1,'2025-12-13 01:36:04','pendiente'),(36,NULL,'reconocimiento_20251212_203658.jpg',0.51,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"50.7%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"49.3%\"}]',1,1,'2025-12-13 01:36:58','pendiente'),(37,NULL,'reconocimiento_20251212_203701.jpg',0.51,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"50.7%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"49.3%\"}]',1,1,'2025-12-13 01:37:01','pendiente'),(38,NULL,'reconocimiento_20251212_203706.jpg',0.51,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"50.7%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"49.3%\"}]',1,1,'2025-12-13 01:37:06','pendiente'),(39,NULL,'reconocimiento_20251212_203819.jpg',0.63,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"63.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"37.0%\"}]',1,1,'2025-12-13 01:38:19','pendiente'),(40,NULL,'reconocimiento_20251212_203957.jpg',0.63,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"63.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"37.0%\"}]',1,1,'2025-12-13 01:39:57','pendiente'),(41,NULL,'reconocimiento_20251212_204310.jpg',0.63,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"63.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"37.0%\"}]',1,1,'2025-12-13 01:43:10','pendiente'),(42,NULL,'reconocimiento_20251212_204344.jpg',0.63,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"63.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"37.0%\"}]',1,1,'2025-12-13 01:43:44','pendiente'),(43,NULL,'reconocimiento_20251212_204348.jpg',0.63,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"63.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"37.0%\"}]',1,1,'2025-12-13 01:43:48','pendiente'),(44,NULL,'reconocimiento_20251212_204558.jpg',0.63,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"63.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"37.0%\"}]',1,1,'2025-12-13 01:45:58','pendiente'),(45,NULL,'reconocimiento_20251212_204651.jpg',0.63,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"63.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"37.0%\"}]',1,1,'2025-12-13 01:46:51','pendiente'),(46,NULL,'reconocimiento_20251212_204834.jpg',0.63,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"63.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"37.0%\"}]',1,1,'2025-12-13 01:48:34','pendiente'),(47,NULL,'reconocimiento_20251212_204901.jpg',0.63,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"63.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"37.0%\"}]',1,1,'2025-12-13 01:49:01','pendiente'),(48,NULL,'reconocimiento_20251212_204903.jpg',0.63,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"63.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"37.0%\"}]',1,1,'2025-12-13 01:49:03','pendiente'),(49,NULL,'reconocimiento_20251212_205257.jpg',0.63,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"63.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"37.0%\"}]',1,1,'2025-12-13 01:52:57','pendiente'),(50,NULL,'reconocimiento_20251212_210939.jpg',0.55,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"55.1%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"44.9%\"}]',1,1,'2025-12-13 02:09:39','pendiente'),(51,NULL,'reconocimiento_20251212_210948.jpg',0.55,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"55.1%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"44.9%\"}]',1,1,'2025-12-13 02:09:48','pendiente'),(52,NULL,'reconocimiento_20251212_211009.jpg',0.55,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"55.1%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"44.9%\"}]',1,1,'2025-12-13 02:10:09','pendiente'),(53,NULL,'reconocimiento_20251212_211033.jpg',0.61,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"60.8%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"39.2%\"}]',1,1,'2025-12-13 02:10:33','pendiente'),(54,NULL,'reconocimiento_20251212_211035.jpg',0.61,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"60.8%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"39.2%\"}]',1,1,'2025-12-13 02:10:35','pendiente'),(55,NULL,'reconocimiento_20251212_211041.jpg',0.61,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"60.8%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"39.2%\"}]',1,1,'2025-12-13 02:10:41','pendiente'),(56,NULL,'reconocimiento_20251212_211128.jpg',0.61,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"60.8%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"39.2%\"}]',1,1,'2025-12-13 02:11:28','pendiente'),(57,NULL,'reconocimiento_20251212_211141.jpg',0.55,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"54.6%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"45.4%\"}]',1,1,'2025-12-13 02:11:41','pendiente'),(58,NULL,'reconocimiento_20251212_211202.jpg',0.77,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"77.4%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"22.6%\"}]',1,1,'2025-12-13 02:12:02','pendiente'),(59,NULL,'reconocimiento_20251212_211203.jpg',0.77,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"77.4%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"22.6%\"}]',1,1,'2025-12-13 02:12:03','pendiente'),(60,NULL,'reconocimiento_20251212_211204.jpg',0.77,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"77.4%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"22.6%\"}]',1,1,'2025-12-13 02:12:04','pendiente'),(61,NULL,'reconocimiento_20251212_211217.jpg',0.77,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"77.4%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"22.6%\"}]',1,1,'2025-12-13 02:12:17','pendiente'),(62,NULL,'reconocimiento_20251212_211242.jpg',0.77,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"77.4%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"22.6%\"}]',1,1,'2025-12-13 02:12:42','pendiente'),(63,NULL,'reconocimiento_20251212_211304.jpg',0.56,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"55.8%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"44.2%\"}]',1,1,'2025-12-13 02:13:04','pendiente'),(64,NULL,'reconocimiento_20251212_211333.jpg',0.51,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"51.1%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"48.9%\"}]',1,1,'2025-12-13 02:13:33','pendiente'),(65,NULL,'reconocimiento_20251212_211341.jpg',0.51,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"51.1%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"48.9%\"}]',1,1,'2025-12-13 02:13:41','pendiente'),(66,NULL,'reconocimiento_20251212_211406.jpg',0.51,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"51.4%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"48.6%\"}]',1,1,'2025-12-13 02:14:06','pendiente'),(67,NULL,'reconocimiento_20251212_211515.jpg',0.55,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"55.1%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"44.9%\"}]',1,1,'2025-12-13 02:15:15','pendiente'),(68,NULL,'reconocimiento_20251212_211904.jpg',0.55,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"55.1%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"44.9%\"}]',1,1,'2025-12-13 02:19:04','pendiente'),(69,NULL,'reconocimiento_20251212_211912.jpg',0.55,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"55.1%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"44.9%\"}]',1,1,'2025-12-13 02:19:12','pendiente'),(70,NULL,'reconocimiento_20251212_212029.jpg',0.55,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"55.1%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"44.9%\"}]',1,1,'2025-12-13 02:20:29','pendiente'),(71,NULL,'reconocimiento_20251212_212033.jpg',0.55,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"55.1%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"44.9%\"}]',1,1,'2025-12-13 02:20:33','pendiente'),(72,NULL,'reconocimiento_20251212_212231.jpg',0.51,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"51.4%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"48.6%\"}]',1,1,'2025-12-13 02:22:31','pendiente'),(73,NULL,'reconocimiento_20251212_212243.jpg',0.50,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"50.1%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"49.9%\"}]',1,1,'2025-12-13 02:22:43','pendiente'),(74,NULL,'reconocimiento_20251212_212312.jpg',0.18,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"18.2%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"11.8%\"}]',1,1,'2025-12-13 02:23:12','pendiente'),(75,NULL,'reconocimiento_20251212_212317.jpg',0.18,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"18.2%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"11.8%\"}]',1,1,'2025-12-13 02:23:17','pendiente'),(76,NULL,'reconocimiento_20251212_212324.jpg',0.18,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"18.2%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"11.8%\"}]',1,1,'2025-12-13 02:23:24','pendiente'),(77,NULL,'reconocimiento_20251212_212328.jpg',0.18,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"18.2%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"11.8%\"}]',1,1,'2025-12-13 02:23:28','pendiente'),(78,NULL,'reconocimiento_20251212_212338.jpg',0.18,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"18.2%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"11.8%\"}]',1,1,'2025-12-13 02:23:38','pendiente'),(79,NULL,'reconocimiento_20251212_212341.jpg',0.18,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"18.2%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"11.8%\"}]',1,1,'2025-12-13 02:23:41','pendiente'),(80,NULL,'reconocimiento_20251212_212355.jpg',0.55,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"54.6%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"45.4%\"}]',1,1,'2025-12-13 02:23:55','pendiente'),(81,NULL,'reconocimiento_20251212_212408.jpg',0.55,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"55.1%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"44.9%\"}]',1,1,'2025-12-13 02:24:08','pendiente'),(82,28,'reconocimiento_20251212_212459.jpg',0.94,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"93.9%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"6.1%\"}]',1,1,'2025-12-13 02:24:59','pendiente'),(83,28,'reconocimiento_20251212_212510.jpg',0.94,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"93.9%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"6.1%\"}]',1,1,'2025-12-13 02:25:10','pendiente'),(84,NULL,'reconocimiento_20251212_212524.jpg',0.18,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"18.5%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"11.5%\"}]',1,1,'2025-12-13 02:25:24','pendiente'),(85,NULL,'reconocimiento_20251212_212526.jpg',0.18,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"18.5%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"11.5%\"}]',1,1,'2025-12-13 02:25:26','pendiente'),(86,NULL,'reconocimiento_20251212_212527.jpg',0.18,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"18.5%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"11.5%\"}]',1,1,'2025-12-13 02:25:27','pendiente'),(87,NULL,'reconocimiento_20251212_212538.jpg',0.81,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"81.4%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"18.6%\"}]',1,1,'2025-12-13 02:25:38','pendiente'),(88,NULL,'reconocimiento_20251212_212607.jpg',0.81,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"81.4%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"18.6%\"}]',1,1,'2025-12-13 02:26:07','pendiente'),(89,29,'reconocimiento_20251212_212648.jpg',0.86,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"86.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"14.0%\"}]',1,1,'2025-12-13 02:26:48','pendiente'),(90,NULL,'reconocimiento_20251212_212709.jpg',0.29,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"28.8%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"1.2%\"}]',1,1,'2025-12-13 02:27:09','pendiente'),(91,NULL,'reconocimiento_20251212_212719.jpg',0.29,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"28.8%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"1.2%\"}]',1,1,'2025-12-13 02:27:19','pendiente'),(92,28,'reconocimiento_20251212_212735.jpg',0.96,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"96.5%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"3.5%\"}]',1,1,'2025-12-13 02:27:35','pendiente'),(93,28,'reconocimiento_20251212_212915.jpg',0.96,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"96.5%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"3.5%\"}]',1,1,'2025-12-13 02:29:15','pendiente'),(94,29,'reconocimiento_20251212_212928.jpg',0.86,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"86.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"14.0%\"}]',1,1,'2025-12-13 02:29:28','pendiente'),(95,28,'reconocimiento_20251212_213321.jpg',0.91,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"91.3%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"8.7%\"}]',1,1,'2025-12-13 02:33:21','pendiente'),(96,28,'reconocimiento_20251212_213420.jpg',0.94,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"94.3%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"5.7%\"}]',1,1,'2025-12-13 02:34:20','pendiente'),(97,NULL,'reconocimiento_20251212_214227.jpg',0.23,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"22.5%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"7.5%\"}]',1,1,'2025-12-13 02:42:27','pendiente'),(98,28,'reconocimiento_20251212_214238.jpg',0.94,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"94.3%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"5.7%\"}]',1,1,'2025-12-13 02:42:38','pendiente'),(99,28,'reconocimiento_20251212_214313.jpg',0.94,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"94.3%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"5.7%\"}]',1,1,'2025-12-13 02:43:13','pendiente'),(100,28,'reconocimiento_20251212_214319.jpg',0.94,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"94.3%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"5.7%\"}]',1,1,'2025-12-13 02:43:19','pendiente'),(101,NULL,'reconocimiento_20251213_090239.jpg',0.75,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"75.4%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"24.6%\"}]',1,1,'2025-12-13 14:02:39','pendiente'),(102,28,'reconocimiento_20251213_090344.jpg',0.97,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"97.0%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"3.0%\"}]',1,1,'2025-12-13 14:03:44','pendiente'),(103,NULL,'reconocimiento_20251213_090432.jpg',0.22,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"22.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"8.0%\"}]',1,1,'2025-12-13 14:04:32','pendiente'),(104,28,'reconocimiento_20251213_090542.jpg',0.97,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"97.0%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"3.0%\"}]',1,1,'2025-12-13 14:05:42','pendiente'),(105,NULL,'reconocimiento_20251213_110016.jpg',0.21,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"20.7%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"9.3%\"}]',1,8,'2025-12-13 16:00:16','pendiente'),(106,28,'reconocimiento_20251213_110109.jpg',0.98,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"97.9%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"2.1%\"}]',1,8,'2025-12-13 16:01:09','pendiente'),(107,29,'reconocimiento_20251213_110120.jpg',0.97,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"97.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"3.0%\"}]',1,8,'2025-12-13 16:01:20','pendiente'),(108,NULL,'reconocimiento_20251213_110136.jpg',0.28,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"28.4%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"1.6%\"}]',1,8,'2025-12-13 16:01:36','pendiente'),(109,29,'reconocimiento_20251213_110209.jpg',0.97,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"97.0%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"3.0%\"}]',1,8,'2025-12-13 16:02:09','pendiente'),(110,28,'reconocimiento_20251213_110219.jpg',0.99,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"98.8%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"1.2%\"}]',1,8,'2025-12-13 16:02:19','pendiente'),(111,NULL,'reconocimiento_20251213_153736.jpg',0.83,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"82.9%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"17.1%\"}]',1,1,'2025-12-13 20:37:36','pendiente'),(112,NULL,'reconocimiento_20251213_153741.jpg',0.83,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"82.9%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"17.1%\"}]',1,1,'2025-12-13 20:37:41','pendiente'),(113,28,'reconocimiento_20251214_084221.jpg',0.97,'[{\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"96.7%\"}, {\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"3.3%\"}]',1,1,'2025-12-14 13:42:21','pendiente'),(114,NULL,'reconocimiento_20251215_121929.jpg',0.18,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"17.9%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"12.1%\"}]',1,1,'2025-12-15 17:19:29','pendiente'),(115,NULL,'reconocimiento_20251215_121944.jpg',0.50,'[{\"codigo\": \"EQP-3C3E77A9\", \"nombre\": \"FORRO\", \"confianza\": \"50.3%\"}, {\"codigo\": \"EQP-8EC1CE0D\", \"nombre\": \"AIRPORDS\", \"confianza\": \"49.7%\"}]',1,1,'2025-12-15 17:19:44','pendiente');
/*!40000 ALTER TABLE `reconocimientos_imagen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre_rol` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `permisos` text COLLATE utf8mb4_unicode_ci,
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `estado` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci DEFAULT 'activo',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre_rol` (`nombre_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrador','Acceso completo al sistema','{\"all\": true, \"usuarios\": true, \"roles\": true, \"programas\": true, \"equipos\": true, \"laboratorios\": true, \"practicas\": true, \"reservas\": true, \"prestamos\": true, \"reportes\": true, \"mantenimiento\": true, \"capacitaciones\": true, \"reconocimiento\": true, \"ia_visual\": true, \"backups\": true, \"configuracion\": true, \"ayuda\": true}','2025-12-12 19:38:02','activo'),(2,'Instructor','Gestión de prácticas y préstamos','{\"equipos\": true, \"laboratorios_ver\": true, \"practicas\": true, \"capacitaciones\": true, \"reservas\": true, \"reportes\": true, \"reconocimiento\": true, \"ayuda\": true}','2025-12-12 19:38:02','activo'),(3,'Técnico Laboratorio','Mantenimiento y gestión de equipos','{\"equipos\": true, \"reservas\": true, \"mantenimiento\": true, \"capacitaciones_ver\": true, \"reconocimiento\": true, \"ayuda\": true}','2025-12-12 19:38:02','activo'),(4,'Aprendiz','Consulta de información y solicitud de préstamos','{\"equipos_ver\": true, \"reservas_propias\": true, \"capacitaciones_ver\": true, \"reconocimiento\": true, \"ayuda\": true}','2025-12-12 19:38:02','activo'),(5,'Coordinador','Supervisión y reportes','{\"equipos_ver\": true, \"laboratorios_ver\": true, \"capacitaciones_ver\": true, \"reservas_ver\": true, \"mantenimiento_ver\": true, \"reportes\": true, \"reconocimiento\": true, \"ayuda\": true}','2025-12-12 19:38:02','activo'),(6,'Funcionario','Solamente reportes','{}','2025-12-13 16:14:52','inactivo'),(7,'sss','asd','{}','2025-12-15 17:02:39','activo');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos_mantenimiento`
--

DROP TABLE IF EXISTS `tipos_mantenimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipos_mantenimiento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `frecuencia_dias` int DEFAULT '30',
  `es_preventivo` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos_mantenimiento`
--

LOCK TABLES `tipos_mantenimiento` WRITE;
/*!40000 ALTER TABLE `tipos_mantenimiento` DISABLE KEYS */;
INSERT INTO `tipos_mantenimiento` VALUES (1,'Mantenimiento Preventivo Mensual','Revisión general mensual del equipo',30,1),(2,'Mantenimiento Preventivo Trimestral','Mantenimiento detallado trimestral',90,1),(3,'Calibración','Calibración de precisión del equipo',100,1),(4,'Limpieza Profunda','Limpieza y desinfección completa',15,1),(5,'Mantenimiento Correctivo','Reparación por falla o avería',0,0),(6,'Revisión Anual','Inspección completa anual',365,1),(7,'Remoto','asdasdas d',30,0),(8,'mmmasd','asd',30,1);
/*!40000 ALTER TABLE `tipos_mantenimiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `documento` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombres` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidos` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_rol` int DEFAULT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ultimo_acceso` timestamp NULL DEFAULT NULL,
  `estado` enum('activo','inactivo','suspendido') COLLATE utf8mb4_unicode_ci DEFAULT 'activo',
  PRIMARY KEY (`id`),
  UNIQUE KEY `documento` (`documento`),
  UNIQUE KEY `email` (`email`),
  KEY `id_rol` (`id_rol`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'1098765432','Carlos Alberto','Rodríguez Pérez','carlos.rodriguez@sena.edu.co','3101234567',1,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09','2025-12-15 19:21:41','activo'),(2,'1087654321','María Fernanda','González López','maria.gonzalez@sena.edu.co','3112345678',1,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09',NULL,'activo'),(3,'1076543210','Juan Pablo','Martínez Ruiz','juan.martinez@sena.edu.co','3123456789',2,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09','2025-12-15 10:13:51','activo'),(4,'1065432109','Ana María','Sánchez Torres','ana.sanchez@sena.edu.co','3134567890',2,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09',NULL,'activo'),(5,'1054321098','Pedro Luis','Ramírez Castro','pedro.ramirez@sena.edu.co','3145678901',2,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09',NULL,'activo'),(6,'1043210987','Laura Patricia','Díaz Mendoza','laura.diaz@sena.edu.co','3156789012',3,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09',NULL,'activo'),(7,'1032109876','Diego Alejandro','Hernández Vargas','diego.hernandez@sena.edu.co','3167890123',3,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09',NULL,'activo'),(8,'1021098765','Sofía Valentina','López García','sofia.lopez@sena.edu.co','3178901234',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09','2025-12-14 23:31:48','activo'),(9,'1010987654','Andrés Felipes','García Muñoz','andres.garcia@sena.edu.co','3189012345',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09','2025-12-15 10:17:25','activo'),(10,'1009876543','Valentina','Moreno Jiménez','valentina.moreno@sena.edu.co','3190123456',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09',NULL,'activo'),(11,'1008765432','Santiago','Torres Rojas','santiago.torres@sena.edu.co','3201234567',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09',NULL,'activo'),(12,'1007654321','Camila Andrea','Vargas Pineda','camila.vargas@sena.edu.co','3212345678',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09',NULL,'activo'),(13,'1006543210','Daniel Esteban','Castro Silva','daniel.castro@sena.edu.co','3223456789',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09',NULL,'activo'),(14,'1005432109','Isabella','Reyes Ortiz','isabella.reyes@sena.edu.co','3234567890',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09',NULL,'activo'),(15,'1004321098','Mateo','Gutiérrez Parra','mateo.gutierrez@sena.edu.co','3245678901',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09',NULL,'activo'),(16,'1003210987','Mariana','Pineda Arias','mariana.pineda@sena.edu.co','3256789012',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09',NULL,'activo'),(17,'1002109876','Sebastián','Arias Londoño','sebastian.arias@sena.edu.co','3267890123',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09',NULL,'activo'),(18,'1001098765','Roberto Carlos','Mendoza Ríos','roberto.mendoza@sena.edu.co','3278901234',5,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-12 19:38:09',NULL,'activo'),(19,'asd as','asd','asdasd','asd','asd',1,'5fd924625f6ab16a19cc9807c7c506ae1813490e4ba675f843d5a10e0baacdb8','2025-12-13 16:44:29',NULL,'inactivo'),(20,'1118534593','Juan','Torres','darksss00007@gmail.com','3115464123',2,'$2b$12$EDSlLN37aoQBasZkrFrR0el8D21KDwn8t6KnkN6j.aK2ooaYYmYGi','2025-12-15 10:19:35','2025-12-15 16:57:11','activo');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `tr_log_crear_usuario` AFTER INSERT ON `usuarios` FOR EACH ROW BEGIN
    INSERT INTO logs_sistema (modulo, nivel_log, mensaje, id_usuario)
    VALUES ('usuarios', 'INFO', CONCAT('Usuario creado: ', NEW.documento, ' - ', NEW.nombres, ' ', NEW.apellidos), NEW.id);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `tr_actualizar_ultimo_acceso` BEFORE UPDATE ON `usuarios` FOR EACH ROW BEGIN
    IF NEW.ultimo_acceso != OLD.ultimo_acceso OR (NEW.ultimo_acceso IS NOT NULL AND OLD.ultimo_acceso IS NULL) THEN
        SET NEW.ultimo_acceso = CURRENT_TIMESTAMP;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary view structure for view `vista_alertas_pendientes`
--

DROP TABLE IF EXISTS `vista_alertas_pendientes`;
/*!50001 DROP VIEW IF EXISTS `vista_alertas_pendientes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_alertas_pendientes` AS SELECT 
 1 AS `id_alerta`,
 1 AS `codigo_interno`,
 1 AS `nombre_equipo`,
 1 AS `nombre_laboratorio`,
 1 AS `tipo_alerta`,
 1 AS `descripcion_alerta`,
 1 AS `fecha_limite`,
 1 AS `prioridad`,
 1 AS `dias_hasta_limite`,
 1 AS `asignado_a`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista_equipos_completa`
--

DROP TABLE IF EXISTS `vista_equipos_completa`;
/*!50001 DROP VIEW IF EXISTS `vista_equipos_completa`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_equipos_completa` AS SELECT 
 1 AS `id_equipo`,
 1 AS `codigo_interno`,
 1 AS `nombre_equipo`,
 1 AS `marca`,
 1 AS `modelo`,
 1 AS `nombre_categoria`,
 1 AS `nombre_laboratorio`,
 1 AS `codigo_lab`,
 1 AS `estado_equipo`,
 1 AS `estado_fisico`,
 1 AS `ubicacion_especifica`,
 1 AS `fecha_registro`,
 1 AS `usuario_actual`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista_prestamos_activos`
--

DROP TABLE IF EXISTS `vista_prestamos_activos`;
/*!50001 DROP VIEW IF EXISTS `vista_prestamos_activos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_prestamos_activos` AS SELECT 
 1 AS `id_prestamo`,
 1 AS `codigo_prestamo`,
 1 AS `codigo_interno`,
 1 AS `nombre_equipo`,
 1 AS `solicitante`,
 1 AS `fecha_prestamo`,
 1 AS `fecha_devolucion_programada`,
 1 AS `dias_restantes`,
 1 AS `estado_temporal`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'gil_laboratorios'
--
/*!50106 SET @save_time_zone= @@TIME_ZONE */ ;
/*!50106 DROP EVENT IF EXISTS `ev_limpiar_logs_antiguos` */;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `ev_limpiar_logs_antiguos` ON SCHEDULE EVERY 1 WEEK STARTS '2025-12-19 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO DELETE FROM logs_sistema WHERE fecha < DATE_SUB(CURDATE(), INTERVAL 90 DAY) */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `ev_marcar_alertas_vencidas` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `ev_marcar_alertas_vencidas` ON SCHEDULE EVERY 1 DAY STARTS '2025-12-13 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO UPDATE alertas_mantenimiento
    SET tipo_alerta = 'mantenimiento_vencido',
        prioridad = 'critica'
    WHERE estado_alerta = 'pendiente'
        AND fecha_limite < CURDATE()
        AND tipo_alerta != 'mantenimiento_vencido' */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
DELIMITER ;
/*!50106 SET TIME_ZONE= @save_time_zone */ ;

--
-- Dumping routines for database 'gil_laboratorios'
--
/*!50003 DROP FUNCTION IF EXISTS `fn_dias_proximo_mantenimiento` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_dias_proximo_mantenimiento`(p_equipo_id INT) RETURNS int
    DETERMINISTIC
BEGIN
    DECLARE v_proxima_fecha DATE;
    DECLARE v_dias INT;
    
    SELECT MIN(fecha_limite) INTO v_proxima_fecha
    FROM alertas_mantenimiento
    WHERE id_equipo = p_equipo_id
        AND estado_alerta = 'pendiente'
        AND fecha_limite >= CURDATE();
    
    IF v_proxima_fecha IS NULL THEN
        SET v_dias = -1;
    ELSE
        SET v_dias = DATEDIFF(v_proxima_fecha, CURDATE());
    END IF;
    
    RETURN v_dias;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `fn_laboratorio_disponible` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_laboratorio_disponible`(p_laboratorio_id INT, p_fecha DATETIME, p_duracion_horas INT) RETURNS tinyint(1)
    DETERMINISTIC
BEGIN
    DECLARE v_conflictos INT;
    DECLARE v_fecha_fin DATETIME;
    
    SET v_fecha_fin = DATE_ADD(p_fecha, INTERVAL p_duracion_horas HOUR);
    
    SELECT COUNT(*) INTO v_conflictos
    FROM practicas_laboratorio
    WHERE id_laboratorio = p_laboratorio_id
        AND estado IN ('programada', 'en_progreso')
        AND (
            (fecha <= p_fecha AND DATE_ADD(fecha, INTERVAL duracion_horas HOUR) > p_fecha)
            OR (fecha < v_fecha_fin AND DATE_ADD(fecha, INTERVAL duracion_horas HOUR) >= v_fecha_fin)
            OR (fecha >= p_fecha AND DATE_ADD(fecha, INTERVAL duracion_horas HOUR) <= v_fecha_fin)
        );
    
    RETURN v_conflictos = 0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_alertas_vencidas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_alertas_vencidas`()
BEGIN
    SELECT 
        a.id,
        e.codigo_interno,
        e.nombre AS equipo,
        a.tipo_alerta,
        a.descripcion_alerta,
        a.fecha_limite,
        a.prioridad,
        DATEDIFF(CURDATE(), a.fecha_limite) AS dias_vencido,
        CONCAT(u.nombres, ' ', u.apellidos) AS tecnico_asignado
    FROM alertas_mantenimiento a
    JOIN equipos e ON a.id_equipo = e.id
    LEFT JOIN usuarios u ON a.asignado_a = u.id
    WHERE a.estado_alerta = 'pendiente'
        AND a.fecha_limite < CURDATE()
    ORDER BY a.fecha_limite ASC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_buscar_equipos_disponibles` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_buscar_equipos_disponibles`(
    IN p_categoria_id INT,
    IN p_laboratorio_id INT
)
BEGIN
    SELECT 
        e.id,
        e.codigo_interno,
        e.nombre,
        e.marca,
        e.modelo,
        c.nombre AS categoria,
        l.nombre AS laboratorio,
        e.estado_fisico,
        e.ubicacion_especifica
    FROM equipos e
    LEFT JOIN categorias_equipos c ON e.id_categoria = c.id
    LEFT JOIN laboratorios l ON e.id_laboratorio = l.id
    WHERE e.estado = 'disponible'
        AND (p_categoria_id IS NULL OR e.id_categoria = p_categoria_id)
        AND (p_laboratorio_id IS NULL OR e.id_laboratorio = p_laboratorio_id)
    ORDER BY e.nombre;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_obtener_estadisticas_dashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_obtener_estadisticas_dashboard`()
BEGIN
    SELECT 
        (SELECT COUNT(*) FROM equipos WHERE estado = 'disponible') AS equipos_disponibles,
        (SELECT COUNT(*) FROM equipos WHERE estado = 'prestado') AS equipos_prestados,
        (SELECT COUNT(*) FROM equipos WHERE estado = 'mantenimiento') AS equipos_mantenimiento,
        (SELECT COUNT(*) FROM prestamos WHERE estado = 'activo') AS prestamos_activos,
        (SELECT COUNT(*) FROM alertas_mantenimiento WHERE estado_alerta = 'pendiente') AS alertas_pendientes,
        (SELECT COUNT(*) FROM practicas_laboratorio WHERE fecha >= CURDATE() AND estado = 'programada') AS practicas_programadas,
        (SELECT COUNT(*) FROM usuarios WHERE estado = 'activo') AS usuarios_activos,
        (SELECT COUNT(*) FROM laboratorios WHERE estado = 'disponible') AS laboratorios_disponibles;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_procesar_devolucion` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_procesar_devolucion`(
    IN p_prestamo_id INT,
    IN p_observaciones TEXT,
    IN p_estado_devolucion VARCHAR(20),
    OUT p_resultado INT,
    OUT p_mensaje VARCHAR(255)
)
BEGIN
    DECLARE v_estado_prestamo VARCHAR(20);
    
    
    SELECT estado INTO v_estado_prestamo FROM prestamos WHERE id = p_prestamo_id;
    
    IF v_estado_prestamo IS NULL THEN
        SET p_resultado = 0;
        SET p_mensaje = 'Préstamo no encontrado';
    ELSEIF v_estado_prestamo = 'devuelto' THEN
        SET p_resultado = 0;
        SET p_mensaje = 'Este préstamo ya fue devuelto';
    ELSE
        
        UPDATE prestamos 
        SET estado = 'devuelto',
            fecha_devolucion_real = NOW(),
            observaciones = p_observaciones,
            estado_devolucion = p_estado_devolucion
        WHERE id = p_prestamo_id;
        
        SET p_resultado = 1;
        SET p_mensaje = 'Devolución procesada exitosamente';
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_registrar_prestamo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_registrar_prestamo`(
    IN p_equipo_id INT,
    IN p_usuario_solicitante INT,
    IN p_usuario_autorizador INT,
    IN p_proposito VARCHAR(255),
    IN p_horas_prestamo INT,
    OUT p_resultado INT,
    OUT p_mensaje VARCHAR(255)
)
BEGIN
    DECLARE v_estado_equipo VARCHAR(20);
    DECLARE v_codigo_prestamo VARCHAR(50);
    
    
    SELECT estado INTO v_estado_equipo FROM equipos WHERE id = p_equipo_id;
    
    IF v_estado_equipo IS NULL THEN
        SET p_resultado = 0;
        SET p_mensaje = 'Equipo no encontrado';
    ELSEIF v_estado_equipo != 'disponible' THEN
        SET p_resultado = 0;
        SET p_mensaje = CONCAT('Equipo no disponible. Estado actual: ', v_estado_equipo);
    ELSE
        
        SET v_codigo_prestamo = CONCAT('PREST-', DATE_FORMAT(NOW(), '%Y%m%d'), '-', LPAD(FLOOR(RAND() * 10000), 4, '0'));
        
        
        INSERT INTO prestamos (codigo, id_equipo, id_usuario_solicitante, id_usuario_autorizador, fecha, fecha_devolucion_programada, proposito, estado)
        VALUES (
            v_codigo_prestamo,
            p_equipo_id,
            p_usuario_solicitante,
            p_usuario_autorizador,
            NOW(),
            DATE_ADD(NOW(), INTERVAL p_horas_prestamo HOUR),
            p_proposito,
            'activo'
        );
        
        SET p_resultado = 1;
        SET p_mensaje = CONCAT('Préstamo registrado exitosamente. Código: ', v_codigo_prestamo);
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `vista_alertas_pendientes`
--

/*!50001 DROP VIEW IF EXISTS `vista_alertas_pendientes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_alertas_pendientes` AS select `a`.`id` AS `id_alerta`,`e`.`codigo_interno` AS `codigo_interno`,`e`.`nombre` AS `nombre_equipo`,`l`.`nombre` AS `nombre_laboratorio`,`a`.`tipo_alerta` AS `tipo_alerta`,`a`.`descripcion_alerta` AS `descripcion_alerta`,`a`.`fecha_limite` AS `fecha_limite`,`a`.`prioridad` AS `prioridad`,(to_days(`a`.`fecha_limite`) - to_days(now())) AS `dias_hasta_limite`,concat(`u`.`nombres`,' ',`u`.`apellidos`) AS `asignado_a` from (((`alertas_mantenimiento` `a` join `equipos` `e` on((`a`.`id_equipo` = `e`.`id`))) left join `laboratorios` `l` on((`e`.`id_laboratorio` = `l`.`id`))) left join `usuarios` `u` on((`a`.`asignado_a` = `u`.`id`))) where (`a`.`estado_alerta` = 'pendiente') order by `a`.`prioridad` desc,`a`.`fecha_limite` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_equipos_completa`
--

/*!50001 DROP VIEW IF EXISTS `vista_equipos_completa`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_equipos_completa` AS select `e`.`id` AS `id_equipo`,`e`.`codigo_interno` AS `codigo_interno`,`e`.`nombre` AS `nombre_equipo`,`e`.`marca` AS `marca`,`e`.`modelo` AS `modelo`,`c`.`nombre` AS `nombre_categoria`,`l`.`nombre` AS `nombre_laboratorio`,`l`.`codigo_lab` AS `codigo_lab`,`e`.`estado` AS `estado_equipo`,`e`.`estado_fisico` AS `estado_fisico`,`e`.`ubicacion_especifica` AS `ubicacion_especifica`,`e`.`fecha_registro` AS `fecha_registro`,(case when (`e`.`estado` = 'prestado') then (select concat(`u`.`nombres`,' ',`u`.`apellidos`) from (`prestamos` `p` join `usuarios` `u` on((`p`.`id_usuario_solicitante` = `u`.`id`))) where ((`p`.`id_equipo` = `e`.`id`) and (`p`.`estado` = 'activo')) order by `p`.`fecha_solicitud` desc limit 1) else NULL end) AS `usuario_actual` from ((`equipos` `e` left join `categorias_equipos` `c` on((`e`.`id_categoria` = `c`.`id`))) left join `laboratorios` `l` on((`e`.`id_laboratorio` = `l`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_prestamos_activos`
--

/*!50001 DROP VIEW IF EXISTS `vista_prestamos_activos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_prestamos_activos` AS select `p`.`id` AS `id_prestamo`,`p`.`codigo` AS `codigo_prestamo`,`e`.`codigo_interno` AS `codigo_interno`,`e`.`nombre` AS `nombre_equipo`,concat(`u`.`nombres`,' ',`u`.`apellidos`) AS `solicitante`,`p`.`fecha` AS `fecha_prestamo`,`p`.`fecha_devolucion_programada` AS `fecha_devolucion_programada`,(to_days(`p`.`fecha_devolucion_programada`) - to_days(now())) AS `dias_restantes`,(case when (`p`.`fecha_devolucion_programada` < now()) then 'VENCIDO' when ((to_days(`p`.`fecha_devolucion_programada`) - to_days(now())) <= 1) then 'POR_VENCER' else 'VIGENTE' end) AS `estado_temporal` from ((`prestamos` `p` join `equipos` `e` on((`p`.`id_equipo` = `e`.`id`))) join `usuarios` `u` on((`p`.`id_usuario_solicitante` = `u`.`id`))) where (`p`.`estado` = 'activo') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-15 14:41:25
