-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: gil_laboratorios
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alertas_mantenimiento`
--

DROP TABLE IF EXISTS `alertas_mantenimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alertas_mantenimiento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_equipo` int NOT NULL,
  `tipo_alerta` enum('mantenimiento_programado','mantenimiento_vencido','falla_predicha','revision_urgente') COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion_alerta` text COLLATE utf8mb4_unicode_ci,
  `fecha_alerta` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_limite` date DEFAULT NULL,
  `prioridad` enum('baja','media','alta','critica') COLLATE utf8mb4_unicode_ci DEFAULT 'media',
  `estado_alerta` enum('pendiente','en_proceso','resuelta','cancelada') COLLATE utf8mb4_unicode_ci DEFAULT 'pendiente',
  `asignado_a` int DEFAULT NULL,
  `fecha_resolucion` datetime DEFAULT NULL,
  `observaciones_resolucion` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `id_equipo` (`id_equipo`),
  KEY `asignado_a` (`asignado_a`),
  KEY `idx_estado_alerta` (`estado_alerta`),
  KEY `idx_prioridad` (`prioridad`),
  KEY `idx_fecha_limite` (`fecha_limite`),
  CONSTRAINT `alertas_mantenimiento_ibfk_1` FOREIGN KEY (`id_equipo`) REFERENCES `equipos` (`id`),
  CONSTRAINT `alertas_mantenimiento_ibfk_2` FOREIGN KEY (`asignado_a`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alertas_mantenimiento`
--

LOCK TABLES `alertas_mantenimiento` WRITE;
/*!40000 ALTER TABLE `alertas_mantenimiento` DISABLE KEYS */;
INSERT INTO `alertas_mantenimiento` VALUES (1,1,'mantenimiento_programado','Mantenimiento preventivo mensual programado para microscopio','2025-12-15 23:48:39','2024-12-15','media','pendiente',6,NULL,NULL),(2,2,'mantenimiento_programado','Mantenimiento preventivo mensual programado para microscopio','2025-12-15 23:48:39','2024-12-15','media','pendiente',6,NULL,NULL),(3,12,'mantenimiento_programado','Limpieza mensual de quemador y nebulizador del AA','2025-12-15 23:48:39','2024-12-20','alta','pendiente',7,NULL,NULL),(4,3,'revision_urgente','Se detectó desalineación en el sistema óptico durante última práctica','2025-12-15 23:48:39','2024-12-10','critica','en_proceso',6,NULL,NULL),(5,21,'mantenimiento_vencido','Calibración de temperatura vencida hace 15 días','2025-12-15 23:48:39','2024-11-25','alta','pendiente',7,NULL,NULL);
/*!40000 ALTER TABLE `alertas_mantenimiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capacitaciones`
--

DROP TABLE IF EXISTS `capacitaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `capacitaciones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titulo` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `tipo_capacitacion` enum('modulo_formativo','taller','material_didactico','gestion_cambio') COLLATE utf8mb4_unicode_ci DEFAULT 'taller',
  `producto` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `medicion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cantidad_meta` int DEFAULT NULL,
  `cantidad_actual` int DEFAULT '0',
  `actividad` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `porcentaje_avance` decimal(5,2) DEFAULT '0.00',
  `recursos_asociados` text COLLATE utf8mb4_unicode_ci,
  `participantes` text COLLATE utf8mb4_unicode_ci,
  `duracion_horas` int DEFAULT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `estado` enum('programada','activo','finalizada','cancelada') COLLATE utf8mb4_unicode_ci DEFAULT 'programada',
  `id_instructor` int DEFAULT NULL,
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_instructor` (`id_instructor`),
  CONSTRAINT `capacitaciones_ibfk_1` FOREIGN KEY (`id_instructor`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capacitaciones`
--

LOCK TABLES `capacitaciones` WRITE;
/*!40000 ALTER TABLE `capacitaciones` DISABLE KEYS */;
INSERT INTO `capacitaciones` VALUES (1,'Módulo Formativo: Inteligencia Artificial Aplicada','Capacitación en uso de herramientas de IA para gestión de laboratorios','modulo_formativo','Instructores capacitados en IA','Número de instructores',15,12,'Talleres teórico-prácticos sobre IA',80.00,NULL,NULL,40,'2024-08-01','2024-08-31','',3,'2025-12-15 23:48:39'),(2,'Taller: Reconocimiento de Imágenes con MobileNet','Taller práctico sobre implementación de reconocimiento de equipos','taller','Sistema de reconocimiento implementado','Equipos registrados',50,28,'Entrenamiento del modelo MobileNet',56.00,NULL,NULL,16,'2024-09-01','2024-09-15','',4,'2025-12-15 23:48:39'),(3,'Material Didáctico: Guías de Uso del Sistema','Creación de material didáctico para usuarios del sistema','material_didactico','Guías digitales publicadas','Número de guías',10,7,'Diseño y redacción de guías',70.00,NULL,NULL,24,'2024-09-10','2024-10-10','',3,'2025-12-15 23:48:39'),(4,'Gestión del Cambio: Adopción del Sistema GIL','Programa de gestión del cambio para adopción del nuevo sistema','gestion_cambio','Personal capacitado','Porcentaje de adopción',100,85,'Sesiones de sensibilización y capacitación',85.00,NULL,NULL,32,'2024-08-15','2024-11-15','',5,'2025-12-15 23:48:39'),(5,'Módulo Formativo: Mantenimiento Predictivo','Capacitación en técnicas de mantenimiento predictivo con ML','modulo_formativo','Técnicos certificados','Número de técnicos',8,6,'Curso de machine learning aplicado',75.00,NULL,NULL,48,'2024-10-01','2024-11-30','',4,'2025-12-15 23:48:39'),(6,'Taller: Comandos de Voz con LUCIA','Taller sobre uso efectivo del asistente de voz','taller','Usuarios entrenados','Número de usuarios',30,30,'Sesiones prácticas con LUCIA',100.00,NULL,NULL,8,'2024-09-20','2024-09-25','',3,'2025-12-15 23:48:39'),(7,'Material Didáctico: Videos Tutoriales','Producción de videos tutoriales para el sistema','material_didactico','Videos publicados','Número de videos',15,9,'Grabación y edición de tutoriales',60.00,NULL,NULL,40,'2024-10-15','2024-12-15','',5,'2025-12-15 23:48:39'),(8,'Gestión del Cambio: Cultura de Innovación','Programa para fomentar cultura de innovación tecnológica','gestion_cambio','Eventos realizados','Número de eventos',6,4,'Charlas y talleres motivacionales',66.67,NULL,NULL,20,'2024-09-01','2024-12-31','',3,'2025-12-15 23:48:39');
/*!40000 ALTER TABLE `capacitaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias_equipos`
--

DROP TABLE IF EXISTS `categorias_equipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorias_equipos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `codigo` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias_equipos`
--

LOCK TABLES `categorias_equipos` WRITE;
/*!40000 ALTER TABLE `categorias_equipos` DISABLE KEYS */;
INSERT INTO `categorias_equipos` VALUES (1,'Microscopios','Equipos de observación y análisis microscópico','MICRO','2025-12-15 23:35:15'),(2,'Balanzas','Equipos de medición de masa y peso','BAL','2025-12-15 23:35:15'),(3,'Centrifugas','Equipos de separación por centrifugación','CENT','2025-12-15 23:35:15'),(4,'Espectrofotómetros','Equipos de análisis espectral','ESPEC','2025-12-15 23:35:15'),(5,'pH-metros','Equipos de medición de pH','PH','2025-12-15 23:35:15'),(6,'Estufas','Equipos de calentamiento y secado','ESTUF','2025-12-15 23:35:15'),(7,'Equipos Minería','Equipos específicos para análisis minero','MIN','2025-12-15 23:35:15'),(8,'Equipos Suelos','Equipos para análisis de suelos','SUELO','2025-12-15 23:35:15'),(9,'Instrumentos Medición','Instrumentos generales de medición','MED','2025-12-15 23:35:15'),(10,'Reactivos','Productos químicos y reactivos','REACT','2025-12-15 23:35:15');
/*!40000 ALTER TABLE `categorias_equipos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comandos_voz`
--

DROP TABLE IF EXISTS `comandos_voz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comandos_voz` (
  `id_comando` int NOT NULL AUTO_INCREMENT,
  `comando_texto` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `intencion` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parametros` text COLLATE utf8mb4_unicode_ci,
  `respuesta_esperada` text COLLATE utf8mb4_unicode_ci,
  `frecuencia_uso` int DEFAULT '0',
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `estado` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci DEFAULT 'activo',
  PRIMARY KEY (`id_comando`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comandos_voz`
--

LOCK TABLES `comandos_voz` WRITE;
/*!40000 ALTER TABLE `comandos_voz` DISABLE KEYS */;
INSERT INTO `comandos_voz` VALUES (1,'Lucia buscar equipo','buscar_equipo','{\"tipo\": \"general\"}','Iniciando búsqueda de equipos disponibles',0,'2025-12-15 23:35:15','activo'),(2,'Lucia estado laboratorio','consultar_laboratorio','{\"info\": \"estado\"}','Consultando estado actual de laboratorios',0,'2025-12-15 23:35:15','activo'),(3,'Lucia préstamo equipo','solicitar_prestamo','{\"accion\": \"solicitar\"}','Iniciando proceso de solicitud de préstamo',0,'2025-12-15 23:35:15','activo'),(4,'Lucia inventario disponible','consultar_inventario','{\"filtro\": \"disponible\"}','Mostrando inventario disponible',0,'2025-12-15 23:35:15','activo'),(5,'Lucia alertas mantenimiento','consultar_alertas','{\"tipo\": \"mantenimiento\"}','Consultando alertas de mantenimiento pendientes',0,'2025-12-15 23:35:15','activo'),(6,'Lucia ayuda comandos','mostrar_ayuda','{\"seccion\": \"comandos\"}','Mostrando comandos disponibles',0,'2025-12-15 23:35:15','activo'),(7,'Lucia estado préstamos','consultar_prestamos','{\"estado\": \"activos\"}','Consultando préstamos activos',0,'2025-12-15 23:35:15','activo'),(8,'Lucia registrar devolución','devolver_equipo','{\"accion\": \"devolver\"}','Iniciando proceso de devolución',0,'2025-12-15 23:35:15','activo');
/*!40000 ALTER TABLE `comandos_voz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion_sistema`
--

DROP TABLE IF EXISTS `configuracion_sistema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracion_sistema` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clave_config` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_config` text COLLATE utf8mb4_unicode_ci,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `tipo_dato` enum('string','integer','boolean','json') COLLATE utf8mb4_unicode_ci DEFAULT 'string',
  `fecha_actualizacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave_config` (`clave_config`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion_sistema`
--

LOCK TABLES `configuracion_sistema` WRITE;
/*!40000 ALTER TABLE `configuracion_sistema` DISABLE KEYS */;
INSERT INTO `configuracion_sistema` VALUES (1,'nombre_sistema','GIL Laboratorios SENA','Nombre del sistema','string','2025-12-15 23:48:39'),(2,'version','1.0.0','Versión actual del sistema','string','2025-12-15 23:48:39'),(3,'timezone','America/Bogota','Zona horaria del sistema','string','2025-12-15 23:48:39'),(4,'idioma_default','es','Idioma por defecto','string','2025-12-15 23:48:39'),(5,'max_prestamo_horas','8','Máximo de horas por préstamo','integer','2025-12-15 23:48:39'),(6,'dias_anticipacion_alerta','7','Días de anticipación para alertas de mantenimiento','integer','2025-12-15 23:48:39'),(7,'umbral_confianza_voz','0.75','Umbral mínimo de confianza para comandos de voz','string','2025-12-15 23:48:39'),(8,'umbral_confianza_imagen','0.80','Umbral mínimo de confianza para reconocimiento de imágenes','string','2025-12-15 23:48:39'),(9,'habilitar_notificaciones_email','true','Habilitar notificaciones por email','boolean','2025-12-15 23:48:39'),(10,'habilitar_lucia','true','Habilitar asistente de voz LUCIA','boolean','2025-12-15 23:48:39'),(11,'tema_interfaz','claro','Tema de la interfaz (claro/oscuro)','string','2025-12-15 23:48:39'),(12,'backup_automatico','true','Habilitar backup automático diario','boolean','2025-12-15 23:48:39');
/*!40000 ALTER TABLE `configuracion_sistema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encuestas`
--

DROP TABLE IF EXISTS `encuestas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `encuestas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `tipo` enum('practica','prestamo','mantenimiento','general') COLLATE utf8mb4_unicode_ci NOT NULL,
  `puntuacion` int DEFAULT NULL,
  `comentarios` text COLLATE utf8mb4_unicode_ci,
  `fecha` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `encuestas_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `encuestas_chk_1` CHECK ((`puntuacion` between 1 and 5))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encuestas`
--

LOCK TABLES `encuestas` WRITE;
/*!40000 ALTER TABLE `encuestas` DISABLE KEYS */;
INSERT INTO `encuestas` VALUES (1,9,'prestamo',5,'El asistente Lucia me prestó el equipo en 10 segundos, ¡increíble!','2025-12-15 23:48:39'),(2,10,'practica',4,'Muy útil, pero a veces Lucia no entiende mi acento boyacense.','2025-12-15 23:48:39'),(3,11,'mantenimiento',5,'Me avisaron que el microscopio necesitaba calibración antes de que fallara.','2025-12-15 23:48:39'),(4,12,'general',4,'El sistema es rápido, pero falta más información en el dashboard.','2025-12-15 23:48:39'),(5,13,'prestamo',3,'El código QR no funcionó, tuve que usar el buscador manual.','2025-12-15 23:48:39'),(6,14,'practica',5,'La programación de prácticas fue muy fluida, sin conflictos.','2025-12-15 23:48:39'),(7,15,'general',5,'Se nota que el sistema aprende, cada vez reconoce mejor los equipos.','2025-12-15 23:48:39'),(8,16,'mantenimiento',4,'Buenas alertas, pero deberían llegar por email también.','2025-12-15 23:48:39'),(9,17,'prestamo',5,'Devolver el equipo con voz es súper cómodo, especialmente con guantes.','2025-12-15 23:48:39'),(10,18,'general',4,'Me gustaría poder reportar fallos directamente desde el sistema.','2025-12-15 23:48:39');
/*!40000 ALTER TABLE `encuestas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipos`
--

DROP TABLE IF EXISTS `equipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo_interno` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_qr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marca` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modelo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_serie` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_categoria` int DEFAULT NULL,
  `id_laboratorio` int DEFAULT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `especificaciones_tecnicas` text COLLATE utf8mb4_unicode_ci,
  `valor_adquisicion` decimal(12,2) DEFAULT NULL,
  `fecha_adquisicion` date DEFAULT NULL,
  `proveedor` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `garantia_meses` int DEFAULT '12',
  `vida_util_anos` int DEFAULT '5',
  `imagen_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imagen_hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` enum('disponible','prestado','mantenimiento','reparacion','dado_baja') COLLATE utf8mb4_unicode_ci DEFAULT 'disponible',
  `estado_fisico` enum('excelente','bueno','regular','malo') COLLATE utf8mb4_unicode_ci DEFAULT 'bueno',
  `ubicacion_especifica` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_actualizacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo_interno` (`codigo_interno`),
  UNIQUE KEY `codigo_qr` (`codigo_qr`),
  KEY `idx_codigo_interno` (`codigo_interno`),
  KEY `idx_estado` (`estado`),
  KEY `idx_categoria` (`id_categoria`),
  KEY `idx_laboratorio` (`id_laboratorio`),
  CONSTRAINT `equipos_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categorias_equipos` (`id`),
  CONSTRAINT `equipos_ibfk_2` FOREIGN KEY (`id_laboratorio`) REFERENCES `laboratorios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipos`
--

LOCK TABLES `equipos` WRITE;
/*!40000 ALTER TABLE `equipos` DISABLE KEYS */;
INSERT INTO `equipos` VALUES (1,'MICRO-001','QR-MICRO-001','Microscopio Óptico Binocular','Olympus','CX23','OLY-CX23-2024-001',1,1,'Microscopio óptico para análisis de muestras','{\"aumento_max\": \"1000x\", \"oculares\": \"10x\", \"objetivos\": \"4x,10x,40x,100x\"}',3500000.00,'2024-01-15','Equipos Científicos S.A.S',24,10,NULL,NULL,'disponible','excelente','Mesa de trabajo 1',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(2,'MICRO-002','QR-MICRO-002','Microscopio Óptico Binocular','Olympus','CX23','OLY-CX23-2024-002',1,1,'Microscopio óptico para análisis de muestras','{\"aumento_max\": \"1000x\", \"oculares\": \"10x\", \"objetivos\": \"4x,10x,40x,100x\"}',3500000.00,'2024-01-15','Equipos Científicos S.A.S',24,10,NULL,NULL,'disponible','excelente','Mesa de trabajo 2',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(3,'MICRO-003','QR-MICRO-003','Microscopio Estereoscópico','Nikon','SMZ745','NIK-SMZ-2023-001',1,4,'Microscopio para observación de minerales','{\"aumento\": \"0.67x-5x\", \"distancia_trabajo\": \"115mm\"}',8500000.00,'2023-06-20','Nikon Colombia',36,15,NULL,NULL,'disponible','bueno','Estación mineralógica',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(4,'MICRO-004','QR-MICRO-004','Microscopio Petrográfico','Leica','DM750P','LEI-DM750-2022-001',1,4,'Microscopio polarizado para petrografía','{\"polarizadores\": \"rotatorios\", \"platina\": \"circular graduada\"}',25000000.00,'2022-03-10','Leica Microsystems',36,20,NULL,NULL,'disponible','excelente','Sala de petrografía',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(5,'BAL-001','QR-BAL-001','Balanza Analítica de Precisión','Mettler Toledo','ME204E','MT-ME204-2024-001',2,1,'Balanza para pesaje de precisión','{\"capacidad\": \"220g\", \"legibilidad\": \"0.1mg\", \"repetibilidad\": \"0.1mg\"}',12000000.00,'2024-02-01','Mettler Toledo Colombia',24,15,NULL,NULL,'disponible','excelente','Mesa de balanzas',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(6,'BAL-002','QR-BAL-002','Balanza Analítica de Precisión','Mettler Toledo','ME204E','MT-ME204-2024-002',2,1,'Balanza para pesaje de precisión','{\"capacidad\": \"220g\", \"legibilidad\": \"0.1mg\", \"repetibilidad\": \"0.1mg\"}',12000000.00,'2024-02-01','Mettler Toledo Colombia',24,15,NULL,NULL,'disponible','excelente','Mesa de balanzas',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(7,'BAL-003','QR-BAL-003','Balanza de Precisión','Ohaus','Pioneer PX224','OH-PX224-2023-001',2,5,'Balanza para análisis de suelos','{\"capacidad\": \"220g\", \"legibilidad\": \"0.1mg\"}',4500000.00,'2023-08-15','Ohaus Colombia',24,10,NULL,NULL,'disponible','bueno','Área de preparación',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(8,'CENT-001','QR-CENT-001','Centrífuga de Laboratorio','Hettich','EBA 21','HET-EBA21-2024-001',3,1,'Centrífuga para separación de muestras','{\"rpm_max\": \"6000\", \"rcf_max\": \"3461xg\", \"capacidad\": \"6x15ml\"}',8000000.00,'2024-03-01','Hettich Instrumentos',24,12,NULL,NULL,'disponible','excelente','Área de centrifugación',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(9,'CENT-002','QR-CENT-002','Centrífuga Refrigerada','Eppendorf','5430R','EPP-5430R-2023-001',3,2,'Centrífuga con control de temperatura','{\"rpm_max\": \"17500\", \"temperatura\": \"-10 a 40°C\", \"capacidad\": \"30x1.5ml\"}',35000000.00,'2023-05-20','Eppendorf Colombia',36,15,NULL,NULL,'disponible','excelente','Cuarto frío',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(10,'ESPEC-001','QR-ESPEC-001','Espectrofotómetro UV-Vis','Thermo Scientific','Genesys 150','TS-GEN150-2024-001',4,1,'Espectrofotómetro para análisis químico','{\"rango\": \"190-1100nm\", \"ancho_banda\": \"2nm\", \"precision\": \"±0.002A\"}',28000000.00,'2024-01-20','Thermo Fisher Scientific',24,15,NULL,NULL,'disponible','excelente','Área de espectroscopía',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(11,'ESPEC-002','QR-ESPEC-002','Espectrofotómetro de Absorción Atómica','Agilent','240FS AA','AGI-240FS-2022-001',4,1,'AA para análisis de metales','{\"atomizador\": \"llama\", \"elementos\": \"67\", \"precision\": \"< 1% RSD\"}',120000000.00,'2022-06-15','Agilent Technologies',36,20,NULL,NULL,'disponible','bueno','Sala de absorción atómica',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(12,'PH-001','QR-PH-001','pH-metro de Mesa','Hanna Instruments','HI5221','HAN-HI5221-2024-001',5,1,'Medidor de pH de alta precisión','{\"rango_pH\": \"-2 a 20\", \"resolucion\": \"0.001\", \"precision\": \"±0.002\"}',3800000.00,'2024-02-15','Hanna Instruments',24,8,NULL,NULL,'disponible','excelente','Mesa de análisis',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(13,'PH-002','QR-PH-002','pH-metro de Mesa','Hanna Instruments','HI5221','HAN-HI5221-2024-002',5,5,'Medidor de pH para análisis de suelos','{\"rango_pH\": \"-2 a 20\", \"resolucion\": \"0.001\", \"precision\": \"±0.002\"}',3800000.00,'2024-02-15','Hanna Instruments',24,8,NULL,NULL,'disponible','excelente','Área de pH',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(14,'PH-003','QR-PH-003','pH-metro Portátil','Hanna Instruments','HI98190','HAN-HI98190-2023-001',5,7,'Medidor de pH portátil','{\"rango_pH\": \"0 a 14\", \"resolucion\": \"0.01\", \"IP67\": true}',2500000.00,'2023-09-10','Hanna Instruments',24,5,NULL,NULL,'prestado','bueno','Almacén portátiles',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(15,'ESTUF-001','QR-ESTUF-001','Estufa de Secado','Binder','ED 115','BIN-ED115-2023-001',6,5,'Estufa para secado de muestras de suelo','{\"volumen\": \"115L\", \"temperatura_max\": \"300°C\", \"uniformidad\": \"±3°C\"}',15000000.00,'2023-04-01','Binder GmbH',24,15,NULL,NULL,'disponible','excelente','Área de secado',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(16,'ESTUF-002','QR-ESTUF-002','Mufla de Alta Temperatura','Nabertherm','L9/11','NAB-L911-2022-001',6,6,'Mufla para calcinación','{\"volumen\": \"9L\", \"temperatura_max\": \"1100°C\", \"rampa\": \"programable\"}',22000000.00,'2022-08-20','Nabertherm',24,20,NULL,NULL,'disponible','bueno','Área de calcinación',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(17,'MIN-001','QR-MIN-001','Trituradora de Mandíbulas','Retsch','BB 50','RET-BB50-2023-001',7,3,'Trituradora para preparación de muestras','{\"abertura\": \"40x40mm\", \"granulometria_final\": \"<0.5mm\", \"potencia\": \"750W\"}',45000000.00,'2023-02-15','Retsch GmbH',24,20,NULL,NULL,'disponible','excelente','Área de trituración',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(18,'MIN-002','QR-MIN-002','Molino de Bolas','Retsch','PM 100','RET-PM100-2022-001',7,3,'Molino planetario para molienda fina','{\"velocidad_max\": \"650rpm\", \"capacidad\": \"500ml\", \"finura\": \"<1µm\"}',38000000.00,'2022-07-10','Retsch GmbH',24,15,NULL,NULL,'disponible','bueno','Área de molienda',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(19,'MIN-003','QR-MIN-003','Celda de Flotación Denver','Metso','D-12','MET-D12-2021-001',7,3,'Celda de flotación para pruebas batch','{\"volumen\": \"2.5L\", \"rpm\": \"1200\", \"aireacion\": \"controlada\"}',28000000.00,'2021-11-05','Metso Outotec',24,20,NULL,NULL,'disponible','bueno','Área de flotación',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(20,'SUELO-001','QR-SUELO-001','Agitador de Tamices','Retsch','AS 200','RET-AS200-2023-001',8,5,'Agitador para análisis granulométrico','{\"amplitud\": \"3mm\", \"tamices\": \"8\", \"tiempo\": \"programable\"}',18000000.00,'2023-03-20','Retsch GmbH',24,15,NULL,NULL,'disponible','excelente','Área de granulometría',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49'),(21,'SUELO-002','QR-SUELO-002','Hidrómetro de Bouyoucos','Fisher Scientific','ASTM 152H','FS-152H-2024-001',8,5,'Hidrómetro para análisis de textura','{\"rango\": \"0-60g/L\", \"precision\": \"±0.5\"}',850000.00,'2024-01-10','Fisher Scientific',12,10,NULL,NULL,'disponible','excelente','Área de sedimentación',NULL,'2025-12-15 23:35:49','2025-12-15 23:35:49');
/*!40000 ALTER TABLE `equipos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historial_mantenimiento`
--

DROP TABLE IF EXISTS `historial_mantenimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `historial_mantenimiento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_equipo` int NOT NULL,
  `id_tipo_mantenimiento` int NOT NULL,
  `estado` enum('en_proceso','completado','cancelado') COLLATE utf8mb4_unicode_ci DEFAULT 'en_proceso',
  `fecha_inicio` datetime NOT NULL,
  `fecha_fin` datetime DEFAULT NULL,
  `tecnico_responsable_id` int DEFAULT NULL,
  `descripcion_trabajo` text COLLATE utf8mb4_unicode_ci,
  `partes_reemplazadas` text COLLATE utf8mb4_unicode_ci,
  `costo_mantenimiento` decimal(10,2) DEFAULT '0.00',
  `tiempo_inactividad_horas` decimal(5,2) DEFAULT '0.00',
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `estado_post_mantenimiento` enum('excelente','bueno','regular','malo') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proxima_fecha_mantenimiento` date DEFAULT NULL,
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_tipo_mantenimiento` (`id_tipo_mantenimiento`),
  KEY `tecnico_responsable_id` (`tecnico_responsable_id`),
  KEY `idx_equipo_mantenimiento` (`id_equipo`),
  KEY `idx_estado` (`estado`),
  KEY `idx_fecha_inicio` (`fecha_inicio`),
  CONSTRAINT `historial_mantenimiento_ibfk_1` FOREIGN KEY (`id_equipo`) REFERENCES `equipos` (`id`),
  CONSTRAINT `historial_mantenimiento_ibfk_2` FOREIGN KEY (`id_tipo_mantenimiento`) REFERENCES `tipos_mantenimiento` (`id`),
  CONSTRAINT `historial_mantenimiento_ibfk_3` FOREIGN KEY (`tecnico_responsable_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historial_mantenimiento`
--

LOCK TABLES `historial_mantenimiento` WRITE;
/*!40000 ALTER TABLE `historial_mantenimiento` DISABLE KEYS */;
INSERT INTO `historial_mantenimiento` VALUES (1,1,1,'en_proceso','2024-11-01 09:00:00',NULL,6,'Limpieza de lentes, verificación de iluminación y ajuste de platina',NULL,150000.00,2.00,NULL,'excelente','2024-12-01','2025-12-15 23:48:39'),(2,2,1,'en_proceso','2024-11-01 11:00:00',NULL,6,'Limpieza de lentes, verificación de iluminación y ajuste de platina',NULL,150000.00,2.00,NULL,'excelente','2024-12-01','2025-12-15 23:48:39'),(3,5,3,'en_proceso','2024-10-15 08:00:00',NULL,7,'Calibración con pesas patrón certificadas, ajuste de sensibilidad',NULL,350000.00,4.00,NULL,'excelente','2025-04-15','2025-12-15 23:48:39'),(4,6,3,'en_proceso','2024-10-15 14:00:00',NULL,7,'Calibración con pesas patrón certificadas, ajuste de sensibilidad',NULL,350000.00,4.00,NULL,'excelente','2025-04-15','2025-12-15 23:48:39'),(5,11,3,'en_proceso','2024-09-20 09:00:00',NULL,7,'Calibración de longitud de onda, verificación de absorbancia',NULL,500000.00,6.00,NULL,'excelente','2025-03-20','2025-12-15 23:48:39'),(6,12,1,'en_proceso','2024-11-15 08:00:00',NULL,6,'Limpieza de quemador, verificación de gases, ajuste de nebulizador',NULL,800000.00,8.00,NULL,'bueno','2024-12-15','2025-12-15 23:48:39'),(7,19,4,'en_proceso','2024-11-20 09:00:00',NULL,6,'Limpieza profunda de cámara, verificación de sellos y calibración de temperatura',NULL,400000.00,4.00,NULL,'excelente','2024-12-05','2025-12-15 23:48:39');
/*!40000 ALTER TABLE `historial_mantenimiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagenes_entrenamiento`
--

DROP TABLE IF EXISTS `imagenes_entrenamiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagenes_entrenamiento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_equipo` int NOT NULL,
  `ruta_imagen` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `angulo_captura` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'frontal',
  `resolucion` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `formato` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'jpg',
  `tamano_bytes` int DEFAULT NULL,
  `hash_imagen` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `calidad_imagen` decimal(3,2) DEFAULT NULL,
  `estado` enum('pendiente','entrenado','error') COLLATE utf8mb4_unicode_ci DEFAULT 'pendiente',
  `fecha_captura` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_equipo` (`id_equipo`),
  KEY `idx_estado` (`estado`),
  CONSTRAINT `imagenes_entrenamiento_ibfk_1` FOREIGN KEY (`id_equipo`) REFERENCES `equipos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagenes_entrenamiento`
--

LOCK TABLES `imagenes_entrenamiento` WRITE;
/*!40000 ALTER TABLE `imagenes_entrenamiento` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagenes_entrenamiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructores`
--

DROP TABLE IF EXISTS `instructores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `especialidad` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `experiencia_anos` int DEFAULT NULL,
  `certificaciones` text COLLATE utf8mb4_unicode_ci,
  `fecha_vinculacion` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `instructores_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructores`
--

LOCK TABLES `instructores` WRITE;
/*!40000 ALTER TABLE `instructores` DISABLE KEYS */;
INSERT INTO `instructores` VALUES (1,3,'Química Analítica y Control de Calidad',8,'Certificación ISO 17025, Especialización en Análisis Instrumental','2017-02-15'),(2,4,'Procesamiento de Minerales',12,'Maestría en Ingeniería de Minas, Certificación en Flotación','2013-03-20'),(3,5,'Análisis de Suelos y Aguas',6,'Especialización en Gestión Ambiental, Certificación en Muestreo','2019-01-10');
/*!40000 ALTER TABLE `instructores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interacciones_voz`
--

DROP TABLE IF EXISTS `interacciones_voz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interacciones_voz` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int DEFAULT NULL,
  `comando_detectado` text COLLATE utf8mb4_unicode_ci,
  `intencion_identificada` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confianza_reconocimiento` decimal(3,2) DEFAULT NULL,
  `respuesta_generada` text COLLATE utf8mb4_unicode_ci,
  `accion_ejecutada` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exitosa` tinyint(1) DEFAULT '0',
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `duracion_procesamiento_ms` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_usuario` (`id_usuario`),
  KEY `idx_timestamp` (`timestamp`),
  CONSTRAINT `interacciones_voz_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interacciones_voz`
--

LOCK TABLES `interacciones_voz` WRITE;
/*!40000 ALTER TABLE `interacciones_voz` DISABLE KEYS */;
INSERT INTO `interacciones_voz` VALUES (1,9,'Lucia buscar microscopio disponible','buscar_equipo',0.95,'Encontré 3 microscopios disponibles. ¿Deseas ver los detalles?','query_equipos',1,'2025-12-15 23:48:39',245),(2,10,'Lucia estado del laboratorio de química','consultar_laboratorio',0.88,'El laboratorio de Química Analítica está disponible con capacidad para 25 personas.','query_laboratorios',1,'2025-12-15 23:48:39',312),(3,11,'Lucia préstamo balanza','solicitar_prestamo',0.92,'Hay 2 balanzas disponibles. ¿Cuál deseas solicitar?','iniciar_prestamo',1,'2025-12-15 23:48:39',198),(4,12,'Lucia alertas pendientes','consultar_alertas',0.97,'Tienes 3 alertas de mantenimiento pendientes. La más urgente es el microscopio estereoscópico.','query_alertas',1,'2025-12-15 23:48:39',156);
/*!40000 ALTER TABLE `interacciones_voz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `laboratorios`
--

DROP TABLE IF EXISTS `laboratorios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `laboratorios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo_lab` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('quimica','mineria','suelos','metalurgia','general') COLLATE utf8mb4_unicode_ci NOT NULL,
  `ubicacion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `capacidad_personas` int DEFAULT '20',
  `area_m2` decimal(8,2) DEFAULT NULL,
  `responsable_id` int DEFAULT NULL,
  `estado` enum('disponible','ocupado','mantenimiento','fuera_servicio') COLLATE utf8mb4_unicode_ci DEFAULT 'disponible',
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo_lab` (`codigo_lab`),
  KEY `responsable_id` (`responsable_id`),
  CONSTRAINT `laboratorios_ibfk_1` FOREIGN KEY (`responsable_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `laboratorios`
--

LOCK TABLES `laboratorios` WRITE;
/*!40000 ALTER TABLE `laboratorios` DISABLE KEYS */;
INSERT INTO `laboratorios` VALUES (1,'LAB-QUI-001','Laboratorio de Química Analítica','quimica','Bloque A - Piso 2 - Aula 201',25,80.50,1,'disponible','2025-12-15 23:35:48'),(2,'LAB-QUI-002','Laboratorio de Química Orgánica','quimica','Bloque A - Piso 2 - Aula 202',20,65.00,1,'disponible','2025-12-15 23:35:48'),(3,'LAB-MIN-001','Laboratorio de Procesamiento de Minerales','mineria','Bloque B - Piso 1 - Aula 101',30,120.00,2,'disponible','2025-12-15 23:35:48'),(4,'LAB-MIN-002','Laboratorio de Caracterización Mineralógica','mineria','Bloque B - Piso 1 - Aula 102',20,75.00,2,'disponible','2025-12-15 23:35:48'),(5,'LAB-SUE-001','Laboratorio de Análisis de Suelos','suelos','Bloque C - Piso 1 - Aula 103',25,90.00,3,'disponible','2025-12-15 23:35:48'),(6,'LAB-MET-001','Laboratorio de Metalurgia Extractiva','metalurgia','Bloque D - Piso 1 - Aula 104',20,100.00,4,'disponible','2025-12-15 23:35:48'),(7,'LAB-GEN-001','Laboratorio Multipropósito','general','Bloque E - Piso 1 - Aula 105',35,150.00,1,'disponible','2025-12-15 23:35:48');
/*!40000 ALTER TABLE `laboratorios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs_cambios`
--

DROP TABLE IF EXISTS `logs_cambios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs_cambios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tabla_afectada` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_registro` int NOT NULL,
  `campo` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_anterior` text COLLATE utf8mb4_unicode_ci,
  `valor_nuevo` text COLLATE utf8mb4_unicode_ci,
  `id_usuario` int DEFAULT NULL,
  `fecha` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `logs_cambios_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs_cambios`
--

LOCK TABLES `logs_cambios` WRITE;
/*!40000 ALTER TABLE `logs_cambios` DISABLE KEYS */;
/*!40000 ALTER TABLE `logs_cambios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs_sistema`
--

DROP TABLE IF EXISTS `logs_sistema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs_sistema` (
  `id` int NOT NULL AUTO_INCREMENT,
  `modulo` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nivel_log` enum('DEBUG','INFO','WARNING','ERROR','CRITICAL') COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensaje` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_usuario` int DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `datos_adicionales` text COLLATE utf8mb4_unicode_ci,
  `timestamp_log` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_modulo` (`modulo`),
  KEY `idx_nivel_log` (`nivel_log`),
  KEY `idx_timestamp` (`timestamp_log`),
  KEY `idx_usuario_log` (`id_usuario`),
  CONSTRAINT `logs_sistema_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs_sistema`
--

LOCK TABLES `logs_sistema` WRITE;
/*!40000 ALTER TABLE `logs_sistema` DISABLE KEYS */;
INSERT INTO `logs_sistema` VALUES (1,'autenticacion','INFO','Usuario carlos.rodriguez@sena.edu.co inició sesión exitosamente',1,'192.168.1.100',NULL,NULL,'2025-12-15 23:48:39'),(2,'prestamos','INFO','Préstamo PREST-2024-001 creado por usuario ID 9',9,'192.168.1.105',NULL,NULL,'2025-12-15 23:48:39'),(3,'mantenimiento','WARNING','Alerta de mantenimiento vencido para equipo ESTUF-002',NULL,NULL,NULL,NULL,'2025-12-15 23:48:39'),(4,'reconocimiento_voz','INFO','Comando de voz procesado exitosamente: buscar_equipo',9,'192.168.1.105',NULL,NULL,'2025-12-15 23:48:39'),(5,'reconocimiento_imagen','INFO','Equipo MICRO-001 identificado con 94% de confianza',6,'192.168.1.110',NULL,NULL,'2025-12-15 23:48:39'),(6,'sistema','INFO','Backup automático completado exitosamente',NULL,NULL,NULL,NULL,'2025-12-15 23:48:39'),(7,'auth','INFO','Login exitoso',1,'127.0.0.1',NULL,NULL,'2025-12-15 23:51:08');
/*!40000 ALTER TABLE `logs_sistema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modelos_ia`
--

DROP TABLE IF EXISTS `modelos_ia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modelos_ia` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('reconocimiento_imagenes','reconocimiento_voz','prediccion_mantenimiento') COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ruta_archivo` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `precision_modelo` decimal(5,4) DEFAULT NULL,
  `fecha_entrenamiento` date DEFAULT NULL,
  `fecha_deployment` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `estado` enum('activo','inactivo','entrenando') COLLATE utf8mb4_unicode_ci DEFAULT 'activo',
  `parametros_modelo` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modelos_ia`
--

LOCK TABLES `modelos_ia` WRITE;
/*!40000 ALTER TABLE `modelos_ia` DISABLE KEYS */;
INSERT INTO `modelos_ia` VALUES (1,'MobileNetV2-Equipos','reconocimiento_imagenes','2.1.0','/models/mobilenet_equipos_v2.h5',0.9234,'2024-10-15','2025-12-15 23:48:39','activo','{\"input_shape\": [224, 224, 3], \"classes\": 50, \"optimizer\": \"adam\"}'),(2,'Whisper-LUCIA','reconocimiento_voz','1.5.0','/models/whisper_lucia_v1.pt',0.8876,'2024-09-20','2025-12-15 23:48:39','activo','{\"language\": \"es\", \"model_size\": \"medium\", \"beam_size\": 5}'),(3,'LSTM-Mantenimiento','prediccion_mantenimiento','1.2.0','/models/lstm_maint_v1.h5',0.8542,'2024-08-10','2025-12-15 23:48:39','activo','{\"sequence_length\": 30, \"features\": 15, \"hidden_units\": 128}');
/*!40000 ALTER TABLE `modelos_ia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expira_en` datetime NOT NULL,
  `usado` tinyint(1) DEFAULT '0',
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ip_solicitud` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_token` (`token`),
  KEY `idx_expira` (`expira_en`),
  KEY `idx_usuario` (`id_usuario`),
  CONSTRAINT `password_reset_tokens_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `practicas_laboratorio`
--

DROP TABLE IF EXISTS `practicas_laboratorio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `practicas_laboratorio` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_programa` int NOT NULL,
  `id_laboratorio` int NOT NULL,
  `id_instructor` int NOT NULL,
  `fecha` datetime NOT NULL,
  `duracion_horas` decimal(3,1) DEFAULT NULL,
  `numero_estudiantes` int DEFAULT NULL,
  `equipos_requeridos` text COLLATE utf8mb4_unicode_ci,
  `materiales_requeridos` text COLLATE utf8mb4_unicode_ci,
  `objetivos` text COLLATE utf8mb4_unicode_ci,
  `descripcion_actividades` text COLLATE utf8mb4_unicode_ci,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `estado` enum('programada','en_curso','completada','cancelada') COLLATE utf8mb4_unicode_ci DEFAULT 'programada',
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `id_programa` (`id_programa`),
  KEY `id_instructor` (`id_instructor`),
  KEY `idx_fecha` (`fecha`),
  KEY `idx_estado` (`estado`),
  KEY `idx_laboratorio` (`id_laboratorio`),
  CONSTRAINT `practicas_laboratorio_ibfk_1` FOREIGN KEY (`id_programa`) REFERENCES `programas_formacion` (`id`),
  CONSTRAINT `practicas_laboratorio_ibfk_2` FOREIGN KEY (`id_laboratorio`) REFERENCES `laboratorios` (`id`),
  CONSTRAINT `practicas_laboratorio_ibfk_3` FOREIGN KEY (`id_instructor`) REFERENCES `instructores` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `practicas_laboratorio`
--

LOCK TABLES `practicas_laboratorio` WRITE;
/*!40000 ALTER TABLE `practicas_laboratorio` DISABLE KEYS */;
INSERT INTO `practicas_laboratorio` VALUES (1,'PRAC-QUI-001','Análisis Volumétrico: Titulaciones Ácido-Base',1,1,1,'2024-12-15 08:00:00',4.0,20,'[1,2,13,14]','Buretas, erlenmeyers, indicadores, soluciones patrón','Determinar la concentración de soluciones mediante titulación',NULL,NULL,'completada','2025-12-15 23:48:39'),(2,'PRAC-QUI-002','Espectrofotometría UV-Vis',2,1,1,'2024-12-16 08:00:00',3.0,15,'[11]','Celdas de cuarzo, soluciones estándar, micropipetas','Aplicar la ley de Beer-Lambert para cuantificación',NULL,NULL,'completada','2025-12-15 23:48:39'),(3,'PRAC-MIN-001','Preparación de Muestras Minerales',2,3,2,'2024-12-17 08:00:00',5.0,18,'[19,20]','Muestras de roca, bolsas para muestras, etiquetas','Realizar trituración y molienda de muestras minerales',NULL,NULL,'completada','2025-12-15 23:48:39'),(4,'PRAC-MIN-002','Flotación de Sulfuros',2,3,2,'2024-12-18 14:00:00',4.0,12,'[21]','Reactivos de flotación, colectores, espumantes','Separar minerales de cobre por flotación',NULL,NULL,'completada','2025-12-15 23:48:39'),(5,'PRAC-SUE-001','Análisis Granulométrico de Suelos',3,5,3,'2024-12-19 08:00:00',4.0,22,'[22,23,7]','Tamices ASTM, cilindros de sedimentación, dispersante','Determinar la distribución de tamaño de partículas',NULL,NULL,'completada','2025-12-15 23:48:39'),(6,'PRAC-SUE-002','Determinación de pH y Conductividad Eléctrica',3,5,3,'2024-12-20 08:00:00',3.0,20,'[15,16]','Electrodos, soluciones buffer, agua destilada','Medir propiedades electroquímicas del suelo',NULL,NULL,'completada','2025-12-15 23:48:39');
/*!40000 ALTER TABLE `practicas_laboratorio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestamos`
--

DROP TABLE IF EXISTS `prestamos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prestamos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_equipo` int NOT NULL,
  `id_usuario_solicitante` int NOT NULL,
  `id_usuario_autorizador` int DEFAULT NULL,
  `fecha_solicitud` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha` datetime DEFAULT NULL,
  `fecha_devolucion_programada` datetime DEFAULT NULL,
  `fecha_devolucion_real` datetime DEFAULT NULL,
  `proposito` text COLLATE utf8mb4_unicode_ci,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `observaciones_devolucion` text COLLATE utf8mb4_unicode_ci,
  `estado` enum('solicitado','aprobado','rechazado','activo','devuelto','vencido') COLLATE utf8mb4_unicode_ci DEFAULT 'solicitado',
  `calificacion_devolucion` enum('excelente','bueno','regular','malo') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `id_equipo` (`id_equipo`),
  KEY `id_usuario_autorizador` (`id_usuario_autorizador`),
  KEY `idx_estado` (`estado`),
  KEY `idx_fecha` (`fecha`),
  KEY `idx_usuario_solicitante` (`id_usuario_solicitante`),
  CONSTRAINT `prestamos_ibfk_1` FOREIGN KEY (`id_equipo`) REFERENCES `equipos` (`id`),
  CONSTRAINT `prestamos_ibfk_2` FOREIGN KEY (`id_usuario_solicitante`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `prestamos_ibfk_3` FOREIGN KEY (`id_usuario_autorizador`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestamos`
--

LOCK TABLES `prestamos` WRITE;
/*!40000 ALTER TABLE `prestamos` DISABLE KEYS */;
INSERT INTO `prestamos` VALUES (1,'PREST-2024-001',17,9,3,'2025-12-15 23:35:49','2024-12-01 08:00:00','2024-12-01 17:00:00',NULL,'Medición de pH en campo para proyecto de análisis de aguas',NULL,NULL,'activo',NULL),(2,'PREST-2024-002',1,10,3,'2025-12-15 23:35:49','2024-12-10 09:00:00','2024-12-10 12:00:00',NULL,'Práctica de microscopía para identificación de microorganismos',NULL,NULL,'solicitado',NULL),(3,'PREST-2024-003',5,11,6,'2025-12-15 23:35:49','2024-11-25 08:00:00','2024-11-25 16:00:00',NULL,'Pesaje de muestras para análisis gravimétrico',NULL,NULL,'devuelto',NULL),(4,'PREST-2024-004',8,12,6,'2025-12-15 23:35:49','2024-11-28 10:00:00','2024-11-28 14:00:00',NULL,'Separación de fases en muestras de laboratorio',NULL,NULL,'devuelto',NULL),(5,'PREST-2024-005',11,13,3,'2025-12-15 23:35:49','2024-12-05 08:00:00','2024-12-05 17:00:00',NULL,'Análisis de concentración de soluciones',NULL,NULL,'aprobado',NULL);
/*!40000 ALTER TABLE `prestamos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programas_formacion`
--

DROP TABLE IF EXISTS `programas_formacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `programas_formacion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo_programa` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre_programa` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_programa` enum('tecnico','tecnologo','complementaria') COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `duracion_meses` int DEFAULT NULL,
  `estado` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci DEFAULT 'activo',
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo_programa` (`codigo_programa`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programas_formacion`
--

LOCK TABLES `programas_formacion` WRITE;
/*!40000 ALTER TABLE `programas_formacion` DISABLE KEYS */;
INSERT INTO `programas_formacion` VALUES (1,'TEC-MIN-001','Tecnología en Minería','tecnologo','Programa tecnológico en explotación minera',30,'activo'),(2,'TEC-QUI-001','Tecnología en Química','tecnologo','Programa tecnológico en análisis químico',30,'activo'),(3,'TEC-SUE-001','Tecnología en Análisis de Suelos','tecnico','Programa técnico en análisis y caracterización de suelos',18,'activo'),(4,'TEC-MET-001','Tecnología en Metalurgia','tecnologo','Programa tecnológico en procesos metalúrgicos',30,'activo');
/*!40000 ALTER TABLE `programas_formacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reconocimientos_imagen`
--

DROP TABLE IF EXISTS `reconocimientos_imagen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reconocimientos_imagen` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_equipo_detectado` int DEFAULT NULL,
  `imagen_original_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confianza_deteccion` decimal(3,2) DEFAULT NULL,
  `coordenadas_deteccion` text COLLATE utf8mb4_unicode_ci,
  `id_modelo_usado` int DEFAULT NULL,
  `procesado_por_usuario` int DEFAULT NULL,
  `fecha_reconocimiento` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `validacion_manual` enum('correcto','incorrecto','pendiente') COLLATE utf8mb4_unicode_ci DEFAULT 'pendiente',
  PRIMARY KEY (`id`),
  KEY `id_equipo_detectado` (`id_equipo_detectado`),
  KEY `id_modelo_usado` (`id_modelo_usado`),
  KEY `procesado_por_usuario` (`procesado_por_usuario`),
  CONSTRAINT `reconocimientos_imagen_ibfk_1` FOREIGN KEY (`id_equipo_detectado`) REFERENCES `equipos` (`id`),
  CONSTRAINT `reconocimientos_imagen_ibfk_2` FOREIGN KEY (`id_modelo_usado`) REFERENCES `modelos_ia` (`id`),
  CONSTRAINT `reconocimientos_imagen_ibfk_3` FOREIGN KEY (`procesado_por_usuario`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reconocimientos_imagen`
--

LOCK TABLES `reconocimientos_imagen` WRITE;
/*!40000 ALTER TABLE `reconocimientos_imagen` DISABLE KEYS */;
INSERT INTO `reconocimientos_imagen` VALUES (1,1,'/uploads/reconocimiento/img_2024120901.jpg',0.94,'{\"x\": 120, \"y\": 85, \"width\": 340, \"height\": 280}',1,6,'2025-12-15 23:48:39','correcto'),(2,5,'/uploads/reconocimiento/img_2024120902.jpg',0.89,'{\"x\": 200, \"y\": 150, \"width\": 180, \"height\": 220}',1,6,'2025-12-15 23:48:39','correcto'),(3,11,'/uploads/reconocimiento/img_2024120903.jpg',0.78,'{\"x\": 50, \"y\": 30, \"width\": 400, \"height\": 350}',1,7,'2025-12-15 23:48:39','pendiente');
/*!40000 ALTER TABLE `reconocimientos_imagen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre_rol` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `permisos` text COLLATE utf8mb4_unicode_ci,
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `estado` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci DEFAULT 'activo',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre_rol` (`nombre_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrador','Acceso completo al sistema','{\"all\": true, \"usuarios\": true, \"roles\": true, \"programas\": true, \"equipos\": true, \"laboratorios\": true, \"practicas\": true, \"reservas\": true, \"reportes\": true, \"mantenimiento\": true, \"capacitaciones\": true, \"reconocimiento\": true, \"ia_visual\": true, \"backups\": true, \"configuracion\": true, \"ayuda\": true}','2025-12-15 23:35:15','activo'),(2,'Instructor','Gestión de prácticas y préstamos','{\"equipos\": true, \"laboratorios_ver\": true, \"practicas\": true, \"reservas\": true, \"reportes\": true, \"mantenimiento_ver\": true, \"capacitaciones\": true, \"reconocimiento\": true, \"ayuda\": true}','2025-12-15 23:35:15','activo'),(3,'Técnico Laboratorio','Mantenimiento y gestión de equipos','{\"equipos\": true, \"reservas\": true, \"mantenimiento\": true, \"capacitaciones_ver\": true, \"reconocimiento\": true, \"ayuda\": true}','2025-12-15 23:35:15','activo'),(4,'Aprendiz','Consulta de información y solicitud de préstamos','{\"equipos_ver\": true, \"reservas_propias\": true, \"capacitaciones_ver\": true, \"reconocimiento\": true, \"ayuda\": true}','2025-12-15 23:35:15','activo'),(5,'Coordinador','Supervisión y reportes','{\"equipos_ver\": true, \"laboratorios_ver\": true, \"reservas_ver\": true, \"reportes\": true, \"mantenimiento_ver\": true, \"capacitaciones_ver\": true, \"reconocimiento\": true, \"ayuda\": true}','2025-12-15 23:35:15','activo');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos_mantenimiento`
--

DROP TABLE IF EXISTS `tipos_mantenimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipos_mantenimiento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `frecuencia_dias` int DEFAULT '30',
  `es_preventivo` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos_mantenimiento`
--

LOCK TABLES `tipos_mantenimiento` WRITE;
/*!40000 ALTER TABLE `tipos_mantenimiento` DISABLE KEYS */;
INSERT INTO `tipos_mantenimiento` VALUES (1,'Mantenimiento Preventivo Mensual','Revisión general mensual del equipo',30,1),(2,'Mantenimiento Preventivo Trimestral','Mantenimiento detallado trimestral',90,1),(3,'Calibración','Calibración de precisión del equipo',180,1),(4,'Limpieza Profunda','Limpieza y desinfección completa',15,1),(5,'Mantenimiento Correctivo','Reparación por falla o avería',0,0),(6,'Revisión Anual','Inspección completa anual',365,1),(7,'Preventivo General','Mantenimiento preventivo rutinario para asegurar el buen funcionamiento del equipo',30,1),(8,'Correctivo','Mantenimiento correctivo para reparar fallas o averías',0,0),(9,'Calibración','Calibración y ajuste de equipos de medición',90,1),(10,'Limpieza Profunda','Limpieza exhaustiva de componentes internos y externos',15,1),(11,'Revisión Técnica','Inspección técnica completa del equipo',60,1),(12,'Reparación Mayor','Reparación de componentes críticos o reemplazo de piezas importantes',0,0),(13,'Actualización de Software','Actualización de firmware o software del equipo',180,1),(14,'Verificación de Seguridad','Verificación de sistemas de seguridad y protección',45,1);
/*!40000 ALTER TABLE `tipos_mantenimiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `documento` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombres` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidos` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_rol` int DEFAULT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ultimo_acceso` timestamp NULL DEFAULT NULL,
  `estado` enum('activo','inactivo','suspendido') COLLATE utf8mb4_unicode_ci DEFAULT 'activo',
  PRIMARY KEY (`id`),
  UNIQUE KEY `documento` (`documento`),
  UNIQUE KEY `email` (`email`),
  KEY `id_rol` (`id_rol`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'1098765432','Carlos Alberto','Rodríguez Pérez','carlos.rodriguez@sena.edu.co','3101234567',1,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48','2025-12-15 23:51:08','activo'),(2,'1087654321','María Fernanda','González López','maria.gonzalez@sena.edu.co','3112345678',1,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48',NULL,'activo'),(3,'1076543210','Juan Pablo','Martínez Ruiz','juan.martinez@sena.edu.co','3123456789',2,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48',NULL,'activo'),(4,'1065432109','Ana María','Sánchez Torres','ana.sanchez@sena.edu.co','3134567890',2,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48',NULL,'activo'),(5,'1054321098','Pedro Luis','Ramírez Castro','pedro.ramirez@sena.edu.co','3145678901',2,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48',NULL,'activo'),(6,'1043210987','Laura Patricia','Díaz Mendoza','laura.diaz@sena.edu.co','3156789012',3,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48',NULL,'activo'),(7,'1032109876','Diego Alejandro','Hernández Vargas','diego.hernandez@sena.edu.co','3167890123',3,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48',NULL,'activo'),(8,'1021098765','Sofía Valentina','López García','sofia.lopez@sena.edu.co','3178901234',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48',NULL,'activo'),(9,'1010987654','Andrés Felipe','García Muñoz','andres.garcia@sena.edu.co','3189012345',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48',NULL,'activo'),(10,'1009876543','Valentina','Moreno Jiménez','valentina.moreno@sena.edu.co','3190123456',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48',NULL,'activo'),(11,'1008765432','Santiago','Torres Rojas','santiago.torres@sena.edu.co','3201234567',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48',NULL,'activo'),(12,'1007654321','Camila Andrea','Vargas Pineda','camila.vargas@sena.edu.co','3212345678',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48',NULL,'activo'),(13,'1006543210','Daniel Esteban','Castro Silva','daniel.castro@sena.edu.co','3223456789',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48',NULL,'activo'),(14,'1005432109','Isabella','Reyes Ortiz','isabella.reyes@sena.edu.co','3234567890',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48',NULL,'activo'),(15,'1004321098','Mateo','Gutiérrez Parra','mateo.gutierrez@sena.edu.co','3245678901',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48',NULL,'activo'),(16,'1003210987','Mariana','Pineda Arias','mariana.pineda@sena.edu.co','3256789012',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48',NULL,'activo'),(17,'1002109876','Sebastián','Arias Londoño','sebastian.arias@sena.edu.co','3267890123',4,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48',NULL,'activo'),(18,'1001098765','Roberto Carlos','Mendoza Ríos','roberto.mendoza@sena.edu.co','3278901234',5,'$2b$12$kDdDQlyzhIp8gPssX4dpDeUUw4VF8t5JKy1Oif9F9Am9I/vCfTn9O','2025-12-15 23:35:48',NULL,'activo');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `vista_alertas_pendientes`
--

DROP TABLE IF EXISTS `vista_alertas_pendientes`;
/*!50001 DROP VIEW IF EXISTS `vista_alertas_pendientes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_alertas_pendientes` AS SELECT 
 1 AS `id_alerta`,
 1 AS `codigo_interno`,
 1 AS `nombre_equipo`,
 1 AS `nombre_laboratorio`,
 1 AS `tipo_alerta`,
 1 AS `descripcion_alerta`,
 1 AS `fecha_limite`,
 1 AS `prioridad`,
 1 AS `dias_hasta_limite`,
 1 AS `asignado_a`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista_equipos_completa`
--

DROP TABLE IF EXISTS `vista_equipos_completa`;
/*!50001 DROP VIEW IF EXISTS `vista_equipos_completa`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_equipos_completa` AS SELECT 
 1 AS `id_equipo`,
 1 AS `codigo_interno`,
 1 AS `nombre_equipo`,
 1 AS `marca`,
 1 AS `modelo`,
 1 AS `nombre_categoria`,
 1 AS `nombre_laboratorio`,
 1 AS `codigo_lab`,
 1 AS `estado_equipo`,
 1 AS `estado_fisico`,
 1 AS `ubicacion_especifica`,
 1 AS `fecha_registro`,
 1 AS `usuario_actual`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista_prestamos_activos`
--

DROP TABLE IF EXISTS `vista_prestamos_activos`;
/*!50001 DROP VIEW IF EXISTS `vista_prestamos_activos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_prestamos_activos` AS SELECT 
 1 AS `id_prestamo`,
 1 AS `codigo_prestamo`,
 1 AS `codigo_interno`,
 1 AS `nombre_equipo`,
 1 AS `solicitante`,
 1 AS `fecha_prestamo`,
 1 AS `fecha_devolucion_programada`,
 1 AS `dias_restantes`,
 1 AS `estado_temporal`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'gil_laboratorios'
--

--
-- Dumping routines for database 'gil_laboratorios'
--

--
-- Final view structure for view `vista_alertas_pendientes`
--

/*!50001 DROP VIEW IF EXISTS `vista_alertas_pendientes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_alertas_pendientes` AS select `a`.`id` AS `id_alerta`,`e`.`codigo_interno` AS `codigo_interno`,`e`.`nombre` AS `nombre_equipo`,`l`.`nombre` AS `nombre_laboratorio`,`a`.`tipo_alerta` AS `tipo_alerta`,`a`.`descripcion_alerta` AS `descripcion_alerta`,`a`.`fecha_limite` AS `fecha_limite`,`a`.`prioridad` AS `prioridad`,(to_days(`a`.`fecha_limite`) - to_days(now())) AS `dias_hasta_limite`,concat(`u`.`nombres`,' ',`u`.`apellidos`) AS `asignado_a` from (((`alertas_mantenimiento` `a` join `equipos` `e` on((`a`.`id_equipo` = `e`.`id`))) left join `laboratorios` `l` on((`e`.`id_laboratorio` = `l`.`id`))) left join `usuarios` `u` on((`a`.`asignado_a` = `u`.`id`))) where (`a`.`estado_alerta` = 'pendiente') order by `a`.`prioridad` desc,`a`.`fecha_limite` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_equipos_completa`
--

/*!50001 DROP VIEW IF EXISTS `vista_equipos_completa`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_equipos_completa` AS select `e`.`id` AS `id_equipo`,`e`.`codigo_interno` AS `codigo_interno`,`e`.`nombre` AS `nombre_equipo`,`e`.`marca` AS `marca`,`e`.`modelo` AS `modelo`,`c`.`nombre` AS `nombre_categoria`,`l`.`nombre` AS `nombre_laboratorio`,`l`.`codigo_lab` AS `codigo_lab`,`e`.`estado` AS `estado_equipo`,`e`.`estado_fisico` AS `estado_fisico`,`e`.`ubicacion_especifica` AS `ubicacion_especifica`,`e`.`fecha_registro` AS `fecha_registro`,(case when (`e`.`estado` = 'prestado') then (select concat(`u`.`nombres`,' ',`u`.`apellidos`) from (`prestamos` `p` join `usuarios` `u` on((`p`.`id_usuario_solicitante` = `u`.`id`))) where ((`p`.`id_equipo` = `e`.`id`) and (`p`.`estado` = 'activo')) order by `p`.`fecha_solicitud` desc limit 1) else NULL end) AS `usuario_actual` from ((`equipos` `e` left join `categorias_equipos` `c` on((`e`.`id_categoria` = `c`.`id`))) left join `laboratorios` `l` on((`e`.`id_laboratorio` = `l`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_prestamos_activos`
--

/*!50001 DROP VIEW IF EXISTS `vista_prestamos_activos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_prestamos_activos` AS select `p`.`id` AS `id_prestamo`,`p`.`codigo` AS `codigo_prestamo`,`e`.`codigo_interno` AS `codigo_interno`,`e`.`nombre` AS `nombre_equipo`,concat(`u`.`nombres`,' ',`u`.`apellidos`) AS `solicitante`,`p`.`fecha` AS `fecha_prestamo`,`p`.`fecha_devolucion_programada` AS `fecha_devolucion_programada`,(to_days(`p`.`fecha_devolucion_programada`) - to_days(now())) AS `dias_restantes`,(case when (`p`.`fecha_devolucion_programada` < now()) then 'VENCIDO' when ((to_days(`p`.`fecha_devolucion_programada`) - to_days(now())) <= 1) then 'POR_VENCER' else 'VIGENTE' end) AS `estado_temporal` from ((`prestamos` `p` join `equipos` `e` on((`p`.`id_equipo` = `e`.`id`))) join `usuarios` `u` on((`p`.`id_usuario_solicitante` = `u`.`id`))) where (`p`.`estado` = 'activo') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-15 18:56:11
